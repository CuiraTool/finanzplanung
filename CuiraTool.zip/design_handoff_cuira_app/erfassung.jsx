/* global React, ReactDOM */
const { useState, useEffect, useMemo, useRef } = React;

const fmt = (n) => n == null || isNaN(n) || n === 0 ? "" : Math.round(n).toLocaleString("de-CH").replace(/,/g, "'");
const parseN = (raw) => {
  const cleaned = String(raw).replace(/[^0-9-]/g, "");
  return cleaned === "" || cleaned === "-" ? 0 : parseInt(cleaned, 10);
};

// === Initial state ===
const INITIAL = {
  mandantId: "M-2026-0142",
  fallart: "paar",
  partner: { name: "Lukas Fischer", firma: "Fischer Vorsorge AG", initials: "LF" },
  priority: "normal",
  notiz: "",
  client: {
    p1: { vorname: "Anna", nachname: "Keller", geb: "1968-04-22", zivilstand: "verheiratet", ahv: "" },
    p2: { vorname: "Marc", nachname: "Keller", geb: "1965-11-09", zivilstand: "verheiratet", ahv: "" },
    adresse: { strasse: "Bahnhofstrasse 24", plz: "8810", ort: "Horgen", kanton: "ZH" },
    email: "anna.keller@example.ch",
    telefon: "+41 44 712 88 30",
  },
  budget: { einkP1: 145000, einkP2: 178000, ausgaben: 138000, wunschPension: 105000 },
  ahv: { rentenfaktorP1: 1.0, rentenfaktorP2: 0.95, beitragsluckenP1: 0, beitragsluckenP2: 1 },
  vorsorge: {
    pkP1: 580000, pkP1Rente: 38500, uswP1: 5.4, einkaufP1: 0, bezugsformP1: "mischung",
    pkP2: 720000, pkP2Rente: 49200, uswP2: 5.4, einkaufP2: 25000, bezugsformP2: "rente",
    s3aP1: 92000, s3aP2: 84000, einzahlungS3aP1: 7258, einzahlungS3aP2: 7258,
    s3bP1: 24000, s3bP2: 0,
    fzP1: 0, fzP2: 25000,
  },
  firma: { vorhanden: false, name: "", anteilProzent: 0, marktwert: 0, liquidation: "offen" },
  nachlass: {
    testament: false, ehevertrag: false, vorsorgeauftrag: false, patientenverfuegung: false,
    erbteilung: "gesetzlich", begunstigte3a: "Ehepartner",
    notiz: "",
  },
  vermoegen: [
    { id: "v1", art: "Lohnkonto", bank: "ZKB", saldo: 38000 },
    { id: "v2", art: "Wertschriftendepot", bank: "Swissquote", saldo: 245000 },
  ],
  immo: [
    { id: "i1", typ: "Eigenheim", ort: "Horgen", verkehrswert: 1450000, hypothek: 850000 },
  ],
  ziele: { pensP1: 64, pensP2: 65, bezugsart: "mischung" },
  docs: {
    vorsorgeausweisP1: { name: "PK_Anna_2026.pdf", size: "240 KB", attached: true },
    vorsorgeausweisP2: null,
    steuerklr: { name: "Steuer_2024.pdf", size: "1.8 MB", attached: true },
    s3aP1: null,
    s3aP2: null,
  },
};

// Sections — gleiche 10 Blöcke wie Cuira Pro, plus 2 Affiliate-spezifische am Ende
const SECTIONS = [
  { id: "personen",  num: "01", label: "Personen",         group: "Stammdaten" },
  { id: "ziele",     num: "02", label: "Ziele & Wünsche",   group: "Stammdaten" },
  { id: "budget",    num: "03", label: "Budget",            group: "Stammdaten" },
  { id: "ahv",       num: "04", label: "1. Säule (AHV)",    group: "Vorsorge" },
  { id: "pk",        num: "05", label: "Pensionskasse",     group: "Vorsorge" },
  { id: "s3",        num: "06", label: "3. Säule",          group: "Vorsorge" },
  { id: "vermoegen", num: "07", label: "Vermögen",          group: "Substanz" },
  { id: "immo",      num: "08", label: "Immobilien",        group: "Substanz" },
  { id: "firma",     num: "09", label: "Firma",             group: "Substanz" },
  { id: "nachlass",  num: "10", label: "Nachlass",          group: "Substanz" },
  { id: "docs",      num: "11", label: "Dokumente",         group: "Übergabe" },
  { id: "uebergabe", num: "12", label: "Notiz & Senden",    group: "Übergabe" },
];

// === Completion logic ===
function completion(s) {
  const r = {};
  const isPaar = s.fallart === "paar";
  r.personen = !!(s.client.p1.vorname && s.client.p1.geb && s.client.adresse.plz && (s.fallart !== "paar" || (s.client.p2.vorname && s.client.p2.geb)));
  r.ziele = !!(s.ziele.pensP1 && s.ziele.bezugsart);
  r.budget = s.budget.einkP1 > 0 && s.budget.ausgaben > 0;
  r.ahv = s.ahv.rentenfaktorP1 > 0;
  r.pk = s.vorsorge.pkP1 > 0;
  r.s3 = s.vorsorge.s3aP1 >= 0;
  r.vermoegen = s.vermoegen.length > 0;
  r.immo = true;
  r.firma = !s.firma.vorhanden || (s.firma.name && s.firma.marktwert > 0);
  r.nachlass = s.nachlass.erbteilung && s.nachlass.begunstigte3a;
  r.docs = !!s.docs.vorsorgeausweisP1;
  r.uebergabe = !!s.notiz && s.notiz.length >= 10;
  return r;
}

// === Atoms ===
function Row({ label, help, children }) {
  return (
    <div className="row">
      <div className="row-label">
        <span>{label}</span>
        {help && <span className="row-help">{help}</span>}
      </div>
      <div className="row-control">{children}</div>
    </div>
  );
}

function NumInput({ value, onChange, suffix = "CHF", placeholder = "0", min }) {
  return (
    <div className="input-with-suffix">
      <input
        className="input is-num"
        type="text"
        value={fmt(value)}
        placeholder={placeholder}
        onChange={(e) => onChange(parseN(e.target.value))}
      />
      <span className="suffix">{suffix}</span>
    </div>
  );
}

function Seg({ value, onChange, options }) {
  return (
    <div className="seg">
      {options.map(o => (
        <button key={o.value} className={value === o.value ? "is-active" : ""} onClick={() => onChange(o.value)}>{o.label}</button>
      ))}
    </div>
  );
}

function Check({ checked, onChange, label }) {
  return (
    <button className={`check ${checked ? "is-on" : ""}`} onClick={() => onChange(!checked)}>
      <span className="check-box"></span>
      {label}
    </button>
  );
}

function Section({ id, num, title, meta, isActive, refMap, children }) {
  return (
    <section ref={(el) => refMap.current[id] = el} id={`sec-${id}`} className="section">
      <header className="section-head">
        <div className="section-head-l">
          <span className="section-num">{num}</span>
          <h2 className="section-title">{title}</h2>
        </div>
        {meta && <div className="section-meta">{meta}</div>}
      </header>
      <div className="section-body">{children}</div>
    </section>
  );
}

// === Repeaters ===
function VermoegenList({ items, onChange }) {
  const upd = (id, k, v) => onChange(items.map(x => x.id === id ? { ...x, [k]: v } : x));
  const add = () => onChange([...items, { id: `v${Date.now()}`, art: "", bank: "", saldo: 0 }]);
  const del = (id) => onChange(items.filter(x => x.id !== id));
  return (
    <div className="repeater">
      <div className="rep-head grid-rep-4">
        <div>Art</div><div>Bank / Anbieter</div><div style={{ textAlign: "right" }}>Saldo CHF</div><div></div>
      </div>
      {items.map(it => (
        <div key={it.id} className="rep-row grid-rep-4">
          <input className="input" value={it.art} placeholder="Lohnkonto, Depot…" onChange={(e) => upd(it.id, "art", e.target.value)} />
          <input className="input" value={it.bank} placeholder="Bank/Broker" onChange={(e) => upd(it.id, "bank", e.target.value)} />
          <input className="input is-num" value={fmt(it.saldo)} onChange={(e) => upd(it.id, "saldo", parseN(e.target.value))} placeholder="0" />
          <button className="rep-del" onClick={() => del(it.id)} title="Entfernen">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M3 5h10M6 5V3h4v2M5 5l1 9h4l1-9" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
        </div>
      ))}
      <button className="rep-add" onClick={add}>+ Position hinzufügen</button>
    </div>
  );
}

function ImmoList({ items, onChange }) {
  const upd = (id, k, v) => onChange(items.map(x => x.id === id ? { ...x, [k]: v } : x));
  const add = () => onChange([...items, { id: `i${Date.now()}`, typ: "Eigenheim", ort: "", verkehrswert: 0, hypothek: 0 }]);
  const del = (id) => onChange(items.filter(x => x.id !== id));
  return (
    <div className="repeater">
      <div className="rep-head grid-rep-immo">
        <div>Typ · Ort</div><div style={{ textAlign: "right" }}>Verkehrswert</div><div style={{ textAlign: "right" }}>Hypothek</div><div></div>
      </div>
      {items.map(it => (
        <div key={it.id} className="rep-row grid-rep-immo">
          <div style={{ display: "flex", padding: "4px 6px", gap: 4 }}>
            <input className="input" style={{ flex: "0 0 110px" }} value={it.typ} onChange={(e) => upd(it.id, "typ", e.target.value)} />
            <input className="input" style={{ flex: 1 }} value={it.ort} placeholder="Ort" onChange={(e) => upd(it.id, "ort", e.target.value)} />
          </div>
          <input className="input is-num" value={fmt(it.verkehrswert)} onChange={(e) => upd(it.id, "verkehrswert", parseN(e.target.value))} placeholder="0" />
          <input className="input is-num" value={fmt(it.hypothek)} onChange={(e) => upd(it.id, "hypothek", parseN(e.target.value))} placeholder="0" />
          <button className="rep-del" onClick={() => del(it.id)}>
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M3 5h10M6 5V3h4v2M5 5l1 9h4l1-9" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
        </div>
      ))}
      <button className="rep-add" onClick={add}>+ Liegenschaft hinzufügen</button>
    </div>
  );
}

// === Doc upload ===
function Upload({ doc, onAttach, label, sub }) {
  const click = () => onAttach({ name: `${label.replace(/\s+/g, "_")}.pdf`, size: `${(0.5 + Math.random() * 1.8).toFixed(1)} MB`, attached: true });
  return (
    <div className={`upload ${doc?.attached ? "is-attached" : ""}`} onClick={click}>
      <div className="upload-icon">
        {doc?.attached
          ? <svg width="18" height="18" viewBox="0 0 16 16" fill="none"><path d="M3 8.5l3 3 7-7" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>
          : <svg width="18" height="18" viewBox="0 0 16 16" fill="none"><path d="M8 3v8m0 0L5 8m3 3l3-3M3 13h10" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>}
      </div>
      <div className="upload-info">
        <div className="upload-title">{label}</div>
        <div className="upload-sub">{doc?.attached ? `${doc.name} · ${doc.size}` : sub}</div>
      </div>
    </div>
  );
}

// === Hand-off panel ===
function ProgressRing({ pct }) {
  const r = 24, c = 2 * Math.PI * r;
  const off = c - (pct / 100) * c;
  return (
    <svg width="56" height="56" viewBox="0 0 56 56">
      <circle cx="28" cy="28" r={r} fill="none" stroke="var(--border)" strokeWidth="4" />
      <circle cx="28" cy="28" r={r} fill="none" stroke="var(--cuira)" strokeWidth="4"
        strokeDasharray={c} strokeDashoffset={off} strokeLinecap="round"
        style={{ transition: "stroke-dashoffset 320ms cubic-bezier(.2,.9,.3,1)" }} />
    </svg>
  );
}

function Handoff({ s, set, comp, onSubmit }) {
  const done = Object.values(comp).filter(Boolean).length;
  const total = Object.keys(comp).length;
  const pct = Math.round((done / total) * 100);
  const ready = pct === 100;
  return (
    <aside className="handoff">
      <div className="handoff-head">
        <div className="handoff-eyebrow">Übergabe-Status</div>
        <div className="handoff-title">{s.mandantId} · {s.client.p1.nachname}</div>
      </div>
      <div className="handoff-body">
        <div className="ring-wrap">
          <div className="ring">
            <ProgressRing pct={pct} />
            <div className="ring-text">{pct}%</div>
          </div>
          <div>
            <div className="ring-info-title">{done} von {total} Sektionen</div>
            <div className="ring-info-sub">{ready ? "Bereit zur Übergabe an Cuira" : `${total - done} noch offen`}</div>
          </div>
        </div>

        <div className="checklist">
          {SECTIONS.map(sec => (
            <div key={sec.id} className={`checklist-item ${comp[sec.id] ? "is-done" : ""}`}>
              <span className="checklist-icon"></span>
              <span>{sec.label}</span>
              <span className="checklist-pct">{comp[sec.id] ? "OK" : "—"}</span>
            </div>
          ))}
        </div>

        <div className="panel-section">
          <span className="panel-h">Priorität</span>
          <div className="priority">
            <button className={s.priority === "normal" ? "is-active" : ""} onClick={() => set({ priority: "normal" })}>Normal</button>
            <button data-tone="warn" className={s.priority === "hoch" ? "is-active" : ""} onClick={() => set({ priority: "hoch" })}>Hoch</button>
            <button data-tone="urg" className={s.priority === "dringend" ? "is-active" : ""} onClick={() => set({ priority: "dringend" })}>Dringend</button>
          </div>
        </div>

        <div className="panel-section">
          <span className="panel-h">Berater-Notiz</span>
          <textarea className="textarea" placeholder="Kontext, offene Fragen, Wünsche des Mandanten…"
            value={s.notiz} onChange={(e) => set({ notiz: e.target.value })} />
          <div className="meta-line">
            <span>Mind. 10 Zeichen</span>
            <span className="mono">{s.notiz.length}</span>
          </div>
        </div>

        <div className="panel-section">
          <span className="panel-h">Provision-Voraussichtlich</span>
          <div className="panel-card">
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12 }}>
              <span style={{ color: "var(--ink-2)" }}>Bei Mandatsabschluss</span>
              <strong className="mono" style={{ color: "var(--cuira)", fontSize: 15 }}>CHF 1'200</strong>
            </div>
            <div style={{ fontSize: 11, color: "var(--ink-3)" }}>Standard-Affiliate-Tarif · auszahlbar nach Erstgespräch.</div>
          </div>
        </div>
      </div>
      <div className="handoff-foot">
        <button className="btn btn-primary" disabled={!ready} onClick={onSubmit}>
          {ready ? "An Cuira übergeben" : `${total - done} Sektion(en) offen`}
          {ready && <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M3 8h10m0 0L9 4m4 4l-4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>}
        </button>
        <button className="btn btn-ghost">Als Entwurf speichern</button>
      </div>
    </aside>
  );
}

// === Section renderers ===
function SecStamm({ s, set }) {
  const setA = (k, v) => set({ client: { ...s.client, adresse: { ...s.client.adresse, [k]: v } } });
  return <>
    <Row label="Mandanten-ID" help="Auto-generiert">
      <input className="input mono" value={s.mandantId} readOnly style={{ background: "var(--bg-2)", color: "var(--ink-3)", flex: 1 }} />
    </Row>
    <Row label="Fall-Art">
      <Seg value={s.fallart} onChange={(v) => set({ fallart: v })} options={[
        { value: "single", label: "Einzelperson" }, { value: "paar", label: "Paar" }, { value: "firma", label: "Firma" }
      ]} />
    </Row>
    <Row label="Strasse · Nr.">
      <input className="input is-grow" value={s.client.adresse.strasse} onChange={(e) => setA("strasse", e.target.value)} />
    </Row>
    <Row label="PLZ · Ort">
      <input className="input" style={{ width: 90 }} value={s.client.adresse.plz} onChange={(e) => setA("plz", e.target.value)} />
      <input className="input is-grow" value={s.client.adresse.ort} onChange={(e) => setA("ort", e.target.value)} />
    </Row>
    <Row label="Steuerkanton">
      <Seg value={s.client.adresse.kanton} onChange={(v) => setA("kanton", v)} options={[
        { value: "ZH", label: "ZH" }, { value: "ZG", label: "ZG" }, { value: "SZ", label: "SZ" }, { value: "BE", label: "BE" }, { value: "Andere", label: "Andere" }
      ]} />
    </Row>
    <Row label="E-Mail · Telefon">
      <input className="input" style={{ flex: 1 }} value={s.client.email} onChange={(e) => set({ client: { ...s.client, email: e.target.value } })} />
      <input className="input" style={{ flex: 1 }} value={s.client.telefon} onChange={(e) => set({ client: { ...s.client, telefon: e.target.value } })} />
    </Row>
  </>;
}

function PersonRows({ p, label, onChange }) {
  return <>
    <Row label={`${label} · Name`}>
      <input className="input" style={{ flex: 1 }} placeholder="Vorname" value={p.vorname} onChange={(e) => onChange({ ...p, vorname: e.target.value })} />
      <input className="input" style={{ flex: 1 }} placeholder="Nachname" value={p.nachname} onChange={(e) => onChange({ ...p, nachname: e.target.value })} />
    </Row>
    <Row label={`${label} · Geburtsdatum`}>
      <input className="input mono" type="date" value={p.geb} onChange={(e) => onChange({ ...p, geb: e.target.value })} />
    </Row>
    <Row label={`${label} · Zivilstand`}>
      <Seg value={p.zivilstand} onChange={(v) => onChange({ ...p, zivilstand: v })} options={[
        { value: "ledig", label: "Ledig" }, { value: "verheiratet", label: "Verheiratet" }, { value: "geschieden", label: "Geschieden" }, { value: "verwitwet", label: "Verwitwet" }
      ]} />
    </Row>
    <Row label={`${label} · AHV-Nummer`} help="Optional · 13 Stellen">
      <input className="input mono" placeholder="756.xxxx.xxxx.xx" value={p.ahv} onChange={(e) => onChange({ ...p, ahv: e.target.value })} />
    </Row>
  </>;
}

function SecZiele({ s, set }) {
  const setZ = (k, v) => set({ ziele: { ...s.ziele, [k]: v } });
  const isPaar = s.fallart === "paar";
  return <>
    <Row label={`Wunsch-Pensionsalter${isPaar ? " P1" : ""}`}>
      <input className="input mono" type="number" min="58" max="70" style={{ width: 80 }}
        value={s.ziele.pensP1} onChange={(e) => setZ("pensP1", parseInt(e.target.value || "65", 10))} />
      <span style={{ fontSize: 12, color: "var(--ink-3)" }}>{s.ziele.pensP1 < 65 ? `Frühpension · ${65 - s.ziele.pensP1} J. vor 65` : s.ziele.pensP1 === 65 ? "Ordentlich" : `Aufgeschoben · +${s.ziele.pensP1 - 65}`}</span>
    </Row>
    {isPaar && <Row label="Wunsch-Pensionsalter P2">
      <input className="input mono" type="number" min="58" max="70" style={{ width: 80 }}
        value={s.ziele.pensP2} onChange={(e) => setZ("pensP2", parseInt(e.target.value || "65", 10))} />
    </Row>}
    <Row label="Bezugsart PK" help="Präferenz — wird im Termin verfeinert">
      <Seg value={s.ziele.bezugsart} onChange={(v) => setZ("bezugsart", v)} options={[
        { value: "rente", label: "Rente" }, { value: "kapital", label: "Kapital" }, { value: "mischung", label: "Mischung" }, { value: "offen", label: "Offen" }
      ]} />
    </Row>
    <Row label="Wunschausgaben Pension" help="Lebenshaltung pro Jahr nach Pensionierung">
      <NumInput value={s.budget.wunschPension} onChange={(v) => set({ budget: { ...s.budget, wunschPension: v } })} suffix="CHF/J" />
    </Row>
  </>;
}

function SecAhv({ s, set }) {
  const setA = (k, v) => set({ ahv: { ...s.ahv, [k]: v } });
  const isPaar = s.fallart === "paar";
  return <>
    <Row label={`Rentenfaktor${isPaar ? " P1" : ""}`} help="1.00 = volle 44 Beitragsjahre. Reduktion bei Lücken.">
      <input className="input mono" type="number" step="0.01" min="0" max="1" style={{ width: 100 }}
        value={s.ahv.rentenfaktorP1} onChange={(e) => setA("rentenfaktorP1", parseFloat(e.target.value || "0"))} />
      <span style={{ fontSize: 11, color: "var(--ink-3)" }}>x AHV-Maximalrente</span>
    </Row>
    <Row label={`Beitragslücken${isPaar ? " P1" : ""}`} help="Anzahl Jahre ohne Beitrag">
      <input className="input mono" type="number" min="0" max="44" style={{ width: 80 }}
        value={s.ahv.beitragsluckenP1} onChange={(e) => setA("beitragsluckenP1", parseInt(e.target.value || "0", 10))} />
      <span style={{ fontSize: 11, color: "var(--ink-3)" }}>Jahre</span>
    </Row>
    {isPaar && <Row label="Rentenfaktor P2">
      <input className="input mono" type="number" step="0.01" min="0" max="1" style={{ width: 100 }}
        value={s.ahv.rentenfaktorP2} onChange={(e) => setA("rentenfaktorP2", parseFloat(e.target.value || "0"))} />
    </Row>}
    {isPaar && <Row label="Beitragslücken P2">
      <input className="input mono" type="number" min="0" max="44" style={{ width: 80 }}
        value={s.ahv.beitragsluckenP2} onChange={(e) => setA("beitragsluckenP2", parseInt(e.target.value || "0", 10))} />
    </Row>}
  </>;
}

function SecPk({ s, set }) {
  const setV = (k, v) => set({ vorsorge: { ...s.vorsorge, [k]: v } });
  const isPaar = s.fallart === "paar";
  return <>
    <Row label={`Altersguthaben${isPaar ? " P1" : ""}`} help="Aus Vorsorgeausweis">
      <NumInput value={s.vorsorge.pkP1} onChange={(v) => setV("pkP1", v)} />
    </Row>
    <Row label={`Erwartete Rente p.a.${isPaar ? " P1" : ""}`}>
      <NumInput value={s.vorsorge.pkP1Rente} onChange={(v) => setV("pkP1Rente", v)} suffix="CHF/J" />
    </Row>
    <Row label={`Umwandlungssatz${isPaar ? " P1" : ""}`}>
      <input className="input mono" type="number" step="0.1" style={{ width: 80 }}
        value={s.vorsorge.uswP1} onChange={(e) => setV("uswP1", parseFloat(e.target.value || "0"))} />
      <span style={{ fontSize: 11, color: "var(--ink-3)" }}>%</span>
    </Row>
    <Row label={`Bezugsform${isPaar ? " P1" : ""}`}>
      <Seg value={s.vorsorge.bezugsformP1} onChange={(v) => setV("bezugsformP1", v)} options={[
        { value: "rente", label: "Rente" }, { value: "kapital", label: "Kapital" }, { value: "mischung", label: "Mischung" }
      ]} />
    </Row>
    <Row label={`Geplanter PK-Einkauf${isPaar ? " P1" : ""}`} help="Sperrfrist 3 Jahre beachten">
      <NumInput value={s.vorsorge.einkaufP1} onChange={(v) => setV("einkaufP1", v)} />
    </Row>
    <Row label={`FZ-Guthaben${isPaar ? " P1" : ""}`}>
      <NumInput value={s.vorsorge.fzP1} onChange={(v) => setV("fzP1", v)} />
    </Row>
    {isPaar && <>
      <div style={{ height: 4, borderTop: "1px dashed var(--border)" }}></div>
      <Row label="Altersguthaben P2"><NumInput value={s.vorsorge.pkP2} onChange={(v) => setV("pkP2", v)} /></Row>
      <Row label="Erwartete Rente p.a. P2"><NumInput value={s.vorsorge.pkP2Rente} onChange={(v) => setV("pkP2Rente", v)} suffix="CHF/J" /></Row>
      <Row label="Umwandlungssatz P2">
        <input className="input mono" type="number" step="0.1" style={{ width: 80 }}
          value={s.vorsorge.uswP2} onChange={(e) => setV("uswP2", parseFloat(e.target.value || "0"))} />
        <span style={{ fontSize: 11, color: "var(--ink-3)" }}>%</span>
      </Row>
      <Row label="Bezugsform P2">
        <Seg value={s.vorsorge.bezugsformP2} onChange={(v) => setV("bezugsformP2", v)} options={[
          { value: "rente", label: "Rente" }, { value: "kapital", label: "Kapital" }, { value: "mischung", label: "Mischung" }
        ]} />
      </Row>
      <Row label="Geplanter PK-Einkauf P2"><NumInput value={s.vorsorge.einkaufP2} onChange={(v) => setV("einkaufP2", v)} /></Row>
      <Row label="FZ-Guthaben P2"><NumInput value={s.vorsorge.fzP2} onChange={(v) => setV("fzP2", v)} /></Row>
    </>}
  </>;
}

function SecS3({ s, set }) {
  const setV = (k, v) => set({ vorsorge: { ...s.vorsorge, [k]: v } });
  const isPaar = s.fallart === "paar";
  return <>
    <div style={{ fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--ink-3)", letterSpacing: ".08em", textTransform: "uppercase" }}>3a · gebundene Vorsorge</div>
    <Row label={`Guthaben${isPaar ? " P1" : ""}`}><NumInput value={s.vorsorge.s3aP1} onChange={(v) => setV("s3aP1", v)} /></Row>
    <Row label={`Einzahlung p.a.${isPaar ? " P1" : ""}`} help="Max. 7'258 CHF (Angestellte)">
      <NumInput value={s.vorsorge.einzahlungS3aP1} onChange={(v) => setV("einzahlungS3aP1", v)} suffix="CHF/J" />
    </Row>
    {isPaar && <Row label="Guthaben P2"><NumInput value={s.vorsorge.s3aP2} onChange={(v) => setV("s3aP2", v)} /></Row>}
    {isPaar && <Row label="Einzahlung p.a. P2"><NumInput value={s.vorsorge.einzahlungS3aP2} onChange={(v) => setV("einzahlungS3aP2", v)} suffix="CHF/J" /></Row>}
    <div style={{ fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--ink-3)", letterSpacing: ".08em", textTransform: "uppercase", paddingTop: 12 }}>3b · freie Vorsorge</div>
    <Row label={`Rückkaufswert / Wert${isPaar ? " P1" : ""}`} help="Lebensvers., Sparpläne 3b">
      <NumInput value={s.vorsorge.s3bP1} onChange={(v) => setV("s3bP1", v)} />
    </Row>
    {isPaar && <Row label="Rückkaufswert / Wert P2"><NumInput value={s.vorsorge.s3bP2} onChange={(v) => setV("s3bP2", v)} /></Row>}
  </>;
}

function SecFirma({ s, set }) {
  const setF = (k, v) => set({ firma: { ...s.firma, [k]: v } });
  return <>
    <Row label="Selbständigkeit / Firmenanteile">
      <Seg value={s.firma.vorhanden ? "ja" : "nein"} onChange={(v) => setF("vorhanden", v === "ja")} options={[
        { value: "nein", label: "Keine" }, { value: "ja", label: "Vorhanden" }
      ]} />
    </Row>
    {s.firma.vorhanden && <>
      <Row label="Firmenname"><input className="input is-grow" value={s.firma.name} onChange={(e) => setF("name", e.target.value)} /></Row>
      <Row label="Beteiligung">
        <input className="input mono" type="number" min="0" max="100" style={{ width: 80 }}
          value={s.firma.anteilProzent} onChange={(e) => setF("anteilProzent", parseInt(e.target.value || "0", 10))} />
        <span style={{ fontSize: 11, color: "var(--ink-3)" }}>%</span>
      </Row>
      <Row label="Marktwert / Goodwill" help="Best-Effort-Schätzung"><NumInput value={s.firma.marktwert} onChange={(v) => setF("marktwert", v)} /></Row>
      <Row label="Plan bei Pensionierung">
        <Seg value={s.firma.liquidation} onChange={(v) => setF("liquidation", v)} options={[
          { value: "verkauf", label: "Verkauf" }, { value: "nachfolge", label: "Nachfolge" }, { value: "liquidation", label: "Liquidation" }, { value: "offen", label: "Offen" }
        ]} />
      </Row>
    </>}
  </>;
}

function SecNachlass({ s, set }) {
  const setN = (k, v) => set({ nachlass: { ...s.nachlass, [k]: v } });
  const present = [s.nachlass.testament, s.nachlass.ehevertrag, s.nachlass.vorsorgeauftrag, s.nachlass.patientenverfuegung].filter(Boolean).length;
  return <>
    <div className="hint-banner" style={{ marginBottom: 4 }}>
      <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6.5" stroke="currentColor" strokeWidth="1.3"/><circle cx="8" cy="5" r="0.9" fill="currentColor"/><path d="M8 7.5v4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/></svg>
      <span>Cuira prüft die Nachlassdokumente im Termin und empfiehlt bei Lücken einen Notar-Partner. <strong style={{ fontWeight: 500 }}>{present} von 4</strong> vorhanden.</span>
    </div>
    <Row label="Testament" help="Eigenhändig oder öffentlich beurkundet">
      <Check checked={s.nachlass.testament} onChange={(v) => setN("testament", v)} label={s.nachlass.testament ? "Vorhanden" : "Fehlt"} />
    </Row>
    <Row label="Ehevertrag" help="Güterstand-Regelung">
      <Check checked={s.nachlass.ehevertrag} onChange={(v) => setN("ehevertrag", v)} label={s.nachlass.ehevertrag ? "Vorhanden" : "Fehlt"} />
    </Row>
    <Row label="Vorsorgeauftrag" help="Bei Urteilsunfähigkeit">
      <Check checked={s.nachlass.vorsorgeauftrag} onChange={(v) => setN("vorsorgeauftrag", v)} label={s.nachlass.vorsorgeauftrag ? "Vorhanden" : "Fehlt"} />
    </Row>
    <Row label="Patientenverfügung" help="Medizinische Willensäusserung">
      <Check checked={s.nachlass.patientenverfuegung} onChange={(v) => setN("patientenverfuegung", v)} label={s.nachlass.patientenverfuegung ? "Vorhanden" : "Fehlt"} />
    </Row>
    <Row label="Erbteilung" help="Gewünschte Verteilung">
      <Seg value={s.nachlass.erbteilung} onChange={(v) => setN("erbteilung", v)} options={[
        { value: "gesetzlich", label: "Gesetzlich" }, { value: "meistbeguenstigung", label: "Meistbegünstigung" }, { value: "individuell", label: "Individuell" }
      ]} />
    </Row>
    <Row label="3a-Begünstigung" help="Gem. BVV3 Art. 2 — eingeschränkter Kreis">
      <input className="input is-grow" value={s.nachlass.begunstigte3a} onChange={(e) => setN("begunstigte3a", e.target.value)} placeholder="z.B. Ehepartner, dann Kinder" />
    </Row>
    <Row label="Notiz Nachlass" help="Besonderheiten, offene Fragen">
      <textarea className="textarea" style={{ flex: 1 }} value={s.nachlass.notiz} onChange={(e) => setN("notiz", e.target.value)} placeholder="z.B. Patchwork-Situation, Pflichtteilsverzicht geplant…" />
    </Row>
  </>;
}

function SecBudget({ s, set }) {
  const setB = (k, v) => set({ budget: { ...s.budget, [k]: v } });
  const total = (s.budget.einkP1 || 0) + (s.fallart === "paar" ? (s.budget.einkP2 || 0) : 0);
  return <>
    <Row label={`${s.fallart === "paar" ? "Bruttoeinkommen P1" : "Bruttoeinkommen"}`} help="13. Monatslohn inkl., ohne Bonus">
      <NumInput value={s.budget.einkP1} onChange={(v) => setB("einkP1", v)} suffix="CHF/J" />
    </Row>
    {s.fallart === "paar" && <Row label="Bruttoeinkommen P2">
      <NumInput value={s.budget.einkP2} onChange={(v) => setB("einkP2", v)} suffix="CHF/J" />
    </Row>}
    {s.fallart === "paar" && <Row label="Total Brutto">
      <span className="mono" style={{ color: "var(--ink-2)", fontSize: 13 }}>{fmt(total)} CHF/J</span>
    </Row>}
    <Row label="Heutige Lebenskosten" help="Ohne PK-Beiträge & Steuern">
      <NumInput value={s.budget.ausgaben} onChange={(v) => setB("ausgaben", v)} suffix="CHF/J" />
    </Row>
    <Row label="Wunschausgaben Pension" help="Lebenshaltung pro Jahr in der Pensionsphase">
      <NumInput value={s.budget.wunschPension} onChange={(v) => setB("wunschPension", v)} suffix="CHF/J" />
    </Row>
  </>;
}

function SecDocs({ s, set }) {
  const setD = (k, v) => set({ docs: { ...s.docs, [k]: v } });
  const isPaar = s.fallart === "paar";
  return <>
    <div className="hint-banner" style={{ marginBottom: 4 }}>
      <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6.5" stroke="currentColor" strokeWidth="1.3" /><circle cx="8" cy="5" r="0.9" fill="currentColor" /><path d="M8 7.5v4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" /></svg>
      <span>Dokumente sind optional, beschleunigen aber den Cuira-Termin um ca. 30 Min. Mindestens ein Vorsorgeausweis ist empfohlen.</span>
    </div>
    <div className="uploads">
      <Upload doc={s.docs.vorsorgeausweisP1} onAttach={(d) => setD("vorsorgeausweisP1", d)}
        label="Vorsorgeausweis PK · P1" sub="PDF · max 5 MB · drag or click" />
      {isPaar && <Upload doc={s.docs.vorsorgeausweisP2} onAttach={(d) => setD("vorsorgeausweisP2", d)}
        label="Vorsorgeausweis PK · P2" sub="PDF · max 5 MB · drag or click" />}
      <Upload doc={s.docs.s3aP1} onAttach={(d) => setD("s3aP1", d)}
        label="3a-Auszüge · P1" sub="Konto- & Depot-Auszüge bündeln" />
      {isPaar && <Upload doc={s.docs.s3aP2} onAttach={(d) => setD("s3aP2", d)}
        label="3a-Auszüge · P2" sub="Konto- & Depot-Auszüge bündeln" />}
      <Upload doc={s.docs.steuerklr} onAttach={(d) => setD("steuerklr", d)}
        label="Steuererklärung — letztes Jahr" sub="Vollständig oder Kopie genügt" />
    </div>
  </>;
}

function SecUebergabe({ s, set, comp, onSubmit }) {
  const sumIncome = (s.budget.einkP1 || 0) + (s.fallart === "paar" ? (s.budget.einkP2 || 0) : 0);
  const sumPK = (s.vorsorge.pkP1 || 0) + (s.fallart === "paar" ? (s.vorsorge.pkP2 || 0) : 0);
  const sum3a = (s.vorsorge.s3aP1 || 0) + (s.fallart === "paar" ? (s.vorsorge.s3aP2 || 0) : 0);
  const sumImmo = s.immo.reduce((a, i) => a + (i.verkehrswert - i.hypothek), 0);
  const sumLiquid = s.vermoegen.reduce((a, v) => a + v.saldo, 0);
  return <>
    <div className="hint-banner">
      <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M3 8.5l3 3 7-7" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>
      <span>Vor der Übergabe an Cuira: prüfen Sie die Zusammenfassung rechts. Cuira übernimmt ab Übergabe die Federführung — Sie erhalten Status-Updates per E-Mail.</span>
    </div>
    <Row label="Quick-Summary" help="Auto-generiert aus den Eingaben">
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, flex: 1 }}>
        <SumKpi label="Bruttoeinkommen" value={sumIncome} />
        <SumKpi label="PK-Saldo total" value={sumPK} />
        <SumKpi label="3a-Saldo total" value={sum3a} />
        <SumKpi label="Liquidität" value={sumLiquid} />
        <SumKpi label="Immo-Eigenkapital" value={sumImmo} />
        <SumKpi label="Wunschausgaben Pension" value={s.budget.wunschPension} />
      </div>
    </Row>
    <Row label="Vorab-Empfehlung" help="Sie sehen das, Cuira sieht das auch">
      <Seg value={s.priority === "dringend" ? "tief" : s.priority === "hoch" ? "mittel" : "hoch"} onChange={() => {}} options={[
        { value: "tief", label: "Wenig Optimierungspotential" },
        { value: "mittel", label: "Mittlere Komplexität" },
        { value: "hoch", label: "Hohes Beratungspotential" },
      ]} />
    </Row>
    <Row label="Notiz an Cuira" help="Was sollte der Cuira-Berater zuerst wissen?">
      <textarea className="textarea" style={{ flex: 1 }} placeholder="z. B. Mandant interessiert sich primär für Frühpensionierung mit 62, hat Fragen zu Sperrfrist nach Einkauf 2024…"
        value={s.notiz} onChange={(e) => set({ notiz: e.target.value })} />
    </Row>
    <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, paddingTop: 8 }}>
      <button className="btn btn-secondary">PDF-Vorschau</button>
      <button className="btn btn-primary" disabled={!Object.values(comp).every(Boolean)} onClick={onSubmit}>
        An Cuira übergeben
        <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M3 8h10m0 0L9 4m4 4l-4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>
      </button>
    </div>
  </>;
}

function SumKpi({ label, value }) {
  return (
    <div style={{ background: "var(--bg-2)", borderRadius: 7, padding: "8px 10px", display: "flex", flexDirection: "column", gap: 2 }}>
      <div style={{ fontSize: 10, color: "var(--ink-3)", fontFamily: "var(--font-mono)", letterSpacing: ".08em", textTransform: "uppercase" }}>{label}</div>
      <div style={{ fontSize: 14, fontWeight: 500, color: "var(--cuira)", fontFamily: "var(--font-mono)" }}>{fmt(value) || "—"}</div>
    </div>
  );
}

// === App ===
function App() {
  const [s, setS] = useState(INITIAL);
  const [active, setActive] = useState("stamm");
  const [submitted, setSubmitted] = useState(false);
  const refMap = useRef({});
  const set = (patch) => setS((cur) => ({ ...cur, ...patch }));
  const comp = useMemo(() => completion(s), [s]);

  // Scroll spy
  useEffect(() => {
    const formEl = document.querySelector(".form");
    if (!formEl) return;
    const onScroll = () => {
      const top = formEl.scrollTop + 80;
      let cur = "stamm";
      for (const sec of SECTIONS) {
        const el = refMap.current[sec.id];
        if (el && el.offsetTop <= top) cur = sec.id;
      }
      setActive(cur);
    };
    formEl.addEventListener("scroll", onScroll);
    return () => formEl.removeEventListener("scroll", onScroll);
  }, []);

  const jump = (id) => {
    const el = refMap.current[id];
    if (el) {
      const formEl = document.querySelector(".form");
      formEl.scrollTo({ top: el.offsetTop - 16, behavior: "smooth" });
    }
  };

  const onSubmit = () => setSubmitted(true);

  const groups = {};
  SECTIONS.forEach(sec => { (groups[sec.group] ||= []).push(sec); });

  return (
    <>
      <header className="topbar">
        <a className="logo" href="#"><span className="logo-mark"></span><span>cuira</span></a>
        <span className="mode-pill"><span className="dot"></span>Affiliate · Erfassung</span>
        <div className="topbar-divider"></div>
        <div className="partner">
          <span className="partner-avatar">{s.partner.initials}</span>
          <span><strong style={{ color: "var(--ink)", fontWeight: 500 }}>{s.partner.name}</strong> · {s.partner.firma}</span>
        </div>
        <div className="topbar-spacer"></div>
        <div className="topbar-search">
          <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><circle cx="7" cy="7" r="5" stroke="currentColor" strokeWidth="1.4" /><path d="M11 11l3 3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" /></svg>
          <span>Mandanten suchen…</span>
          <span style={{ marginLeft: "auto", fontFamily: "var(--font-mono)", fontSize: 10, color: "var(--ink-4)" }}>⌘K</span>
        </div>
        <div className="save-status"><span className="dot"></span>Gespeichert · 12:42</div>
        <a href="Cuira Pensionsplanung.html" className="topbar-icon-btn" title="Pro-Modus" style={{ textDecoration: "none" }}>
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M3 8h10m0 0L9 4m4 4l-4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </a>
      </header>
      <div className="shell">
        <nav className="nav">
          {Object.entries(groups).map(([g, list]) => (
            <div key={g} className="nav-block">
              <div className="nav-eyebrow">{g}</div>
              {list.map(sec => (
                <button key={sec.id} onClick={() => jump(sec.id)}
                  className={`nav-item ${active === sec.id ? "is-active" : ""} ${comp[sec.id] ? "is-done" : ""}`}>
                  <span className="nav-num">{comp[sec.id] && active !== sec.id ? "✓" : sec.num}</span>
                  <span>{sec.label}</span>
                  <span className="nav-fill">{comp[sec.id] ? "OK" : "—"}</span>
                </button>
              ))}
            </div>
          ))}
        </nav>

        <div className="form">
          <div className="hint-banner">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="6.5" stroke="currentColor" strokeWidth="1.3" /><circle cx="8" cy="5" r="0.9" fill="currentColor" /><path d="M8 7.5v4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" /></svg>
            <div>
              <strong style={{ fontWeight: 500 }}>Affiliate-Modus</strong> — schlanker Daten-Intake. Tragen Sie ein, was Sie wissen; offene Felder klärt der Cuira-Berater im Termin. Provision wird nach Erstgespräch ausbezahlt.
            </div>
          </div>

          <Section id="personen" num="01" title="Personen" meta={s.fallart === "paar" ? "Zwei Personen + Adresse" : "Eine Person + Adresse"} isActive={active === "personen"} refMap={refMap}>
            <PersonRows p={s.client.p1} label={s.fallart === "paar" ? "P1" : "Mandant"}
              onChange={(v) => set({ client: { ...s.client, p1: v } })} />
            {s.fallart === "paar" && (<>
              <div style={{ height: 4, borderTop: "1px dashed var(--border)" }}></div>
              <PersonRows p={s.client.p2} label="P2" onChange={(v) => set({ client: { ...s.client, p2: v } })} />
            </>)}
            <div style={{ height: 4, borderTop: "1px dashed var(--border)", marginTop: 6 }}></div>
            <SecStamm s={s} set={set} />
          </Section>

          <Section id="ziele" num="02" title="Ziele & Wünsche" meta="Pensionsalter · Bezugsart" isActive={active === "ziele"} refMap={refMap}>
            <SecZiele s={s} set={set} />
          </Section>

          <Section id="budget" num="03" title="Budget" meta="Einnahmen & Ausgaben" isActive={active === "budget"} refMap={refMap}>
            <SecBudget s={s} set={set} />
          </Section>

          <Section id="ahv" num="04" title="1. Säule (AHV)" meta="Rentenfaktor & Lücken" isActive={active === "ahv"} refMap={refMap}>
            <SecAhv s={s} set={set} />
          </Section>

          <Section id="pk" num="05" title="Pensionskasse — 2. Säule" meta="PK · FZ · Einkäufe" isActive={active === "pk"} refMap={refMap}>
            <SecPk s={s} set={set} />
          </Section>

          <Section id="s3" num="06" title="3. Säule" meta="3a + 3b" isActive={active === "s3"} refMap={refMap}>
            <SecS3 s={s} set={set} />
          </Section>

          <Section id="vermoegen" num="07" title="Vermögen" meta="Konten & Depots" isActive={active === "vermoegen"} refMap={refMap}>
            <VermoegenList items={s.vermoegen} onChange={(v) => set({ vermoegen: v })} />
          </Section>

          <Section id="immo" num="08" title="Immobilien" meta="Liegenschaften & Hypotheken" isActive={active === "immo"} refMap={refMap}>
            <ImmoList items={s.immo} onChange={(v) => set({ immo: v })} />
          </Section>

          <Section id="firma" num="09" title="Firma" meta="Selbständigkeit · optional" isActive={active === "firma"} refMap={refMap}>
            <SecFirma s={s} set={set} />
          </Section>

          <Section id="nachlass" num="10" title="Nachlass" meta="Vorsorge & Erben" isActive={active === "nachlass"} refMap={refMap}>
            <SecNachlass s={s} set={set} />
          </Section>

          <Section id="docs" num="11" title="Dokumente" meta="Beschleunigt den Termin" isActive={active === "docs"} refMap={refMap}>
            <SecDocs s={s} set={set} />
          </Section>

          <Section id="uebergabe" num="12" title="Notiz & Senden" meta="Letzter Schritt" isActive={active === "uebergabe"} refMap={refMap}>
            <SecUebergabe s={s} set={set} comp={comp} onSubmit={onSubmit} />
          </Section>
        </div>

        <Handoff s={s} set={set} comp={comp} onSubmit={onSubmit} />
      </div>

      {submitted && (
        <div className="submit-overlay" onClick={() => setSubmitted(false)}>
          <div className="submit-card" onClick={(e) => e.stopPropagation()}>
            <div className="submit-icon">✓</div>
            <h2 style={{ margin: 0, fontSize: 22, fontWeight: 500 }}>Übergabe erfolgreich</h2>
            <p style={{ margin: 0, fontSize: 14, color: "var(--ink-2)", lineHeight: 1.5 }}>
              Mandant <strong style={{ color: "var(--ink)" }}>{s.client.p1.vorname} {s.client.p1.nachname}</strong> wurde an Cuira übergeben.
              Sie erhalten innert 24 Std. eine Bestätigung mit dem Cuira-Berater-Kontakt — Provision von <span className="mono">CHF 1'200</span> wird nach Erstgespräch verbucht.
            </p>
            <div style={{ display: "flex", gap: 8, marginTop: 6 }}>
              <button className="btn btn-secondary" onClick={() => setSubmitted(false)}>Schliessen</button>
              <button className="btn btn-primary" onClick={() => { setSubmitted(false); setS(INITIAL); }}>Neuen Mandanten erfassen</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
