/* global React */
const { useState: pS, useEffect: pE, useMemo: pM, useRef: pR, useCallback: pC } = React;

// === ⌘K Command Palette ===
const CMD_FIELDS = [
  { id: "fallart", block: 1, label: "Fallart", sub: "Einzel / Paar / Konkubinat", kw: "fallart einzel paar konkubinat" },
  { id: "geb1", block: 1, label: "Geburtsdatum Person 1", sub: "Block 1 · Personen", kw: "geburt person 1" },
  { id: "geb2", block: 1, label: "Geburtsdatum Person 2", sub: "Block 1 · Personen", kw: "geburt person 2" },
  { id: "adresse", block: 1, label: "Adresse / Kanton", sub: "Block 1 · steuerlich relevant", kw: "adresse plz ort kanton" },
  { id: "bezalter1", block: 2, label: "Bezugsalter Person 1", sub: "Block 2 · Wunsch-Pensionsalter", kw: "pensionsalter bezugsalter wunsch ahv vorbezug aufschub" },
  { id: "bezalter2", block: 2, label: "Bezugsalter Person 2", sub: "Block 2 · Wunsch-Pensionsalter", kw: "pensionsalter bezugsalter person 2" },
  { id: "einmal", block: 2, label: "Einmalige Ausgaben", sub: "Renovation, Auto, Hochzeit", kw: "einmalig ausgaben renovation auto hochzeit" },
  { id: "einkP1", block: 3, label: "Einkommen Person 1", sub: "Block 3 · Budget", kw: "einkommen lohn budget" },
  { id: "einkP2", block: 3, label: "Einkommen Person 2", sub: "Block 3 · Budget", kw: "einkommen lohn person 2" },
  { id: "ausgaben", block: 3, label: "Ausgaben heute", sub: "Lebenshaltungskosten p.a.", kw: "ausgaben lebenshaltung budget" },
  { id: "wunschverb", block: 3, label: "Wunschverbrauch ab Pension", sub: "Block 3 · meist 75–85 %", kw: "wunschverbrauch pension ausgaben" },
  { id: "ahv1", block: 4, label: "AHV-Rentenfaktor Person 1", sub: "Beitragsjahre / Lücken", kw: "ahv rentenfaktor beitrag" },
  { id: "ahv2", block: 4, label: "AHV-Rentenfaktor Person 2", sub: "Beitragsjahre / Lücken", kw: "ahv rentenfaktor person 2" },
  { id: "pkagh1", block: 5, label: "Altersguthaben PK Person 1", sub: "Block 5 · vom PK-Ausweis", kw: "altersguthaben bvg pensionskasse pk-ausweis" },
  { id: "pkbez1", block: 5, label: "PK-Altersguthaben bei Bezug P1", sub: "Block 5 · für Berechnung", kw: "altersguthaben bezug projektion pk" },
  { id: "uws1", block: 5, label: "Umwandlungssatz Person 1", sub: "PK-Reglement", kw: "umwandlungssatz uws bvg" },
  { id: "bezpref1", block: 5, label: "Bezugspräferenz Person 1", sub: "Rente / Kapital / Mischung", kw: "bezugspraeferenz rente kapital mischung" },
  { id: "einkauf1", block: 5, label: "PK-Einkäufe Person 1", sub: "freiwillige Einzahlungen", kw: "einkauf bvg pk einzahlung steuer" },
  { id: "fz1", block: 5, label: "Freizügigkeit Person 1", sub: "aus früheren Anstellungen", kw: "freizuegigkeit fz konto" },
  { id: "s3a1", block: 6, label: "3a-Konto Person 1", sub: "Block 6 · 3. Säule", kw: "3a saeule3 saeule3a" },
  { id: "s3b1", block: 6, label: "3b-Versicherung", sub: "Block 6 · Rückkaufswert", kw: "3b saeule3b versicherung rueckkauf" },
  { id: "konten", block: 7, label: "Konten & Depots", sub: "Block 7 · Vermögen", kw: "konto depot bank wertschriften" },
  { id: "immo", block: 8, label: "Immobilien", sub: "Verkehrswert, Hypotheken", kw: "immobilie liegenschaft hypothek wohneigentum" },
  { id: "hyp", block: 8, label: "Hypotheken-Tranchen", sub: "Block 8 · Belehnung & Ablauf", kw: "hypothek tranche zins ablauf belehnung" },
  { id: "firma", block: 9, label: "Firma / Selbständigkeit", sub: "Block 9", kw: "firma selbstaendig beteiligung" },
  { id: "testament", block: 10, label: "Testament / Vorsorgeauftrag", sub: "Block 10 · Nachlass", kw: "testament ehevertrag vorsorgeauftrag nachlass" },
];

const CMD_ACTIONS = [
  { id: "scenario", icon: "B", label: "Szenario B starten", sub: "Schnappschuss als Vergleich", kw: "szenario variante b vergleich plan" },
  { id: "fullscreen", icon: "⤢", label: "Live-Plan im Vollbild", sub: "für Screenshare", kw: "vollbild fullscreen praesentation" },
  { id: "pdf", icon: "📄", label: "PDF-Export", sub: "Auswertung als PDF", kw: "pdf print export" },
  { id: "inflation", icon: "%", label: "Inflation-Toggle", sub: "in heutiger Kaufkraft", kw: "inflation kaufkraft" },
];

window.CmdK = function CmdK({ open, onClose, onJump, onAction }) {
  const [q, setQ] = pS("");
  const [idx, setIdx] = pS(0);
  const inp = pR();

  pE(() => { if (open) { setQ(""); setIdx(0); setTimeout(() => inp.current?.focus(), 30); } }, [open]);

  const items = pM(() => {
    const ql = q.toLowerCase().trim();
    const score = (item) => {
      const hay = (item.label + " " + (item.sub || "") + " " + (item.kw || "")).toLowerCase();
      if (!ql) return 1;
      if (hay.includes(ql)) return 2;
      // fuzzy: each char in q must appear in order
      let i = 0;
      for (const c of ql) {
        const p = hay.indexOf(c, i);
        if (p < 0) return 0;
        i = p + 1;
      }
      return 1;
    };
    const fields = CMD_FIELDS.map(f => ({ ...f, type: "field", _s: score(f) })).filter(f => f._s > 0);
    const actions = CMD_ACTIONS.map(a => ({ ...a, type: "action", _s: score(a) })).filter(a => a._s > 0);
    return { fields: fields.slice(0, 8), actions: actions.slice(0, 4) };
  }, [q]);

  const flat = pM(() => [...items.actions, ...items.fields], [items]);

  pE(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") { onClose(); }
      else if (e.key === "ArrowDown") { e.preventDefault(); setIdx(i => Math.min(flat.length - 1, i + 1)); }
      else if (e.key === "ArrowUp") { e.preventDefault(); setIdx(i => Math.max(0, i - 1)); }
      else if (e.key === "Enter") {
        e.preventDefault();
        const it = flat[idx];
        if (!it) return;
        if (it.type === "field") onJump(it);
        else onAction(it.id);
        onClose();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, flat, idx]);

  if (!open) return null;
  return (
    <div className="cmdk-backdrop" onClick={onClose}>
      <div className="cmdk" onClick={(e) => e.stopPropagation()}>
        <div className="cmdk-input">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><circle cx="7" cy="7" r="5" stroke="var(--ink-3)" strokeWidth="1.4" /><path d="M11 11l3 3" stroke="var(--ink-3)" strokeWidth="1.4" strokeLinecap="round" /></svg>
          <input ref={inp} placeholder="Frage, Feld, Block oder Aktion suchen…" value={q} onChange={(e) => { setQ(e.target.value); setIdx(0); }} />
          <span className="cmdk-row-key">esc</span>
        </div>
        <div className="cmdk-list">
          {flat.length === 0 && <div className="cmdk-empty">Nichts gefunden für „{q}"</div>}
          {items.actions.length > 0 && <div className="cmdk-group-label">Aktionen</div>}
          {items.actions.map((a, i) => (
            <div key={a.id} className={`cmdk-row ${idx === i ? "is-active" : ""}`} onMouseEnter={() => setIdx(i)} onClick={() => { onAction(a.id); onClose(); }}>
              <span className="cmdk-row-icon">{a.icon}</span>
              <span className="cmdk-row-main">
                <div className="cmdk-row-title">{a.label}</div>
                <div className="cmdk-row-sub">{a.sub}</div>
              </span>
            </div>
          ))}
          {items.fields.length > 0 && <div className="cmdk-group-label">Felder</div>}
          {items.fields.map((f, i) => {
            const idxI = items.actions.length + i;
            return (
              <div key={f.id} className={`cmdk-row ${idx === idxI ? "is-active" : ""}`} onMouseEnter={() => setIdx(idxI)} onClick={() => { onJump(f); onClose(); }}>
                <span className="cmdk-row-icon">{f.block}</span>
                <span className="cmdk-row-main">
                  <div className="cmdk-row-title">{f.label}</div>
                  <div className="cmdk-row-sub">{f.sub}</div>
                </span>
                <span className="cmdk-row-key">↵</span>
              </div>
            );
          })}
        </div>
        <div className="cmdk-foot">
          <span><span className="cmdk-row-key">↑↓</span> wählen</span>
          <span><span className="cmdk-row-key">↵</span> springen</span>
          <span><span className="cmdk-row-key">esc</span> schliessen</span>
        </div>
      </div>
    </div>
  );
};

// === Resizer ===
window.useResize = function useResize(initial = 400, min = 320, max = 560) {
  const [w, setW] = pS(initial);
  const draggingRef = pR(false);
  pE(() => {
    const onMove = (e) => {
      if (!draggingRef.current) return;
      const next = window.innerWidth - e.clientX;
      setW(Math.max(min, Math.min(max, next)));
    };
    const onUp = () => { draggingRef.current = false; document.body.style.cursor = ""; document.body.style.userSelect = ""; };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => { window.removeEventListener("mousemove", onMove); window.removeEventListener("mouseup", onUp); };
  }, [min, max]);
  const onDown = () => {
    draggingRef.current = true;
    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";
  };
  return [w, onDown, draggingRef];
};

// === Waterfall (Heute → Pension breakdown) ===
window.Waterfall = function Waterfall({ state, reihe }) {
  const j1 = parseInt(state.person1.geburtsdatum.slice(0, 4), 10);
  const pj = j1 + state.ziele.bezugsalterP1;
  const heute = reihe[0]?.vermoegenNetto || 0;
  const pension = reihe.find(r => r.jahr === pj)?.vermoegenNetto || heute;

  // Decompose contributions between today and pension
  const jahre = pj - reihe[0].jahr;
  const erwerb = (state.budget.einkommenP1 + (state.fallart === "paar" ? state.budget.einkommenP2 : 0)) * jahre;
  const ausgaben = state.budget.ausgabenTotal * jahre;
  const steuern = (reihe.slice(0, jahre).reduce((a, r) => a + r.steuern, 0));
  const rendite = pension - heute - (erwerb - ausgaben - steuern);

  const steps = [
    { label: "Heute", value: heute, type: "anchor" },
    { label: "Erwerb", value: erwerb, type: "pos" },
    { label: "Lebenskosten", value: -ausgaben, type: "neg" },
    { label: "Steuern", value: -steuern, type: "neg" },
    { label: "PK + Rendite", value: rendite, type: "pos" },
    { label: "Bei Pension", value: pension, type: "anchor", target: true },
  ];

  // Compute running totals & y positions
  const w = 720, h = 240, padL = 60, padR = 16, padT = 18, padB = 32;
  let acc = 0;
  const bars = steps.map((s, i) => {
    if (s.type === "anchor") {
      const v = s.value;
      acc = v;
      return { ...s, from: 0, to: v };
    }
    const from = acc;
    acc += s.value;
    return { ...s, from, to: acc };
  });
  const allVals = bars.flatMap(b => [b.from, b.to, 0]);
  const minY = Math.min(...allVals);
  const maxY = Math.max(...allVals);
  const sy = (v) => padT + (1 - (v - minY) / Math.max(1, maxY - minY)) * (h - padT - padB);
  const colW = (w - padL - padR) / steps.length;
  const barW = colW * 0.62;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <div className="card-eyebrow">Was passiert zwischen heute und Pensionsjahr {pj}?</div>
      <svg viewBox={`0 0 ${w} ${h}`} width="100%" height="auto" style={{ display: "block" }}>
        {/* zero line */}
        <line x1={padL} x2={w - padR} y1={sy(0)} y2={sy(0)} stroke="var(--border)" strokeDasharray="2 3" />
        {/* y axis labels */}
        <text x={padL - 6} y={sy(maxY) + 4} className="axis-tick" textAnchor="end">{fmtCHF(maxY, { compact: true })}</text>
        <text x={padL - 6} y={sy(0) + 4} className="axis-tick" textAnchor="end">0</text>
        {bars.map((b, i) => {
          const x = padL + i * colW + (colW - barW) / 2;
          const top = Math.min(b.from, b.to);
          const bot = Math.max(b.from, b.to);
          const y = sy(bot);
          const height = Math.max(2, sy(top) - sy(bot));
          const fill = b.type === "anchor" ? "var(--cuira-deep)" : b.type === "pos" ? "var(--pos)" : "var(--neg)";
          const isAnchor = b.type === "anchor";
          return (
            <g key={i}>
              {!isAnchor && i > 0 && bars[i - 1] && (
                <line x1={padL + (i - 1) * colW + (colW + barW) / 2} x2={x} y1={sy(b.from)} y2={sy(b.from)} stroke="var(--border-strong)" strokeDasharray="2 3" />
              )}
              <rect x={x} y={y} width={barW} height={height} fill={fill} rx={3} className="waterfall-bar" opacity={isAnchor ? 1 : 0.85} />
              <text x={x + barW / 2} y={y - 6} className="axis-tick" textAnchor="middle" fill="var(--ink-2)" style={{ fontSize: 11 }}>
                {(b.value >= 0 ? "+" : "−") + fmtCHF(Math.abs(b.value), { compact: true }).replace("CHF ", "")}
              </text>
              <text x={x + barW / 2} y={h - 14} className="axis-tick" textAnchor="middle" fill="var(--ink-2)" style={{ fontSize: 11, fontWeight: 500 }}>{b.label}</text>
              {isAnchor && (
                <text x={x + barW / 2} y={h - 2} className="axis-tick" textAnchor="middle" fill="var(--ink-3)">{i === 0 ? reihe[0].jahr : pj}</text>
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
};
