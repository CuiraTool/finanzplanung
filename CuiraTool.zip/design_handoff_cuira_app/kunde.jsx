/* global React, ReactDOM */
const { useState, useEffect, useMemo, useRef } = React;

// === Helpers ===
const fmt = (n) => {
  if (n == null || isNaN(n)) return "—";
  const abs = Math.abs(n);
  const sign = n < 0 ? "−" : "";
  return `${sign}CHF ${Math.round(abs).toLocaleString("de-CH").replace(/,/g, "'")}`;
};
const fmtCompact = (n) => {
  if (n == null || isNaN(n)) return "—";
  const abs = Math.abs(n);
  const sign = n < 0 ? "−" : "";
  if (abs >= 1_000_000) return `${sign}CHF ${(abs / 1_000_000).toFixed(2).replace(".", ".")} Mio.`;
  if (abs >= 1_000) return `${sign}CHF ${(abs / 1_000).toFixed(0)}'${String(abs % 1000).padStart(3, "0").slice(0,3)}`.replace(/'(\d{1,2})$/, "'$1");
  return fmt(n);
};

const HEUTE = 2026;

// === Engine — simplified projection for B2C ===
function project(s) {
  const startAge1 = HEUTE - s.geb1;
  const startAge2 = s.paar ? HEUTE - s.geb2 : null;
  const ret1 = s.retire1;
  const ret2 = s.paar ? s.retire2 : null;
  const yearRet1 = s.geb1 + ret1;
  const yearRet2 = s.paar ? s.geb2 + ret2 : null;
  const endYear = HEUTE + 60;

  let wealth = s.wCash + s.wInvest + (s.hasImmo ? Math.max(0, s.immoValue - s.immoMortgage) : 0) + s.pk1 + (s.paar ? s.pk2 : 0) + s.s3a1 + (s.paar ? s.s3a2 : 0);
  const series = [];
  let depleteYear = null;

  for (let y = HEUTE; y <= endYear; y++) {
    const a1 = y - s.geb1;
    const a2 = s.paar ? y - s.geb2 : null;
    const isRetired1 = a1 >= ret1;
    const isRetired2 = s.paar ? a2 >= ret2 : true;
    const bothRetired = isRetired1 && isRetired2;

    // Income
    let income = 0;
    if (!isRetired1) income += s.income1;
    if (s.paar && !isRetired2) income += s.income2;

    // Pension income
    let ahv = 0;
    if (a1 >= 65) ahv += 30240;
    if (s.paar && a2 >= 65) ahv += 30240;
    if (s.paar && a1 >= 65 && a2 >= 65) ahv = Math.min(ahv, 45360);

    let pkRente = 0;
    if (isRetired1) pkRente += s.pk1Rente;
    if (s.paar && isRetired2) pkRente += s.pk2Rente;

    // Spending
    const expenses = bothRetired ? s.spendRet : s.spendNow;
    const tax = Math.round((income + ahv + pkRente) * 0.14 + Math.max(0, wealth) * 0.003);

    const out = expenses + tax;
    const inFlow = income + ahv + pkRente;
    const saldo = inFlow - out;

    // Growth on positive wealth
    const growth = wealth > 0 ? wealth * 0.025 : 0;
    wealth = wealth + saldo + growth;

    if (wealth < 0 && depleteYear == null) depleteYear = y;
    series.push({ year: y, age1: a1, age2: a2, wealth, income, ahv, pkRente, expenses, saldo, isRetired: bothRetired });
  }

  const atRet = series.find(r => r.year === Math.max(yearRet1, yearRet2 || 0));
  const at85 = series.find(r => r.year === s.geb1 + 85) || series[series.length - 1];

  // Verdict
  let verdict = "good";
  let verdictTitle = "Ihr Plan reicht komfortabel";
  let verdictSub = "Ihr Vermögen reicht voraussichtlich bis weit über das Alter 90 hinaus.";
  if (depleteYear != null) {
    const ageAtDeplete = depleteYear - s.geb1;
    if (ageAtDeplete < 80) {
      verdict = "neg";
      verdictTitle = `Eng — Geld reicht bis Alter ${ageAtDeplete}`;
      verdictSub = "Wir empfehlen ein Beratungsgespräch, um den Plan zu schärfen.";
    } else if (ageAtDeplete < 90) {
      verdict = "warn";
      verdictTitle = `Knapp — Geld reicht bis Alter ${ageAtDeplete}`;
      verdictSub = "Mit kleinen Anpassungen lässt sich das Bild verbessern.";
    }
  }

  return { series, depleteYear, atRet, at85, verdict, verdictTitle, verdictSub, retYear: Math.max(yearRet1, yearRet2 || 0) };
}

// === Initial state ===
const INITIAL = {
  paar: true,
  geb1: 1967,
  geb2: 1972,
  retire1: 64,
  retire2: 62,
  income1: 168000,
  income2: 92000,
  spendNow: 142000,
  spendRet: 110000,
  wCash: 85000,
  wInvest: 220000,
  hasImmo: true,
  immoValue: 1200000,
  immoMortgage: 720000,
  pk1: 612000,
  pk2: 218000,
  pk1Rente: 45630,
  pk2Rente: 19440,
  s3a1: 78000,
  s3a2: 24000,
  email: "",
  phone: "",
  name: "",
};

// === Steps definition ===
const STEPS = [
  { id: "welcome", label: "Start" },
  { id: "wer", label: "Sie" },
  { id: "beruf", label: "Beruf" },
  { id: "vermoegen", label: "Vermögen" },
  { id: "vorsorge", label: "Vorsorge" },
  { id: "wunsch", label: "Wunsch" },
  { id: "ergebnis", label: "Ergebnis" },
  { id: "termin", label: "Termin" },
];

// === Components ===

function Topbar({ step, onJumpHome }) {
  return (
    <header className="topbar">
      <button className="logo" onClick={onJumpHome}>
        <span className="logo-mark"></span>
        <span>cuira</span>
      </button>
      <span style={{ color: "var(--ink-3)", fontSize: 13 }}>· Pensionsplaner</span>
      <div className="top-meta">
        <span className="topmeta-hide-sm">Bereits Berater?</span>
        <a href="Cuira Pensionsplanung.html">Pro-Modus</a>
      </div>
    </header>
  );
}

function Progress({ step }) {
  if (step === 0) return null;
  const steps = STEPS.slice(1, -1); // exclude welcome + termin
  const idx = step - 1;
  return (
    <div className="progress-wrap">
      <div className="progress-row">
        {steps.map((s, i) => (
          <div key={s.id} className={`progress-pip ${i < idx ? "is-done" : i === idx ? "is-active" : ""}`} />
        ))}
      </div>
      <div className="progress-meta">
        <span>Schritt {Math.min(idx + 1, steps.length)} von {steps.length}</span>
        <span className="mono">{steps[Math.min(idx, steps.length - 1)]?.label}</span>
      </div>
    </div>
  );
}

function Slider({ value, min, max, step = 1, onChange, format = (v) => v, side, ticks }) {
  const fill = `${((value - min) / (max - min)) * 100}%`;
  return (
    <div className="slider-wrap">
      <div className="slider-value-row">
        <div className="slider-value tnum">{format(value)}</div>
        {side && <div className="slider-value-side">{side}</div>}
      </div>
      <input
        className="slider"
        type="range"
        min={min} max={max} step={step} value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        style={{ "--fill": fill }}
      />
      {ticks && (
        <div className="slider-ticks">
          {ticks.map((t, i) => <span key={i}>{t}</span>)}
        </div>
      )}
    </div>
  );
}

function ModuleCard({ icon, title, desc, value, onChange, suffix = "CHF" }) {
  return (
    <div className="module-card">
      <div className="module-icon">{icon}</div>
      <div className="module-info">
        <div className="module-title">{title}</div>
        <div className="module-desc">{desc}</div>
      </div>
      <input
        className="module-input tnum"
        type="text"
        value={value === 0 ? "" : value.toLocaleString("de-CH").replace(/,/g, "'")}
        placeholder="0"
        onChange={(e) => {
          const raw = e.target.value.replace(/[^0-9]/g, "");
          onChange(raw === "" ? 0 : parseInt(raw, 10));
        }}
      />
      <div className="module-suffix">{suffix}</div>
    </div>
  );
}

function InfoPill({ children }) {
  return (
    <div className="info-pill">
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
        <circle cx="8" cy="8" r="6.5" stroke="currentColor" strokeWidth="1.3" />
        <circle cx="8" cy="5" r="0.9" fill="currentColor" />
        <path d="M8 7.5v4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
      </svg>
      <div>{children}</div>
    </div>
  );
}

// === Step screens ===

function StepWelcome({ onNext }) {
  return (
    <section className="welcome">
      <span className="welcome-eyebrow"><span className="pulse"></span>Live-Berechnung · keine Anmeldung nötig</span>
      <h1 className="welcome-title">Reicht Ihr Geld in der Pension? <em>In 5 Minuten klar.</em></h1>
      <p className="welcome-sub">Beantworten Sie ein paar Fragen — wir zeigen Ihnen sofort, wie Ihr Plan wirklich aussieht. Keine Werbung, keine versteckten Annahmen.</p>
      <div className="welcome-meta">
        <div className="welcome-stat">
          <div className="welcome-stat-num">~5 Min.</div>
          <div className="welcome-stat-label">Bearbeitungszeit</div>
        </div>
        <div className="welcome-stat">
          <div className="welcome-stat-num">8 Schritte</div>
          <div className="welcome-stat-label">Klare Fragen</div>
        </div>
        <div className="welcome-stat">
          <div className="welcome-stat-num">CH-Recht</div>
          <div className="welcome-stat-label">AHV · BVG · 3a</div>
        </div>
      </div>
      <button className="btn btn-primary" onClick={onNext}>
        Los geht's
        <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M3 8h10m0 0L9 4m4 4l-4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>
      </button>
      <div className="side-note"><span className="dot"></span>Ihre Daten bleiben auf diesem Gerät, bis Sie sie senden.</div>
    </section>
  );
}

function StepWer({ s, set }) {
  return (
    <div className="step">
      <div className="step-head">
        <div className="step-eyebrow">Über Sie</div>
        <h2 className="step-title">Planen Sie für sich allein <em>oder zu zweit?</em></h2>
        <p className="step-sub">Bei Paaren rechnen wir mit der gemeinsamen AHV und beiden Pensionskassen.</p>
      </div>
      <div className="choices choices-2">
        <button className={`choice ${!s.paar ? "is-active" : ""}`} onClick={() => set({ paar: false })}>
          <div className="choice-check"></div>
          <div className="choice-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.6" stroke="currentColor" strokeWidth="1.6"/><path d="M5 21c0-3.5 3.1-6 7-6s7 2.5 7 6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>
          </div>
          <div>
            <div className="choice-title">Ich, allein</div>
            <div className="choice-desc">Single, getrennt oder verwitwet — Plan für eine Person.</div>
          </div>
        </button>
        <button className={`choice ${s.paar ? "is-active" : ""}`} onClick={() => set({ paar: true })}>
          <div className="choice-check"></div>
          <div className="choice-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><circle cx="8" cy="8" r="3" stroke="currentColor" strokeWidth="1.6"/><circle cx="16" cy="8" r="3" stroke="currentColor" strokeWidth="1.6"/><path d="M3 21c0-3 2.5-5 5-5s5 2 5 5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/><path d="M11 21c0-3 2.5-5 5-5s5 2 5 5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>
          </div>
          <div>
            <div className="choice-title">Wir, als Paar</div>
            <div className="choice-desc">Verheiratet oder Konkubinat — Plan für beide Personen zusammen.</div>
          </div>
        </button>
      </div>
      <div className="field-grid" style={{ gridTemplateColumns: s.paar ? "1fr 1fr" : "1fr" }}>
        <div className="field">
          <label className="field-label">{s.paar ? "Ihr Geburtsjahr" : "Geburtsjahr"}</label>
          <div className="input-suffix">
            <input className="input is-big tnum" type="number" min="1940" max="2010"
              value={s.geb1} onChange={(e) => set({ geb1: parseInt(e.target.value || "0", 10) })} />
          </div>
          <div className="field-help">{HEUTE - s.geb1} Jahre alt</div>
        </div>
        {s.paar && (
          <div className="field">
            <label className="field-label">Geburtsjahr Partner:in</label>
            <div className="input-suffix">
              <input className="input is-big tnum" type="number" min="1940" max="2010"
                value={s.geb2} onChange={(e) => set({ geb2: parseInt(e.target.value || "0", 10) })} />
            </div>
            <div className="field-help">{HEUTE - s.geb2} Jahre alt</div>
          </div>
        )}
      </div>
    </div>
  );
}

function StepBeruf({ s, set }) {
  return (
    <div className="step">
      <div className="step-head">
        <div className="step-eyebrow">Beruf & Pension</div>
        <h2 className="step-title">Was verdienen Sie heute — und wann <em>wollen Sie aufhören?</em></h2>
        <p className="step-sub">Ihr Bruttoeinkommen pro Jahr (13. Monatslohn inkl., ohne Bonus). Das ordentliche Pensionsalter in der Schweiz ist 65, viele wollen früher.</p>
      </div>
      <div className="field" style={{ gap: 6 }}>
        <label className="field-label">{s.paar ? "Ihr Bruttoeinkommen pro Jahr" : "Bruttoeinkommen pro Jahr"}</label>
        <Slider value={s.income1} min={40000} max={400000} step={2000}
          onChange={(v) => set({ income1: v })}
          format={(v) => fmt(v)}
          side={s.paar ? "Person 1" : null}
          ticks={["40'000", "200'000", "400'000+"]} />
      </div>
      {s.paar && (
        <div className="field" style={{ gap: 6 }}>
          <label className="field-label">Bruttoeinkommen Partner:in pro Jahr</label>
          <Slider value={s.income2} min={0} max={400000} step={2000}
            onChange={(v) => set({ income2: v })}
            format={(v) => fmt(v)}
            ticks={["0", "200'000", "400'000+"]} />
        </div>
      )}
      <div className="field" style={{ gap: 6 }}>
        <label className="field-label">{s.paar ? "Wunsch-Pensionierung — Sie" : "Wunsch-Pensionierung"}</label>
        <Slider value={s.retire1} min={58} max={70} step={1}
          onChange={(v) => set({ retire1: v })}
          format={(v) => `${v} Jahre`}
          side={s.retire1 < 65 ? `Frühpension · ${65 - s.retire1} Jahre vor 65` : s.retire1 === 65 ? "Ordentlich" : `Aufgeschoben · +${s.retire1 - 65}`}
          ticks={["58", "65 ordentlich", "70"]} />
      </div>
      {s.paar && (
        <div className="field" style={{ gap: 6 }}>
          <label className="field-label">Wunsch-Pensionierung — Partner:in</label>
          <Slider value={s.retire2} min={58} max={70} step={1}
            onChange={(v) => set({ retire2: v })}
            format={(v) => `${v} Jahre`}
            ticks={["58", "65", "70"]} />
        </div>
      )}
      <InfoPill>
        Eine Frühpension kostet bei der AHV ca. 6.8% Rente pro Jahr Vorbezug — wir berücksichtigen das automatisch.
      </InfoPill>
    </div>
  );
}

function StepVermoegen({ s, set }) {
  const total = s.wCash + s.wInvest + (s.hasImmo ? Math.max(0, s.immoValue - s.immoMortgage) : 0);
  return (
    <div className="step">
      <div className="step-head">
        <div className="step-eyebrow">Vermögen</div>
        <h2 className="step-title">Was haben Sie heute <em>auf der Seite?</em></h2>
        <p className="step-sub">Grobe Schätzung reicht — wir verfeinern später. Pensionskasse und 3. Säule kommen im nächsten Schritt.</p>
      </div>
      <div className="module-list">
        <ModuleCard
          icon={<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="3" y="6" width="18" height="14" rx="2" stroke="currentColor" strokeWidth="1.6"/><path d="M3 10h18" stroke="currentColor" strokeWidth="1.6"/></svg>}
          title="Konto & Bargeld"
          desc="Lohn-, Sparkonto, Bargeld."
          value={s.wCash} onChange={(v) => set({ wCash: v })} />
        <ModuleCard
          icon={<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M4 18l5-6 4 4 7-9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/><path d="M14 7h6v6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>}
          title="Wertschriften & Fonds"
          desc="Aktien, ETFs, Anlagefonds, Krypto."
          value={s.wInvest} onChange={(v) => set({ wInvest: v })} />
      </div>
      <div className="field-grid field-grid-1">
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div className="choices choices-2" style={{ gridTemplateColumns: "1fr 1fr" }}>
            <button className={`choice ${!s.hasImmo ? "is-active" : ""}`} onClick={() => set({ hasImmo: false })}
              style={{ padding: 16, flexDirection: "row", alignItems: "center", gap: 12 }}>
              <div className="choice-check" style={{ position: "static", width: 18, height: 18 }}></div>
              <div>
                <div className="choice-title" style={{ fontSize: 15 }}>Keine Immobilie</div>
                <div className="choice-desc" style={{ fontSize: 12 }}>Mieter:in.</div>
              </div>
            </button>
            <button className={`choice ${s.hasImmo ? "is-active" : ""}`} onClick={() => set({ hasImmo: true })}
              style={{ padding: 16, flexDirection: "row", alignItems: "center", gap: 12 }}>
              <div className="choice-check" style={{ position: "static", width: 18, height: 18 }}></div>
              <div>
                <div className="choice-title" style={{ fontSize: 15 }}>Eigenheim</div>
                <div className="choice-desc" style={{ fontSize: 12 }}>Eigentumswohnung oder Haus.</div>
              </div>
            </button>
          </div>
          {s.hasImmo && (
            <div className="module-list" style={{ marginTop: 4 }}>
              <ModuleCard
                icon={<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M3 11l9-7 9 7v9a1 1 0 01-1 1h-5v-6h-6v6H4a1 1 0 01-1-1v-9z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round"/></svg>}
                title="Verkehrswert"
                desc="Aktueller Marktwert (Schätzung reicht)."
                value={s.immoValue} onChange={(v) => set({ immoValue: v })} />
              <ModuleCard
                icon={<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M5 8h14M5 12h14M5 16h14" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>}
                title="Hypothek"
                desc="Restschuld total über alle Tranchen."
                value={s.immoMortgage} onChange={(v) => set({ immoMortgage: v })} />
            </div>
          )}
        </div>
      </div>
      <div className="info-pill" style={{ background: "var(--bg-2)", color: "var(--ink-2)" }}>
        <span style={{ fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--ink-3)" }}>SUMME</span>
        <strong style={{ fontFamily: "var(--font-mono)", fontSize: 18, color: "var(--cuira)", fontWeight: 500 }}>{fmt(total)}</strong>
        <span style={{ marginLeft: "auto", fontSize: 12 }}>Nettovermögen ohne Vorsorge</span>
      </div>
    </div>
  );
}

function StepVorsorge({ s, set }) {
  return (
    <div className="step">
      <div className="step-head">
        <div className="step-eyebrow">Vorsorge — Säule 2 & 3a</div>
        <h2 className="step-title">Was steht auf Ihrem <em>Vorsorgeausweis?</em></h2>
        <p className="step-sub">Diese Zahlen finden Sie auf dem Vorsorgeausweis Ihrer Pensionskasse (jährlich per Post) und auf dem Auszug Ihrer 3a-Bank.</p>
      </div>
      <div>
        <div style={{ fontSize: 13, color: "var(--ink-3)", marginBottom: 10, fontFamily: "var(--font-mono)", letterSpacing: ".08em", textTransform: "uppercase" }}>2. Säule · Pensionskasse</div>
        <div className="module-list">
          <ModuleCard
            icon="🏛"
            title={s.paar ? "Altersguthaben — Sie" : "Aktuelles Altersguthaben"}
            desc='Auf dem Ausweis als „Aktuelles Altersguthaben" oder „Sparkapital".'
            value={s.pk1} onChange={(v) => set({ pk1: v })} />
          <ModuleCard
            icon="📈"
            title={s.paar ? "Erwartete Rente p.a. — Sie" : "Erwartete Rente pro Jahr"}
            desc='Beim Ausweis unter „Voraussichtliche Altersrente" (jährlich).'
            value={s.pk1Rente} onChange={(v) => set({ pk1Rente: v })} />
          {s.paar && (
            <>
              <ModuleCard
                icon="🏛"
                title="Altersguthaben — Partner:in"
                desc="Vorsorgeausweis der zweiten Person."
                value={s.pk2} onChange={(v) => set({ pk2: v })} />
              <ModuleCard
                icon="📈"
                title="Erwartete Rente p.a. — Partner:in"
                desc="Voraussichtliche Altersrente, jährlich."
                value={s.pk2Rente} onChange={(v) => set({ pk2Rente: v })} />
            </>
          )}
        </div>
      </div>
      <div>
        <div style={{ fontSize: 13, color: "var(--ink-3)", marginBottom: 10, fontFamily: "var(--font-mono)", letterSpacing: ".08em", textTransform: "uppercase" }}>Säule 3a · Privatvorsorge</div>
        <div className="module-list">
          <ModuleCard
            icon="💰"
            title={s.paar ? "Aktuelles Guthaben — Sie" : "Aktuelles Guthaben"}
            desc="Total über alle 3a-Konten und -Depots."
            value={s.s3a1} onChange={(v) => set({ s3a1: v })} />
          {s.paar && (
            <ModuleCard
              icon="💰"
              title="Aktuelles Guthaben — Partner:in"
              desc="Total über alle 3a-Konten und -Depots."
              value={s.s3a2} onChange={(v) => set({ s3a2: v })} />
          )}
        </div>
      </div>
      <InfoPill>
        Keinen Ausweis zur Hand? Lassen Sie die Felder leer — wir nehmen für die Vorab-Schätzung Schweizer Durchschnittswerte und korrigieren später im Beratungsgespräch.
      </InfoPill>
    </div>
  );
}

function StepWunsch({ s, set }) {
  return (
    <div className="step">
      <div className="step-head">
        <div className="step-eyebrow">Lebensstil</div>
        <h2 className="step-title">Wie viel möchten Sie <em>in der Pension ausgeben?</em></h2>
        <p className="step-sub">Pro Jahr, alles inklusive — Wohnen, Essen, Versicherungen, Reisen, Hobbys. Faustregel: rund 75% Ihrer heutigen Ausgaben.</p>
      </div>
      <div className="field" style={{ gap: 6 }}>
        <label className="field-label">Heutige Ausgaben (für die Hochrechnung)</label>
        <Slider value={s.spendNow} min={40000} max={300000} step={2000}
          onChange={(v) => set({ spendNow: v })}
          format={(v) => fmt(v)}
          side="pro Jahr · heute"
          ticks={["40'000", "150'000", "300'000+"]} />
      </div>
      <div className="field" style={{ gap: 6 }}>
        <label className="field-label">Wunschausgaben in der Pension</label>
        <Slider value={s.spendRet} min={40000} max={300000} step={2000}
          onChange={(v) => set({ spendRet: v })}
          format={(v) => fmt(v)}
          side={`pro Jahr · ≈ ${Math.round(s.spendRet / s.spendNow * 100)}% von heute`}
          ticks={["40'000", "150'000", "300'000+"]} />
      </div>
      <InfoPill>
        Tipp: Hypothek, Kinderkosten und Pensionskassenbeiträge fallen meist weg — gleichzeitig kommen mehr Reisen und Gesundheitskosten dazu.
      </InfoPill>
    </div>
  );
}

// === Result === 
function ResultChart({ series, retYear, depleteYear }) {
  if (!series || series.length === 0) return null;
  const w = 660, h = 180, padL = 8, padR = 8, padT = 8, padB = 24;
  const xs = series.map(r => r.year);
  const ys = series.map(r => r.wealth);
  const minX = xs[0], maxX = xs[xs.length - 1];
  const maxY = Math.max(...ys, 0);
  const minY = Math.min(...ys, 0);
  const sx = (x) => padL + ((x - minX) / (maxX - minX)) * (w - padL - padR);
  const sy = (y) => padT + (1 - (y - minY) / Math.max(1, maxY - minY)) * (h - padT - padB);
  const path = series.map((p, i) => `${i === 0 ? "M" : "L"} ${sx(p.year).toFixed(1)} ${sy(p.wealth).toFixed(1)}`).join(" ");
  const area = `${path} L ${sx(maxX)} ${sy(0)} L ${sx(minX)} ${sy(0)} Z`;
  const retX = sx(retYear);
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" className="result-chart-svg">
      <defs>
        <linearGradient id="kunde-grad" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="var(--cuira)" stopOpacity="0.22" />
          <stop offset="100%" stopColor="var(--cuira)" stopOpacity="0" />
        </linearGradient>
      </defs>
      <line x1={padL} x2={w - padR} y1={sy(0)} y2={sy(0)} stroke="var(--border)" strokeDasharray="2 3" />
      <path d={area} fill="url(#kunde-grad)" />
      <path d={path} fill="none" stroke="var(--cuira)" strokeWidth="2" />
      <line x1={retX} x2={retX} y1={padT} y2={h - padB} stroke="var(--accent)" strokeWidth="1" strokeDasharray="3 3" />
      <circle cx={retX} cy={sy(series.find(r => r.year === retYear)?.wealth || 0)} r="4" fill="var(--accent)" />
      <text x={retX + 6} y={padT + 11} fontSize="10" fill="var(--accent-ink)" fontFamily="var(--font-mono)">Pension {retYear}</text>
      {depleteYear && (
        <>
          <line x1={sx(depleteYear)} x2={sx(depleteYear)} y1={padT} y2={h - padB} stroke="var(--neg)" strokeWidth="1" strokeDasharray="3 3" />
          <text x={sx(depleteYear) + 6} y={padT + 11} fontSize="10" fill="var(--neg)" fontFamily="var(--font-mono)">Aufgebraucht {depleteYear}</text>
        </>
      )}
      <text x={padL} y={h - 6} fontSize="10" fill="var(--ink-3)" fontFamily="var(--font-mono)">{minX}</text>
      <text x={w - padR} y={h - 6} fontSize="10" fill="var(--ink-3)" textAnchor="end" fontFamily="var(--font-mono)">{maxX}</text>
    </svg>
  );
}

function StepErgebnis({ s, result }) {
  const verdictClass = result.verdict === "good" ? "is-pos" : result.verdict === "warn" ? "is-warn" : "is-neg";
  const icon = result.verdict === "good" ? "✓" : result.verdict === "warn" ? "!" : "✕";
  const startWealth = result.series[0].wealth;
  const retWealth = result.atRet?.wealth || 0;
  const endWealth = result.at85?.wealth || 0;
  return (
    <div className="step">
      <div className="step-head">
        <div className="step-eyebrow">Ergebnis · Vorab-Berechnung</div>
        <h2 className="step-title">So sieht Ihr Plan <em>heute aus.</em></h2>
        <p className="step-sub">Das ist eine Überschlagsrechnung mit Schweizer Durchschnittsannahmen. Im Beratungsgespräch verfeinern wir alles auf Ihre Situation.</p>
      </div>
      <div className="result-card">
        <div className={`result-verdict ${verdictClass}`}>
          <div className="result-icon">{icon}</div>
          <div>
            <div className="result-verdict-title">{result.verdictTitle}</div>
            <div className="result-verdict-sub">{result.verdictSub}</div>
          </div>
        </div>
        <div className="result-kpis">
          <div className="result-kpi">
            <div className="result-kpi-label">Heute · {result.series[0].year}</div>
            <div className="result-kpi-value tnum">{fmt(startWealth)}</div>
            <div className="result-kpi-sub">Nettovermögen total</div>
          </div>
          <div className="result-kpi">
            <div className="result-kpi-label">Pensionierung · {result.retYear}</div>
            <div className="result-kpi-value tnum">{fmt(retWealth)}</div>
            <div className="result-kpi-sub">Vermögen bei Renteneintritt</div>
          </div>
          <div className="result-kpi">
            <div className="result-kpi-label">Mit Alter 85 · {s.geb1 + 85}</div>
            <div className="result-kpi-value tnum">{fmt(endWealth)}</div>
            <div className="result-kpi-sub">Vermögen am Lebensabend</div>
          </div>
        </div>
        <div className="result-chart-card">
          <div className="result-chart-title">
            <span>Vermögensverlauf bis Alter 90+</span>
            <span style={{ fontFamily: "var(--font-mono)", color: "var(--ink-3)", fontSize: 11 }}>{result.series[0].year} → {result.series[result.series.length-1].year}</span>
          </div>
          <ResultChart series={result.series} retYear={result.retYear} depleteYear={result.depleteYear} />
        </div>
      </div>
      <div className="info-pill" style={{ background: "var(--bg-2)", color: "var(--ink-2)" }}>
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <path d="M3 12l2-2 3 3 5-5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        <span>Im nächsten Schritt erhalten Sie das detaillierte PDF und einen 30-Min.-Termin mit einem Cuira-Berater — kostenlos und unverbindlich.</span>
      </div>
    </div>
  );
}

function StepTermin({ s, set, onSubmit, submitted }) {
  if (submitted) {
    return (
      <div className="step" style={{ alignItems: "center", textAlign: "center" }}>
        <div style={{ width: 80, height: 80, borderRadius: 999, background: "var(--pos-soft)", color: "var(--pos)", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 40 }}>✓</div>
        <h2 className="step-title" style={{ textAlign: "center" }}>Vielen Dank, {s.name.split(" ")[0] || "Sie"}!</h2>
        <p className="step-sub" style={{ textAlign: "center", margin: "0 auto" }}>
          Wir haben Ihre Vorab-Berechnung erhalten und melden uns innerhalb von 24 Stunden auf <strong style={{ color: "var(--ink)" }}>{s.email}</strong> mit dem Termin-Vorschlag und dem PDF Ihrer Hochrechnung.
        </p>
        <div style={{ display: "flex", gap: 12, marginTop: 8 }}>
          <a className="btn btn-secondary" href="https://cuirapartners.ch" target="_blank" rel="noopener">Mehr über Cuira</a>
          <button className="btn btn-ghost" onClick={() => window.location.reload()}>Neuen Plan starten</button>
        </div>
      </div>
    );
  }
  const valid = s.email && s.name;
  return (
    <div className="step">
      <div className="step-head">
        <div className="step-eyebrow">Beratungstermin · 30 Min · gratis</div>
        <h2 className="step-title">Sprechen wir über <em>Ihren Plan.</em></h2>
        <p className="step-sub">Sie erhalten Ihre detaillierte Hochrechnung als PDF und einen Termin mit einem unabhängigen Cuira-Berater. Keine Verkaufsgespräche, keine Provisionen.</p>
      </div>
      <div className="lead-card">
        <div>
          <div className="lead-eyebrow">Ihr nächster Schritt</div>
          <div className="lead-title">PDF & Termin per E-Mail</div>
        </div>
        <div className="lead-form">
          <input className="lead-input lead-form-full" placeholder="Vorname Nachname"
            value={s.name} onChange={(e) => set({ name: e.target.value })} />
          <input className="lead-input" placeholder="E-Mail-Adresse" type="email"
            value={s.email} onChange={(e) => set({ email: e.target.value })} />
          <input className="lead-input" placeholder="Telefon (optional)" type="tel"
            value={s.phone} onChange={(e) => set({ phone: e.target.value })} />
        </div>
        <div className="lead-cta-row">
          <button className="btn btn-bright" disabled={!valid} onClick={onSubmit}
            style={{ opacity: valid ? 1 : 0.5, cursor: valid ? "pointer" : "not-allowed" }}>
            PDF anfordern & Termin vereinbaren →
          </button>
          <span style={{ fontSize: 12, color: "rgba(255,255,255,0.6)" }}>Antwort innert 24 Std.</span>
        </div>
        <div className="lead-trust">
          <span>FINMA-konform</span>
          <span>Honorarberatung</span>
          <span>Kein Datenverkauf</span>
          <span>DSGVO + revDSG</span>
        </div>
      </div>
    </div>
  );
}

// === App ===
function App() {
  const [step, setStep] = useState(0);
  const [s, setS] = useState(INITIAL);
  const [submitted, setSubmitted] = useState(false);
  const set = (patch) => setS((cur) => ({ ...cur, ...patch }));
  const result = useMemo(() => project(s), [s]);

  // Scroll to top on step change
  useEffect(() => { window.scrollTo({ top: 0, behavior: "smooth" }); }, [step]);

  // Keyboard nav
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "ArrowRight" && step < STEPS.length - 1 && !submitted) {
        const tag = document.activeElement?.tagName;
        if (tag !== "INPUT" && tag !== "TEXTAREA") setStep(step + 1);
      }
      if (e.key === "ArrowLeft" && step > 0) {
        const tag = document.activeElement?.tagName;
        if (tag !== "INPUT" && tag !== "TEXTAREA") setStep(step - 1);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [step, submitted]);

  const next = () => setStep((s) => Math.min(s + 1, STEPS.length - 1));
  const prev = () => setStep((s) => Math.max(s - 1, 0));

  const id = STEPS[step].id;
  const showFooter = step > 0 && !submitted && id !== "termin";

  return (
    <div className="stage">
      <Topbar step={step} onJumpHome={() => setStep(0)} />
      <Progress step={step} />
      <div className="step-stage" key={id}>
        {id === "welcome" && <StepWelcome onNext={next} />}
        {id === "wer" && <StepWer s={s} set={set} />}
        {id === "beruf" && <StepBeruf s={s} set={set} />}
        {id === "vermoegen" && <StepVermoegen s={s} set={set} />}
        {id === "vorsorge" && <StepVorsorge s={s} set={set} />}
        {id === "wunsch" && <StepWunsch s={s} set={set} />}
        {id === "ergebnis" && <StepErgebnis s={s} result={result} />}
        {id === "termin" && <StepTermin s={s} set={set} onSubmit={() => setSubmitted(true)} submitted={submitted} />}
      </div>
      {showFooter && (
        <div className="footer">
          <button className="btn btn-ghost" onClick={prev}>
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M13 8H3m0 0l4 4m-4-4l4-4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>
            Zurück
          </button>
          <span style={{ fontSize: 12, color: "var(--ink-3)" }}>
            <span className="kbd" style={{ background: "var(--bg-2)", color: "var(--ink-2)" }}>← →</span> zum Navigieren
          </span>
          <button className="btn btn-primary" onClick={next}>
            {id === "ergebnis" ? "Termin vereinbaren" : "Weiter"}
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M3 8h10m0 0L9 4m4 4l-4 4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
        </div>
      )}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
