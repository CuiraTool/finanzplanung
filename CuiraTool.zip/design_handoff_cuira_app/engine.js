// Simplified pension engine — calibrated to feel realistic, not BSV-perfect.
// Returns a vermoegensbilanz (3 stichtage) and a yearly cashflow series.

(function () {
  const HEUTE = 2026;
  const ENDE_ALTER = 85;
  const AHV_MAX_INDIVIDUAL = 30240; // BSV 2025
  const AHV_PLAFOND_PAAR = 45360;

  function jahrAusGeb(geb) {
    return geb ? parseInt(geb.slice(0, 4), 10) : null;
  }
  function alterIn(geb, jahr) {
    const j = jahrAusGeb(geb);
    return j == null ? null : jahr - j;
  }

  function ahvJahr(s, jahr) {
    const a1 = alterIn(s.person1.geburtsdatum, jahr);
    const a2 = s.fallart === "paar" ? alterIn(s.person2.geburtsdatum, jahr) : null;
    let r = 0;
    if (a1 != null && a1 >= 65) r += AHV_MAX_INDIVIDUAL * (s.ahv.rentenfaktorP1 || 1);
    if (a2 != null && a2 >= 65) r += AHV_MAX_INDIVIDUAL * (s.ahv.rentenfaktorP2 || 1);
    if (s.fallart === "paar" && a1 != null && a2 != null && a1 >= 65 && a2 >= 65) {
      r = Math.min(r, AHV_PLAFOND_PAAR);
    }
    return Math.round(r);
  }

  function bvgRenteJahr(p, person, jahr) {
    if (!p.aktiverAnschluss) return 0;
    const a = alterIn(person.geburtsdatum, jahr);
    if (a == null) return 0;
    // approx Bezugsalter from store ziele — passed via engine call, here we accept "active from age 64+"
    if (a < 64) return 0;
    const kapital = p.altersguthabenBeiBezug || 0;
    const usw = (p.umwandlungssatzProzent || 5.4) / 100;
    const rentenAnteil = p.bezugspraeferenz === "kapital" ? 0 : p.bezugspraeferenz === "rente" ? 1 : (100 - (p.kapitalanteil || 0)) / 100;
    return Math.round(kapital * rentenAnteil * usw);
  }

  function bvgKapitalauszahlungJahr(p, person, ziele, personIdx) {
    if (!p.aktiverAnschluss) return 0;
    const bezugsalter = personIdx === 1 ? ziele.bezugsalterP1 : ziele.bezugsalterP2;
    const j = jahrAusGeb(person.geburtsdatum);
    if (j == null) return 0;
    const auszJ = j + bezugsalter;
    return auszJ;
  }

  function netInitial(s) {
    let v = 0;
    s.vermoegen.forEach((x) => (v += x.saldo || 0));
    s.saeule3.p1.forEach((x) => (v += x.saldoHeute || x.rueckkaufHeute || 0));
    if (s.fallart === "paar") s.saeule3.p2.forEach((x) => (v += x.saldoHeute || x.rueckkaufHeute || 0));
    v += s.bvg.p1.altersguthabenHeute || 0;
    if (s.fallart === "paar") v += s.bvg.p2.altersguthabenHeute || 0;
    s.bvg.p1.freizuegigkeit.forEach((f) => (v += f.saldoHeute || 0));
    if (s.fallart === "paar") s.bvg.p2.freizuegigkeit.forEach((f) => (v += f.saldoHeute || 0));
    s.immobilien.forEach((im) => {
      v += im.verkehrswert || 0;
      im.hypotheken.forEach((h) => (v -= h.betrag || 0));
    });
    return v;
  }

  function einkommenAktiv(s, jahr) {
    const a1 = alterIn(s.person1.geburtsdatum, jahr);
    const a2 = s.fallart === "paar" ? alterIn(s.person2.geburtsdatum, jahr) : null;
    let e = 0;
    if (a1 != null && a1 < (s.ziele.bezugsalterP1 || 65)) e += s.budget.einkommenP1 || 0;
    if (a2 != null && a2 < (s.ziele.bezugsalterP2 || 65)) e += s.budget.einkommenP2 || 0;
    return e;
  }

  function steuern(einkommen, vermoegen, jahr) {
    // Crude ZH approximation — Eink * 0.18 + Verm * 0.0035
    return Math.round(einkommen * 0.18 + Math.max(0, vermoegen) * 0.0035);
  }

  function cashflowReihe(s) {
    const j1 = jahrAusGeb(s.person1.geburtsdatum) || HEUTE - 50;
    const ende = j1 + ENDE_ALTER;
    const reihe = [];
    let v = netInitial(s);
    let depot = (s.vermoegen.find((x) => x.renditeProzent) || {}).saldo || 0;
    const depotRendite = ((s.vermoegen.find((x) => x.renditeProzent) || {}).renditeProzent || 0) / 100;

    for (let j = HEUTE; j <= ende; j++) {
      const a1 = alterIn(s.person1.geburtsdatum, j);
      const ahv = ahvJahr(s, j);
      const bvgR = bvgRenteJahr(s.bvg.p1, s.person1, j) +
        (s.fallart === "paar" ? bvgRenteJahr(s.bvg.p2, s.person2, j) : 0);
      const mieten = 0;
      const eAktiv = einkommenAktiv(s, j);
      const einkommen = eAktiv + ahv + bvgR + mieten;
      const ausgaben = a1 != null && a1 >= (s.ziele.bezugsalterP1 || 65)
        ? (s.budget.wunschVerbrauch || 0) : (s.budget.ausgabenTotal || 0);
      const einmal = (s.ziele.einmalAusgaben || []).filter((x) => x.jahr === j).reduce((a, b) => a + b.betrag, 0);
      const st = steuern(einkommen, v, j);

      // BVG kapitalauszahlung (one-off in bezugsjahr)
      const bvgK1Jahr = bvgKapitalauszahlungJahr(s.bvg.p1, s.person1, s.ziele, 1);
      const bvgK2Jahr = s.fallart === "paar" ? bvgKapitalauszahlungJahr(s.bvg.p2, s.person2, s.ziele, 2) : 0;
      let bvgKapital = 0;
      if (j === bvgK1Jahr && s.bvg.p1.aktiverAnschluss) {
        const kap = s.bvg.p1.altersguthabenBeiBezug || 0;
        const anteil = s.bvg.p1.bezugspraeferenz === "kapital" ? 1 : s.bvg.p1.bezugspraeferenz === "rente" ? 0 : (s.bvg.p1.kapitalanteil || 0) / 100;
        bvgKapital += kap * anteil;
      }
      if (j === bvgK2Jahr && s.fallart === "paar" && s.bvg.p2.aktiverAnschluss) {
        const kap = s.bvg.p2.altersguthabenBeiBezug || 0;
        const anteil = s.bvg.p2.bezugspraeferenz === "kapital" ? 1 : s.bvg.p2.bezugspraeferenz === "rente" ? 0 : (s.bvg.p2.kapitalanteil || 0) / 100;
        bvgKapital += kap * anteil;
      }

      // depot growth
      depot = depot * (1 + depotRendite);
      const depotZuwachs = depot * depotRendite;

      const saldoJahr = einkommen - ausgaben - st - einmal + depotZuwachs;
      v = v + saldoJahr + (j === bvgK1Jahr || j === bvgK2Jahr ? 0 : 0); // bvg kapital schon in initial mitgezählt
      reihe.push({
        jahr: j,
        alter: a1,
        einkommen, ahv, bvgRente: bvgR, eAktiv,
        ausgaben: ausgaben + einmal,
        steuern: st,
        vermoegenNetto: Math.round(v),
        saldoJahr: Math.round(saldoJahr),
      });
    }
    return reihe;
  }

  function vermoegensbilanz(s) {
    const reihe = cashflowReihe(s);
    const j1 = jahrAusGeb(s.person1.geburtsdatum);
    const pensionsjahr = j1 ? j1 + (s.ziele.bezugsalterP1 || 65) : null;
    const heute = reihe[0]?.vermoegenNetto || 0;
    const pension = pensionsjahr ? (reihe.find(r => r.jahr === pensionsjahr)?.vermoegenNetto || 0) : null;
    const ende = reihe[reihe.length - 1]?.vermoegenNetto || 0;
    const endeJahr = reihe[reihe.length - 1]?.jahr || null;
    return { heute, pension, pensionsjahr, ende, endeJahr };
  }

  function massnahmen(s) {
    const m = [];
    // PK Einkauf checks
    const j1 = jahrAusGeb(s.person1.geburtsdatum);
    const bezJ1 = j1 ? j1 + (s.ziele.bezugsalterP1 || 65) : null;
    s.bvg.p1.einkaeufe.forEach(ek => {
      if (bezJ1 && ek.jahr >= bezJ1 - 2 && (s.bvg.p1.bezugspraeferenz === "kapital" || s.bvg.p1.bezugspraeferenz === "mischung")) {
        m.push({ id: "sperr-p1-" + ek.id, prio: "warn", icon: "⚠", title: "3-Jahres-Sperrfrist BVG", sub: `Einkauf ${ek.jahr} • Person 1 verletzt Art. 79b Abs. 3 BVG.`, impact: "blockiert Kapitalbezug" });
      }
    });
    // 3a Maximalausschöpfung
    const max3a = 7258;
    [s.saeule3.p1, s.fallart === "paar" ? s.saeule3.p2 : []].forEach((arr, i) => {
      const k = arr.find(x => x.typ === "3a-konto");
      if (k && (k.einzahlungJaehrlich || 0) < max3a) {
        m.push({ id: "3a-max-" + i, prio: "info", icon: "↑", title: `3a-Maximum nicht ausgeschöpft`, sub: `${i === 0 ? s.person1.vorname : s.person2.vorname}: ${(k.einzahlungJaehrlich || 0).toLocaleString("de-CH")} statt ${max3a.toLocaleString("de-CH")}`, impact: `+CHF ${((max3a - (k.einzahlungJaehrlich || 0)) * 18 / 100 * 1).toLocaleString("de-CH", { maximumFractionDigits: 0 })} Steuern p.a.` });
      }
    });
    // Hypothek-Tragbarkeit
    s.immobilien.forEach(im => {
      const sumHyp = im.hypotheken.reduce((a,b) => a + (b.betrag||0), 0);
      const beleihung = im.verkehrswert ? sumHyp / im.verkehrswert : 0;
      if (beleihung > 0.66) {
        m.push({ id: "amort-" + im.id, prio: "info", icon: "↓", title: "Amortisation auf 2/3 prüfen", sub: `${im.adresse}: Belehnung ${(beleihung*100).toFixed(0)}% • Tragbarkeit bei Pension`, impact: "vor Pension" });
      }
    });
    // Pensionierung Stephanie früh
    if (s.fallart === "paar" && s.ziele.bezugsalterP2 < 64) {
      m.push({ id: "vorbezug-p2", prio: "warn", icon: "−", title: "AHV-Vorbezug Person 2", sub: `Bezug mit ${s.ziele.bezugsalterP2} • Lebenslange Kürzung 6.8% pro Vorbezugsjahr`, impact: `−${((64 - s.ziele.bezugsalterP2)*6.8).toFixed(1)}% AHV` });
    }
    // Always: Sample positive
    m.push({ id: "good-1", prio: "pos", icon: "✓", title: "Vorsorgeauftrag vorhanden", sub: "Block 10 Nachlass • aktualisiert 2024", impact: "OK" });
    return m;
  }

  window.CuiraEngine = { cashflowReihe, vermoegensbilanz, massnahmen, HEUTE };
})();
