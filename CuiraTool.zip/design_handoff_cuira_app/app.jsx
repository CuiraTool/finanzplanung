/* global React, ReactDOM */
const { useState: aS, useEffect: aE, useMemo: aM, useRef: aR, useCallback: aC } = React;

// === Top bar ===
function TopBar({ state, recalc, onCmdK, scenarioB, onScenarioToggle, onScenarioClear }) {
  const fa = state.fallart;
  const initials = fa === "paar"
    ? `${(state.person1.vorname || "?")[0]}${(state.person2.vorname || "?")[0]}`
    : `${(state.person1.vorname || "?")[0]}${(state.person1.nachname || "?")[0]}`;
  const titel = fa === "paar"
    ? `Familie ${state.person1.nachname}`
    : `${state.person1.vorname} ${state.person1.nachname}`;
  return (
    <header className="topbar">
      <div className="topbar-logo"><span className="topbar-logo-mark"></span><span>cuira</span></div>
      <div className="topbar-tag">Pensionsplanung · Pro</div>
      <div className="topbar-mandant">
        <span className="topbar-mandant-avatar">{initials.toUpperCase()}</span>
        <span>{titel}</span>
        <span style={{ color: "var(--ink-4)", fontSize: 11, marginLeft: 4 }}>· {state.adresse.kanton}</span>
      </div>
      <div className="scenario-bar" style={{ marginLeft: 6 }}>
        <button className="scenario-tab is-active"><span className="dot a"/>Plan A</button>
        {scenarioB ? (
          <button className="scenario-tab" onClick={onScenarioToggle}>
            <span className="dot b"/>Plan B
            <span className="x" onClick={(e) => { e.stopPropagation(); onScenarioClear(); }}>×</span>
          </button>
        ) : (
          <button className="scenario-tab" onClick={onScenarioToggle}><span className="dot b"/>+ Plan B</button>
        )}
      </div>
      <div className="topbar-spacer" />
      <button className="topbar-cmd" onClick={onCmdK}>
        <svg width="13" height="13" viewBox="0 0 16 16" fill="none"><circle cx="7" cy="7" r="5" stroke="currentColor" strokeWidth="1.4" /><path d="M11 11l3 3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" /></svg>
        <span>Springe zu Frage…</span>
        <span className="topbar-cmd-key">⌘K</span>
      </button>
      <div style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 12, color: "var(--ink-3)" }}>
        <span className="autosave-dot" />Auto-Save
      </div>
      <button className="topbar-icon-btn" title="PDF-Export">
        <svg width="14" height="14" viewBox="0 0 16 16" fill="none"><path d="M4 2h6l2 2v10H4V2z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" /><path d="M10 2v3h2" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" /></svg>
      </button>
      <span className="topbar-avatar">KM</span>
    </header>
  );
}

function Rail({ state, currentBlock, setCurrentBlock, completed }) {
  const pct = Math.round((completed.size / BLOCKS.length) * 100);
  return (
    <nav className="rail">
      <div className="rail-header">
        <div className="rail-eyebrow">Erfassung</div>
        <div className="rail-title">10 Blöcke</div>
        <div className="rail-progress">
          <div className="rail-progress-bar"><div className="rail-progress-fill" style={{ width: `${pct}%` }} /></div>
          <div className="rail-progress-text"><span>{completed.size} / {BLOCKS.length} erledigt</span><span className="mono">{pct}%</span></div>
        </div>
      </div>
      <div className="rail-list">
        {BLOCKS.map((b) => {
          const isActive = currentBlock === b.id;
          const isDone = completed.has(b.id);
          return (
            <button key={b.id} className={`rail-item ${isActive ? "is-active" : ""} ${isDone ? "is-done" : ""}`} onClick={() => setCurrentBlock(b.id)}>
              <span className="rail-num">{isDone && !isActive ? "✓" : b.id}</span>
              <span>
                <div className="rail-label">{b.title}</div>
                <div className="rail-sub">{b.glance(state)}</div>
              </span>
              <span className="rail-mark">{isActive ? "→" : ""}</span>
            </button>
          );
        })}
      </div>
      <div className="rail-footer">
        <div className="rail-foot-row"><span>Schema</span><strong className="mono">v17</strong></div>
        <div className="rail-foot-row"><span>Engine</span><strong>BSV 2025</strong></div>
      </div>
    </nav>
  );
}

function MainColumn({ state, set, currentBlock, setCurrentBlock, completed, setCompleted }) {
  const block = BLOCKS.find((b) => b.id === currentBlock);
  const Comp = window[block.comp];
  return (
    <main className="main">
      <div className="main-head fade-in" key={`head-${currentBlock}`}>
        <div className="main-head-num">BLOCK {String(block.id).padStart(2, "0")} / 10</div>
        <div style={{ flex: 1 }}>
          <h1 className="main-head-title">{block.title}</h1>
          <div className="main-head-sub">{block.desc}</div>
        </div>
        <div className="main-head-meta">
          <button className="btn btn-ghost" onClick={() => {
            const next = new Set(completed);
            if (next.has(currentBlock)) next.delete(currentBlock); else next.add(currentBlock);
            setCompleted(next);
          }}>{completed.has(currentBlock) ? "✓ erledigt" : "Als erledigt markieren"}</button>
        </div>
      </div>
      <div className="block-container fade-in" key={`body-${currentBlock}`}>
        <Comp state={state} set={set} />
      </div>
      <div className="block-footer">
        <button className="btn btn-ghost" disabled={currentBlock === 1} onClick={() => setCurrentBlock(currentBlock - 1)}>← Zurück</button>
        <span className="block-footer-hint">{currentBlock < BLOCKS.length ? `Nächster Block: ${BLOCKS[currentBlock].title}` : "Alle Blöcke abgeschlossen"}</span>
        <button className="btn btn-primary" onClick={() => {
          const next = new Set(completed); next.add(currentBlock); setCompleted(next);
          if (currentBlock < BLOCKS.length) setCurrentBlock(currentBlock + 1);
        }}>{currentBlock < BLOCKS.length ? `Weiter` : "Fertig"} →</button>
      </div>
    </main>
  );
}

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "density": "comfortable",
  "theme": "light",
  "accent": "#2456c8"
}/*EDITMODE-END*/;

function CuiraTweaks({ tweaks, setTweak }) {
  return (
    <window.TweaksPanel title="Tweaks">
      <window.TweakSection title="Layout">
        <window.TweakRadio label="Density" value={tweaks.density} onChange={(v) => setTweak("density", v)} options={[
          { value: "comfortable", label: "Bequem" },
          { value: "compact", label: "Kompakt" },
        ]} />
        <window.TweakRadio label="Theme" value={tweaks.theme} onChange={(v) => setTweak("theme", v)} options={[
          { value: "light", label: "Hell" },
          { value: "dark", label: "Dunkel" },
        ]} />
      </window.TweakSection>
      <window.TweakSection title="Akzent">
        <window.TweakColor label="Action-Farbe" value={tweaks.accent} onChange={(v) => setTweak("accent", v)} options={["#2456c8", "#0a2540", "#0e7c66", "#7c3aed"]} />
      </window.TweakSection>
    </window.TweaksPanel>
  );
}

function App() {
  const [tweaks, setTweak] = window.useTweaks(TWEAK_DEFAULTS);
  const [state, setState] = aS(window.CUIRA_INITIAL_STATE);
  const [scenarioB, setScenarioB] = aS(null); // snapshot of state when activated
  const [currentBlock, setCurrentBlock] = aS(2);
  const [completed, setCompleted] = aS(() => new Set([1, 4]));
  const [recalc, setRecalc] = aS(false);
  const [cmdkOpen, setCmdkOpen] = aS(false);
  const [fullscreen, setFullscreen] = aS(false);
  const [showWaterfall, setShowWaterfall] = aS(false);
  const [liveW, onResizerDown] = window.useResize(400, 340, 600);

  const recalcTimer = aR();
  aE(() => {
    setRecalc(true);
    clearTimeout(recalcTimer.current);
    recalcTimer.current = setTimeout(() => setRecalc(false), 400);
  }, [state]);

  aE(() => {
    document.documentElement.dataset.density = tweaks.density;
    document.documentElement.dataset.theme = tweaks.theme;
    document.documentElement.style.setProperty("--accent", tweaks.accent);
    document.documentElement.style.setProperty("--accent-soft", `color-mix(in oklab, ${tweaks.accent} 12%, white)`);
    document.documentElement.style.setProperty("--accent-ink", `color-mix(in oklab, ${tweaks.accent} 80%, black)`);
  }, [tweaks]);

  aE(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") { e.preventDefault(); setCmdkOpen(o => !o); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const set = aC((patch) => setState((s) => ({ ...s, ...patch })), []);

  const onScenarioToggle = () => {
    if (scenarioB) {
      // toggle visibility (clear B activates create-from-current)
      setScenarioB(null);
    } else {
      setScenarioB(JSON.parse(JSON.stringify(state)));
    }
  };

  const onJump = (item) => {
    setCurrentBlock(item.block);
    setTimeout(() => {
      const main = document.querySelector(".main");
      if (main) main.scrollTop = 0;
      const cards = document.querySelectorAll(".block-container .card");
      // best-effort: highlight first card
      cards[0]?.classList.add("flash-field");
      setTimeout(() => cards[0]?.classList.remove("flash-field"), 1700);
    }, 50);
  };

  const onAction = (id) => {
    if (id === "scenario") onScenarioToggle();
    else if (id === "fullscreen") setFullscreen(true);
  };

  return (
    <>
      <TopBar state={state} recalc={recalc} onCmdK={() => setCmdkOpen(true)}
        scenarioB={scenarioB} onScenarioToggle={onScenarioToggle} onScenarioClear={() => setScenarioB(null)} />
      <div className="shell shell-resizable">
        <Rail state={state} currentBlock={currentBlock} setCurrentBlock={setCurrentBlock} completed={completed} />
        <MainColumn state={state} set={set} currentBlock={currentBlock} setCurrentBlock={setCurrentBlock} completed={completed} setCompleted={setCompleted} />
        <div className="resizer" onMouseDown={onResizerDown} />
        <window.LiveDashboard state={state} scenarioB={scenarioB} recalc={recalc}
          width={liveW} fullscreen={fullscreen} onFullscreen={setFullscreen}
          showWaterfall={showWaterfall} onShowWaterfall={setShowWaterfall} />
      </div>
      <window.CmdK open={cmdkOpen} onClose={() => setCmdkOpen(false)} onJump={onJump} onAction={onAction} />
      <CuiraTweaks tweaks={tweaks} setTweak={setTweak} />
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
