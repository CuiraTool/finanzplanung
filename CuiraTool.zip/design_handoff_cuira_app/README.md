# Handoff: Cuira Pensionsplanung — App-Suite

## Overview

This handoff package contains the design references for the **Cuira Pensionsplanung** product — a Swiss pension-planning application with three distinct user roles and a public-facing customer funnel:

1. **Pro-Modus** (`Cuira Pensionsplanung.html`) — Full advisor cockpit for Cuira-internal advisors. 10-block wizard, live A/B plan comparison, Live-Plan with charts, ⌘K command palette, Tweaks panel.
2. **Affiliate-Erfassung** (`Cuira Erfassung.html`) — Data-capture tool for external sales partners ("Affiliates") who collect client data and hand it off to Cuira advisors. Same 10 blocks as Pro, plus a handover panel for priority/notes/commission.
3. **Kunden-Funnel** (`Cuira Kunde.html`) — Public-facing 8-step funnel for end customers ("Reicht Ihr Geld in der Pension?"). Linear, friendly, no jargon. Ends with appointment booking.
4. **Mandanten-Cockpit** (`Cuira Mandanten.html`) — Advisor's portfolio overview: client table, KPIs, filters, calendar strip.
5. **Mandant-Detail** (`Cuira Mandant Detail.html`) — Hub page per client: plans, activities, documents, appointments.
6. **Login** (`Cuira Login.html`) — Three role-tailored login screens (Berater · Affiliate · Kunde). In production these become 3 separate routes.

The visual language is built around the existing Cuira blue (`#0a2540`) on cool neutrals, Geist & Geist Mono typography, and a calm dense layout with subtle shadows.

## About the Design Files

The files in this bundle are **design references created in HTML** — interactive prototypes showing intended look and behavior. **They are NOT production code to copy directly.** The task is to **recreate these designs in the target codebase** (the existing Next.js app at `cuirapartners.ch`) using its established patterns: React components, server actions/API routes, real auth, real DB persistence, real calculation engine.

The HTML prototypes use inline React + Babel for fast iteration; production should use proper Next.js routing, server components where appropriate, and TypeScript. Treat the `.jsx` files as **structural references** for component breakdown, not as drop-in code.

## Fidelity

**High-fidelity (hifi).** Final colors, typography, spacing, copy (German, Swiss conventions), and interactions. Recreate pixel-perfectly. The design system is internally consistent across all six HTML files — `styles.css` is the canonical source of truth for tokens.

## Files in this Handoff

| File | Purpose |
|---|---|
| `Cuira Pensionsplanung.html` + `app.jsx`, `wizard.jsx`, `dashboard.jsx`, `polish.jsx`, `engine.js` | Pro-Modus advisor cockpit |
| `Cuira Erfassung.html` + `erfassung.jsx` | Affiliate data-capture |
| `Cuira Kunde.html` + `kunde.jsx` | Customer funnel |
| `Cuira Mandanten.html` + `dashboard-mandanten.jsx` | Mandant cockpit |
| `Cuira Mandant Detail.html` + `mandant-detail.jsx` | Per-client hub |
| `Cuira Login.html` | Three-role login |
| `styles.css` | Shared design system / tokens |
| `data.js`, `utils.js`, `tweaks-panel.jsx` | Shared helpers |

## Routes (production targets)

```
/                       → Marketing site (existing on cuirapartners.ch)
/login/berater          → Berater login (E-Mail + Passwort + 2FA OTP)
/login/affiliate        → Affiliate login (E-Mail + Passwort)
/login/kunde            → Kunde login (Magic-Link)

/app                    → Berater Mandanten-Cockpit (default after Berater login)
/app/mandant/[id]       → Mandant-Detail-Page
/app/mandant/[id]/plan  → Pro-Modus Pensionsplanung (10-block wizard)
/app/termine            → (NOT YET DESIGNED — Wochen/Monat-Kalender)
/app/settings           → (NOT YET DESIGNED — Profil, Branding, E-Mail-Templates)

/affiliate              → Affiliate Mandanten-Cockpit (filtered to own)
/affiliate/erfassung    → Erfassung (new mandant) or /affiliate/erfassung/[id]
/affiliate/provisionen  → (NOT YET DESIGNED — Auszahlungs-Übersicht)

/kunde                  → Public funnel landing
/kunde/schritt-[1..7]   → Funnel steps
/kunde/ergebnis         → Verdict
/kunde/termin           → Appointment booking
/portal                 → Logged-in customer portal (NOT YET DESIGNED — plan view, documents, messages)
```

## Design Tokens (from `styles.css`)

### Colors

```css
/* Brand */
--cuira-deep: #0a2540;
--cuira-deep-soft: #14315a;

/* Surfaces (light) */
--bg: #f4f6f8;
--bg-soft: #eef1f5;
--surface: #ffffff;
--surface-2: #fafbfc;
--surface-hover: #f6f8fa;

/* Surfaces (dark) */
--bg: #0a1220; --bg-soft: #0f1a2e;
--surface: #111d33; --surface-2: #15243d; --surface-hover: #1a2c49;

/* Borders */
--border: #e7eaee; --border-strong: #d4d9e0;
/* dark: #1f2f4d / #2a3c5e */

/* Ink */
--ink: #0a2540; --ink-2: #4b566b; --ink-3: #8390a3; --ink-4: #a9b3c1;
/* dark: #e7ecf3 / #a9b6cb / #7a8aa6 / #56678a */

/* Action accent — Cuira-derivative */
--accent:     oklch(0.55 0.16 252);
--accent-soft: oklch(0.95 0.04 252);
--accent-ink:  oklch(0.4  0.18 252);

/* Status */
--pos: oklch(0.55 0.12 158); --pos-soft: oklch(0.95 0.04 158);
--neg: oklch(0.6  0.18 25);  --neg-soft: oklch(0.96 0.04 25);
--warn: oklch(0.74 0.14 80); --warn-soft: oklch(0.96 0.06 85);
```

The Tweaks panel exposes 4 accent options: Cuira-blau (default), Cuira-deep, Emerald, Violett. The `--accent`, `--accent-soft`, `--accent-ink` triplet rotates together.

### Typography

```css
--font-sans: "Geist", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
--font-mono: "Geist Mono", ui-monospace, "SF Mono", Menlo, monospace;

/* Use tabular-nums for ALL CHF amounts and percentages: */
font-feature-settings: "tnum"; font-variant-numeric: tabular-nums;
```

Both fonts loaded via Google Fonts (`Geist:300,400,500,600,700` + `Geist+Mono:400,500`).

**Type scale used:**
- Hero h1 (Login brand pane, Kunde funnel): 44–56px, weight 500, letter-spacing -0.025em
- Page h1: 26–32px, weight 600, letter-spacing -0.02em
- Section h2: 18–22px, weight 600
- Card title: 14–16px, weight 500–600
- Body: 13.5–14.5px
- Small / mono labels: 11–12px, mono, uppercase, letter-spacing 0.04–0.12em

### Spacing & geometry

```css
--radius-sm: 6px; --radius: 10px; --radius-lg: 14px; --radius-xl: 18px;
--row-h: 40px (compact: 34px);
--pad: 14px (compact: 10px);
--gap: 12px (compact: 8px);

--shadow-card: 0 1px 2px rgba(10,37,64,.04), 0 0 0 1px rgba(10,37,64,.05);
--shadow-pop:  0 12px 32px -12px rgba(10,37,64,.18), 0 0 0 1px rgba(10,37,64,.06);
```

The `[data-density="compact"]` attribute on `<html>` switches density. Tweaks panel toggles this.

## Screens

### 1. Pro-Modus — `Cuira Pensionsplanung.html`

**Purpose:** Cuira-internal advisor builds a pension plan with the client live (in-meeting or remote). Plan is the core deliverable.

**Layout:** 3-column shell
- **Topbar** (56px): Cuira-Logo chip · mandant pill (`Familie Muster · ZH`) · Plan A/B tabs · ⌘K spring-zu pill · autosave dot · Tweaks toggle
- **Left rail** (280px, resizable): 10 numbered blocks with completion dots, live "glance value" per block (e.g. "AHV-Prognose · CHF 28'600/J"), progress meter at top
- **Center** (flex): Active block content with cards, segmented controls, sliders, repeater tables, BVG-Sperrfrist warnings inline
- **Resizer** (4px drag handle, 340–600px range)
- **Right Live-Plan** (340–600px): 3 KPI cards (heute / Pension / Alter 85), Vermögensverlauf area chart with Pension marker line, Cashflow-bar for pension year, Massnahmen list (Sperrfrist warnings, 3a-Maximum hints, Vorbezug-Hinweise)

**The 10 blocks** (same in Pro & Erfassung — only the chrome differs):
1. Personen (households, partners, children, ages, incomes)
2. Ziele & Pension (target retirement age, desired monthly income, lifestyle prefs)
3. Budget (monthly income/expense breakdown)
4. AHV (1st pillar, contribution years, expected pension)
5. PK / BVG (2nd pillar, current capital, employer code, conversion rate, Sperrfrist)
6. 3. Säule (3a/3b, current balance, annual contribution, Vorbezug intent)
7. Vermögen (liquid + invested assets, repeater table)
8. Immobilien (properties, repeater, rental/own use)
9. Firma (collapsible — "Keine / Vorhanden" toggle; if shown: Lohn/Dividende, Vorsorgeplan)
10. Nachlass (Testament, Ehevertrag, Vorsorgeauftrag, Patientenverfügung checks; Erbteilung; 3a-Begünstigte)

**Live-Plan engine** (`engine.js`) — recomputes on every keystroke:
- `vermogensverlauf(state)` → array of {jahr, vermogen, einzahlungen, ausgaben} per year from now to age 95
- `pensionKpis(state)` → {heute, pension, alter85}
- `massnahmen(state)` → array of warnings/recommendations with severity
- A/B mode: `state.planB` is a sparse override of `state` — engine merges before computing

**⌘K palette:** searches schema (block titles + field labels), jumps to block + smooth-scrolls to field with highlight pulse. Plus quick-actions: "Plan B erstellen", "Live-Plan Vollbild".

**Tweaks panel** (right-floating):
- Layout: 3-spaltig | Floating Live-Plan
- Density: bequem | kompakt
- Theme: hell | dunkel
- Accent: 4 swatches (Cuira-blau / Cuira-deep / Emerald / Violett)

**Production wiring needed:**
- Real auto-save (debounced PATCH to API per field change)
- Real AHV calculation (BSV-Tabelle 2026)
- Real PK conversion-rate logic per provider
- Cantonal tax rates (all 26 — use `swiss-tax-rates` package or maintain table)
- PDF export of the plan (print-stylesheet + headless Chromium)
- A/B plan persistence (store both in DB, scenario diff in API response)

### 2. Affiliate-Erfassung — `Cuira Erfassung.html`

**Purpose:** External sales partners (insurance brokers, financial advisors) capture full client data structured the same way as Pro-Modus, but without doing the actual planning. Submit hands the file to Cuira; partner gets paid CHF 1'200 per closed plan.

**Layout:** 3-column, no Live-Plan
- **Topbar:** Affiliate-Pill ("Vertriebspartner") · advisor avatar (e.g. "Lukas Fischer · Fischer Vorsorge AG") · mandant search (⌘K stub) · auto-save status · link to Pro-Modus
- **Left nav** (240px): 9 sections in 3 groups (Mandant · Finanzen · Plan), scroll-spy active section, checkmark per completed section
- **Form** (flex): Dense table-rows with inline inputs, repeater tables (+/- rows) for assets/properties, segmented controls for Bezugsart/Kanton, upload slots for Vorsorgeausweis & Steuererklärung
- **Übergabe-Panel** (320px right): Progress ring (% complete), section checklist, priority picker (Normal / Hoch / Dringend), advisor note, expected commission (CHF 1'200), sticky Submit

**Production wiring needed:**
- Multi-tenant: each affiliate sees only their own mandanten
- Document upload to S3-equivalent (Swiss data residency!)
- Submit triggers email notification to Cuira ops
- Commission tracking: Erfasst → Termin → Plan → Bezahlt status machine
- Whitelabel branding: affiliate uploads logo, appears on customer PDF

### 3. Kunden-Funnel — `Cuira Kunde.html`

**Purpose:** Public-facing acquisition funnel. End customer answers 8 questions in 5 minutes, sees a verdict, books an appointment.

**Layout:** Single-column, viewport-centered, large type
- **Welcome:** Big headline "Reicht Ihr Geld in der Pension?", warm off-white bg, 3 trust stats
- **Steps 1–5** (Sie · Beruf · Vermögen · Vorsorge · Wunsch): one question per screen, large typography, choice cards or custom slider with live tick-marks, or module cards with icons + inline input. Tooltips in accent pills explain Swiss-specific terms (Vorsorgeausweis, AHV-Vorbezug, etc.)
- **Step 6 — Ergebnis:** verdict card (positiv/warn/negativ), 3 KPIs (heute · Pension · Alter 85), Vermögensverlauf chart with Pension marker and optional "Aufgebraucht" marker
- **Step 7 — Termin:** lead-capture in dark Cuira card with calendar slot picker
- **Step 8 — Danke:** confirmation

**Tone:** Sie-form throughout, friendly, no jargon — Swiss-specific terms always parenthetically explained.

**Keyboard:** ←/→ arrow nav, visible shortcut hint.

**Production wiring needed:**
- A/B test variants of headline + verdict copy
- Lead persistence (even if user drops off mid-funnel) — track UTM
- Email confirmation + ICS calendar attachment
- Appointment slot picker pulls from advisor calendar (Calendly-style or built-in)
- After appointment: convert lead to mandant → full Pro-Modus plan
- GDPR/CH-DSG: explicit consent, tracking opt-in, data deletion endpoint

### 4. Mandanten-Cockpit — `Cuira Mandanten.html`

**Purpose:** Advisor's daily landing page. See all clients, today's appointments, KPIs.

**Layout:** Sidebar + main
- **Sidebar** (220px): Cuira logo · nav (Dashboard · Mandanten · Termine · Provisionen · Berichte) · direct links to all 3 modes (Erfassung, Pro, Kunde) · advisor avatar at bottom
- **Main:** Greeting "Guten Morgen, Lukas" + 7-day calendar strip (today highlighted, dot per appointment) · 4 KPI cards (aktive Mandanten · Termine 7 Tage · AUM · Provision YTD · all with sparklines/deltas) · view tabs (aktiv / abgeschlossen / alle) · filter bar (status pills · search · sort · "Neuer Mandant" with `N` hotkey) · table

**Table columns:** Avatar · Name · Status pill · Plan-Vollständigkeit (mini-bar) · Vermögen (CHF) · Δ bei Pension (red/yellow/green) · Nächster Termin (with "Heute"/"Morgen"/"in X T.") · Letzte Aktivität · row-click opens detail drawer.

**Detail drawer:** Eckwerte, activity timeline, source. "Im Pro-Modus öffnen" → routes to `/app/mandant/[id]/plan`. "Neuer Mandant" → routes to Erfassung.

### 5. Mandant-Detail — `Cuira Mandant Detail.html`

**Purpose:** Per-client hub. Where Affiliate-erfassten Daten landen and where the advisor manages everything for one client.

**Layout:** Sidebar + main
- **Sidebar:** breadcrumb back to cockpit · client mini-profile (avatar, name, age, marital, kids, canton, source pill: "Affiliate / Direkt / Kunde-Funnel") · contact · status switcher
- **Main tabs:** Übersicht · Pläne · Termine · Dokumente · Aktivität · Notizen
  - **Übersicht:** KPI tiles (Vermögen heute, bei Pension, Δ, nächster Termin), Plan thumbnails (A & B, click to open Pro-Modus), recent activity feed
  - **Pläne:** list with version history, "Neuer Plan", duplicate, archive, share-link
  - **Termine:** past + upcoming, "Termin buchen"
  - **Dokumente:** uploaded files, drag-drop zone
  - **Aktivität:** chronological log
  - **Notizen:** rich text per advisor

### 6. Login — `Cuira Login.html`

**Purpose:** Three role-tailored entry points. **In production these become 3 separate routes** (`/login/berater`, `/login/affiliate`, `/login/kunde`). The role-tab switcher in the prototype is for design comparison only.

**Layout:** Split-screen 2-column
- **Brand pane** (left, flex 1, `--cuira-deep` bg with radial-gradient overlays): Cuira logo · eyebrow · big headline (with `<em>` accent in `oklch(0.78 0.13 252)`) · lede · 3 feature items · role-specific extra (testimonial card / affiliate stats / trust badges) · footer
- **Form pane** (right, 520px, white bg): top help-link · role-tab segmented control (Berater · Affiliate · Kunde, only in prototype) · form

**Berater form:** E-Mail + Passwort + 2FA → 6-cell OTP screen → `/app`
**Affiliate form:** E-Mail + Passwort → `/affiliate`
**Kunde form:** E-Mail only → "Link unterwegs" magic-link state → email contains 15-min validity link → `/portal`

All forms have SSO buttons (Microsoft, Google) below a divider; Kunde does not.

## Components

These appear repeatedly across screens — recreate as a shared component library:

| Component | Where used | Notes |
|---|---|---|
| `<KpiCard>` | Pro Live-Plan, Cockpit, Mandant-Detail, Kunde Ergebnis | Big number with mono tabular-nums, label, optional sparkline + delta |
| `<StatusPill>` | Cockpit, Mandant-Detail | Variants: aktiv (accent), warten (warn), abgeschlossen (pos), archiviert (ink-3) |
| `<ProgressBar>` | Cockpit table (plan-vollständigkeit), Pro left rail (block progress), Erfassung übergabe | 4px height, `--accent` fill on `--bg-soft` track |
| `<SegmentedControl>` | Pro & Erfassung forms (Bezugsart, Kanton-class), Cockpit view tabs | Active item: `--surface` bg with `--shadow-card` |
| `<ChoiceCard>` | Kunde funnel | Big tap target, icon + label + sub, hover lift, selected state with accent border |
| `<RepeaterTable>` | Pro & Erfassung Vermögen/Immobilien | +/- buttons, animated row insert |
| `<UploadSlot>` | Erfassung, Mandant-Detail Dokumente | Drag-drop dashed border, accepts PDF/JPG/PNG, shows filename + size after |
| `<TweaksPanel>` (`tweaks-panel.jsx`) | Pro, also enabled in others via toolbar toggle | Full protocol — see `tweaks-panel.jsx` |
| `<CommandPalette>` (⌘K) | Pro topbar | Fuzzy search over schema + quick-actions |
| `<MagicLinkSent>` | Login Kunde | Centered icon-card with email confirmation |
| `<OtpInput>` | Login Berater | 6 cells, auto-advance focus on input |
| `<RoleTab>` | Login | Icon + label + sub, active has surface bg + shadow |
| `<Avatar>` | All | Circular, initials fallback, gradient bg |
| `<DateChip>` | Cockpit calendar strip | Day-of-week + date number, dot for appointment, today highlighted |

## Interactions & Behavior

### Auto-save
Every form field in Pro and Erfassung debounces 500ms then PATCHes the mandant. UI: top-right dot — gray (idle) → pulse blue (saving) → green (saved) → fade. On error: red, retry inline.

### A/B plan compare (Pro-Modus)
- Topbar tabs: Plan A | Plan B | + Neuer Plan
- "Plan B erstellen" via ⌘K duplicates Plan A as sparse override
- When Plan B exists, Live-Plan shows: A as filled area, B as dashed line over it; KPIs show B value + Δ in pos/neg color
- Edit mode: editing in B-tab writes to override; resetting a field reverts to A's value

### Live-Plan recompute
Engine runs in a `useMemo` over the entire state. Re-runs on every keystroke. Charts animate (`d` attribute transition 200ms ease-out) on value change. KPIs cross-fade old→new value (200ms).

### Resizer
4px hitbox between main and Live-Plan. On `mousedown` adds full-page overlay capturing mousemove. Updates a `--liveplan-width` CSS var. Persists to `localStorage`.

### Vollbild Live-Plan
Header button toggles a class that transitions Live-Plan to fixed inset-0 with backdrop. Esc closes.

### Waterfall
KPI "Bei Pensionierung" is clickable → opens a Heute → Pension waterfall: starting balance + Beiträge - Ausgaben + Rendite = ending balance, as colored bricks.

### ⌘K palette
- `cmd+k` / `ctrl+k` opens
- Searches block titles + field labels (fuzzy)
- Enter jumps to that block, smooth-scrolls to field, highlight pulse 1.2s
- Quick actions appear at top: "Plan B erstellen", "Live-Plan Vollbild"

### Tweaks panel
See `tweaks-panel.jsx` for full protocol. Persists via `__edit_mode_set_keys` postMessage in the prototype; in production wire to user-preferences API.

### Funnel keyboard nav
Kunde funnel: ← / → arrows navigate steps when no input focused. Enter advances. Escape returns to landing.

## State Management

For production:
- **Server state:** TanStack Query / SWR — mandanten list, mandant detail, plans, appointments
- **Form state:** React Hook Form (Pro & Erfassung have ~80–120 fields; uncontrolled with refs is much faster than controlled re-renders)
- **Engine:** stateless pure-function module (`engine.js`-equivalent in `/lib/engine/`); call from a `useMemo` over the form's `getValues()` snapshot
- **Auto-save:** debounced effect on watched fields → PATCH
- **Tweaks:** persist to user-preferences endpoint; mirror in cookie for SSR

## Compliance & Engineering Open Items

- **FINMA:** Beratung must be documented (audit log of every plan change, exportable)
- **CH-DSG:** Data residency CH (Swiss-hosted DB and S3 — e.g. Exoscale / Infomaniak)
- **2FA mandatory** for Berater; recommended for Affiliate
- **Magic-link** flow for Kunde: 15-min token, single-use, rate-limited
- **PDF generation** for plan export — Swiss formatting (CHF 1'234'567.– with apostrophe thousands separator!)
- **i18n:** prepare for FR / IT (Swiss markets) but ship DE first
- **Cantonal data:** maintain table of all 26 cantons with current tax tables (or use a vendor)
- **AHV/BVG:** track yearly updates (BSV publishes new tables every Jan 1)

## NOT Yet Designed (Post-Handoff)

- `/app/termine` — week/month calendar view with drag-to-schedule
- `/app/settings` — advisor profile, branding (logo for customer PDFs), email templates
- `/affiliate/provisionen` — payout history, status pipeline, monthly statements
- `/portal` — logged-in customer portal (plan view, documents, message advisor, book appointment)

These can ship after MVP. Recommended order: Termine → Settings → Provisionen → Portal.

## Assets

No real client logos or photos — all customer/advisor names in the prototype (Familie Muster, Lukas Fischer, Fischer Vorsorge AG) are placeholders. Replace with real data before launch.

The Cuira "C" mark in the topbar/login is a simple typographic chip — if a proper logo SVG exists in the existing repo, swap it in.

Icons throughout are inline SVG with `stroke="currentColor"`, 16–20px, 2px stroke-width — Feather/Lucide-compatible. Easiest: install `lucide-react` and replace inline SVGs with `<Icon name="..."/>`.

Charts (Vermögensverlauf, Cashflow-bar, Waterfall) are hand-drawn SVG paths in the prototype. For production, use Recharts or Visx — same visual treatment (filled area, mono-line accent) is easy to reproduce.
