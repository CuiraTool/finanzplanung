/* global React, CuiraEngine */
const { useMemo: useDM } = React;

window.AreaChart = function AreaChart({ reihe, reiheB, pensionsjahr, height = 110 }) {
  if (!reihe || reihe.length === 0) return null;
  const w = 340;
  const h = height;
  const padL = 4, padR = 4, padT = 6, padB = 18;
  const xs = reihe.map((r) => r.jahr);
  const ysAll = reihe.map(r => r.vermoegenNetto).concat(reiheB ? reiheB.map(r => r.vermoegenNetto) : []);
  const minY = Math.min(0, ...ysAll);
  const maxY = Math.max(...ysAll);
  const xMin = xs[0], xMax = xs[xs.length - 1];
  const sx = (x) => padL + ((x - xMin) / Math.max(1, xMax - xMin)) * (w - padL - padR);
  const sy = (y) => padT + (1 - (y - minY) / Math.max(1, maxY - minY)) * (h - padT - padB);
  const pathOf = (r) => r.map((p, i) => `${i === 0 ? "M" : "L"} ${sx(p.jahr).toFixed(1)} ${sy(p.vermoegenNetto).toFixed(1)}`).join(" ");
  const path = pathOf(reihe);
  const area = `${path} L ${sx(xMax).toFixed(1)} ${sy(minY).toFixed(1)} L ${sx(xMin).toFixed(1)} ${sy(minY).toFixed(1)} Z`;
  const pX = pensionsjahr ? sx(pensionsjahr) : null;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} width="100%" height={h} style={{ display: "block" }}>
      <defs>
        <linearGradient id="grad-area" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="var(--cuira-deep)" stopOpacity="0.2" />
          <stop offset="100%" stopColor="var(--cuira-deep)" stopOpacity="0" />
        </linearGradient>
      </defs>
      <line x1={padL} x2={w - padR} y1={sy(0)} y2={sy(0)} stroke="var(--border)" strokeDasharray="2 3" />
      <path d={area} fill="url(#grad-area)" style={{ transition: "d 380ms cubic-bezier(.2,.9,.3,1)" }} />
      <path d={path} fill="none" stroke="var(--cuira-deep)" strokeWidth="1.6" style={{ transition: "d 380ms cubic-bezier(.2,.9,.3,1)" }} />
      {reiheB && <path d={pathOf(reiheB)} fill="none" stroke="var(--accent)" strokeWidth="1.6" strokeDasharray="3 3" style={{ transition: "d 380ms cubic-bezier(.2,.9,.3,1)" }} />}
      {pX != null && (<>
        <line x1={pX} x2={pX} y1={padT} y2={h - padB} stroke="var(--accent)" strokeDasharray="3 3" strokeWidth="1" />
        <text x={pX + 4} y={padT + 8} className="axis-tick" fill="var(--accent-ink)">Pension {pensionsjahr}</text>
      </>)}
      <text x={padL} y={h - 4} className="axis-tick">{xMin}</text>
      <text x={w - padR} y={h - 4} className="axis-tick" textAnchor="end">{xMax}</text>
    </svg>
  );
};

window.IncomeBars = function IncomeBars({ row }) {
  if (!row) return null;
  const total = Math.max(row.einkommen, row.ausgaben + row.steuern, 1);
  const seg = (val) => `${(val / total * 100).toFixed(1)}%`;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "var(--ink-3)" }}>
        <span>Jahr {row.jahr} · Alter {row.alter}</span>
        <span className="mono">Saldo {fmtCHF(row.saldoJahr)}</span>
      </div>
      <div>
        <div style={{ fontSize: 10, color: "var(--ink-3)", marginBottom: 4, display: "flex", justifyContent: "space-between" }}>
          <span>Einnahmen</span><span className="mono" style={{ color: "var(--ink-2)" }}>{fmtCHF(row.einkommen)}</span>
        </div>
        <div style={{ display: "flex", height: 8, borderRadius: 4, overflow: "hidden", background: "var(--bg-soft)" }}>
          {row.eAktiv > 0 && <div style={{ width: seg(row.eAktiv), background: "var(--cuira-deep)" }} />}
          {row.ahv > 0 && <div style={{ width: seg(row.ahv), background: "var(--accent)" }} />}
          {row.bvgRente > 0 && <div style={{ width: seg(row.bvgRente), background: "oklch(0.7 0.13 200)" }} />}
        </div>
      </div>
      <div>
        <div style={{ fontSize: 10, color: "var(--ink-3)", marginBottom: 4, display: "flex", justifyContent: "space-between" }}>
          <span>Ausgaben + Steuern</span><span className="mono" style={{ color: "var(--ink-2)" }}>{fmtCHF(row.ausgaben + row.steuern)}</span>
        </div>
        <div style={{ display: "flex", height: 8, borderRadius: 4, overflow: "hidden", background: "var(--bg-soft)" }}>
          <div style={{ width: seg(row.ausgaben), background: "oklch(0.78 0.05 25)" }} />
          <div style={{ width: seg(row.steuern), background: "var(--neg)" }} />
        </div>
      </div>
      <div className="legend">
        <span><i style={{ background: "var(--cuira-deep)" }}></i>Erwerb</span>
        <span><i style={{ background: "var(--accent)" }}></i>AHV</span>
        <span><i style={{ background: "oklch(0.7 0.13 200)" }}></i>BVG</span>
        <span><i style={{ background: "oklch(0.78 0.05 25)" }}></i>Lebenskosten</span>
        <span><i style={{ background: "var(--neg)" }}></i>Steuern</span>
      </div>
    </div>
  );
};

window.LiveDashboard = function LiveDashboard({ state, scenarioB, recalc, width, fullscreen, onFullscreen, showWaterfall, onShowWaterfall }) {
  const reihe = useDM(() => CuiraEngine.cashflowReihe(state), [state]);
  const reiheB = useDM(() => scenarioB ? CuiraEngine.cashflowReihe(scenarioB) : null, [scenarioB]);
  const bilanz = useDM(() => CuiraEngine.vermoegensbilanz(state), [state]);
  const bilanzB = useDM(() => scenarioB ? CuiraEngine.vermoegensbilanz(scenarioB) : null, [scenarioB]);
  const massnahmen = useDM(() => CuiraEngine.massnahmen(state), [state]);

  const heuteRow = reihe[0];
  const pensionRow = bilanz.pensionsjahr ? reihe.find(r => r.jahr === bilanz.pensionsjahr) : null;

  const dHeute = useDelta(bilanz.heute, 100);
  const dPension = useDelta(bilanz.pension || 0, 100);
  const dEnde = useDelta(bilanz.ende || 0, 100);

  const style = fullscreen ? {} : { width: `${width}px` };

  return (
    <aside className={`live ${fullscreen ? "is-fullscreen" : ""}`} style={style}>
      <div className="live-head">
        <div className="live-head-row">
          <div>
            <div className="live-eyebrow">Live-Plan</div>
            <div className="live-title">Vermögensbilanz {scenarioB && <span style={{ fontWeight: 400, color: "var(--ink-3)", fontSize: 12 }}>· A vs B</span>}</div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <div className={`live-pulse ${recalc ? "is-recalc" : ""}`}>
              <span className="live-pulse-dot" />
              <span>{recalc ? "rechnet…" : "synchron"}</span>
            </div>
            <button className="live-fs-btn" onClick={() => onFullscreen(!fullscreen)} title="Vollbild für Screenshare">
              {fullscreen ? "← zurück" : "⤢ Vollbild"}
            </button>
          </div>
        </div>
      </div>
      <div className="live-body">
        <div className="kpi-stack">
          <Kpi label="Nettovermögen heute" jahr={heuteRow?.jahr} value={bilanz.heute} valueB={bilanzB?.heute} delta={dHeute} hint="Aktiva − Schulden" big />
          <Kpi label="Bei Pensionierung" jahr={bilanz.pensionsjahr} value={bilanz.pension} valueB={bilanzB?.pension} delta={dPension} hint="inkl. PK-Auszahlungen" onClick={() => onShowWaterfall(!showWaterfall)} accentBtn={showWaterfall ? "↑ Waterfall" : "↓ Waterfall"} />
          <Kpi label={`Mit Alter 85`} jahr={bilanz.endeJahr} value={bilanz.ende} valueB={bilanzB?.ende} delta={dEnde} hint="Cashflow-Projektion" />
        </div>

        {showWaterfall && (
          <div>
            <div className="live-section-title"><span>Waterfall: Heute → Pension</span><em>Beiträge & Abzüge</em></div>
            <div className="chart-card"><window.Waterfall state={state} reihe={reihe} /></div>
          </div>
        )}

        <div className={fullscreen ? "area-large" : ""}>
          <div className="live-section-title">
            <span>Vermögensverlauf</span>
            <em>{reihe[0]?.jahr}–{reihe[reihe.length - 1]?.jahr}</em>
          </div>
          <div className="chart-card">
            <AreaChart reihe={reihe} reiheB={reiheB} pensionsjahr={bilanz.pensionsjahr} height={fullscreen ? 280 : 110} />
            {scenarioB && (
              <div className="legend" style={{ marginTop: 6 }}>
                <span><i style={{ background: "var(--cuira-deep)" }}></i>Plan A</span>
                <span><i style={{ background: "var(--accent)", borderRadius: 999 }}></i>Plan B</span>
              </div>
            )}
          </div>
        </div>

        {pensionRow && (
          <div>
            <div className="live-section-title"><span>Cashflow Pensionsjahr</span><em>{pensionRow.jahr}</em></div>
            <div className="chart-card"><window.IncomeBars row={pensionRow} /></div>
          </div>
        )}

        <div>
          <div className="live-section-title"><span>Massnahmen</span><em>{massnahmen.length} Empfehlungen</em></div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {massnahmen.map(m => (
              <div key={m.id} className={`massnahme prio-${m.prio}`}>
                <div className="massnahme-icon">{m.icon}</div>
                <div>
                  <div className="massnahme-title">{m.title}</div>
                  <div className="massnahme-sub">{m.sub}</div>
                </div>
                <div className="massnahme-impact">{m.impact}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </aside>
  );
};

function Kpi({ label, jahr, value, valueB, delta, hint, big, onClick, accentBtn }) {
  const [shown, flipping] = useFlipNumber(value);
  const diff = valueB != null && value != null ? valueB - value : null;
  return (
    <div className="kpi" style={{ paddingTop: big ? 14 : undefined, paddingBottom: big ? 14 : undefined, cursor: onClick ? "pointer" : "default" }} onClick={onClick}>
      <div className="kpi-row">
        <span className="kpi-label">{label}</span>
        {jahr != null && <span className="kpi-year">{jahr}</span>}
      </div>
      <div className={`kpi-value flip-num ${flipping ? "is-flip" : ""}`} style={{ fontSize: big ? 26 : 20 }}>{fmtCHF(shown)}</div>
      {valueB != null && (
        <div className="kpi-b-row">
          <span className="swatch"></span>
          <span>Plan B {fmtCHF(valueB)}</span>
          {diff != null && <span className={`kpi-b-diff ${diff >= 0 ? "is-pos" : "is-neg"}`}>{diff >= 0 ? "+" : "−"}{fmtCHF(Math.abs(diff))}</span>}
        </div>
      )}
      <div className="kpi-bump is-show" style={{ opacity: delta != null ? 1 : 0 }}>
        {delta != null && (<span className={delta < 0 ? "is-neg" : ""}>{delta >= 0 ? "+" : "−"}{fmtCHF(Math.abs(delta))}</span>)}
      </div>
      <div style={{ fontSize: 11, color: "var(--ink-3)", marginTop: 2, display: "flex", justifyContent: "space-between" }}>
        <span>{hint}</span>
        {accentBtn && <span style={{ color: "var(--accent-ink)", fontWeight: 500 }}>{accentBtn}</span>}
      </div>
    </div>
  );
}
