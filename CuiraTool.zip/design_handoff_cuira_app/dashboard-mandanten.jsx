// Cuira Berater · Mandanten-Dashboard
const { useState, useMemo, useEffect } = React;

// === Mock data ===
const HEUTE = new Date(2026, 4, 9); // 9. Mai 2026

const MANDANTEN = [
  { id: "m1", vorname: "Ralph & Stephanie", nachname: "Muster", typ: "paar", ort: "Zürich", kanton: "ZH", geb: 1967, status: "plan", letzteAktivitaet: 2, vermoegen: 3210000, gapBeiPension: -180000, naechsterTermin: { datum: new Date(2026, 4, 14), art: "Strategiegespräch" }, planVollstaendig: 78, provision: 0, prio: "hoch", herkunft: "Affiliate · Fischer Vorsorge", quelleId: "FF-201" },
  { id: "m2", vorname: "Anna",     nachname: "Brunner",     typ: "single", ort: "Winterthur", kanton: "ZH", geb: 1971, status: "termin",   letzteAktivitaet: 0, vermoegen: 1480000, gapBeiPension: 240000, naechsterTermin: { datum: new Date(2026, 4, 11), art: "Erstgespräch" }, planVollstaendig: 45, provision: 0, prio: "normal", herkunft: "Direkt", quelleId: null },
  { id: "m3", vorname: "Marco",    nachname: "Bianchi",     typ: "single", ort: "Lugano",     kanton: "TI", geb: 1963, status: "plan",     letzteAktivitaet: 1, vermoegen: 2780000, gapBeiPension: 90000,  naechsterTermin: { datum: new Date(2026, 4, 19), art: "Plan-Review" }, planVollstaendig: 92, provision: 0, prio: "normal", herkunft: "Empfehlung", quelleId: null },
  { id: "m4", vorname: "Hans & Beatrice", nachname: "Keller", typ: "paar", ort: "Bern",       kanton: "BE", geb: 1958, status: "abgeschlossen", letzteAktivitaet: 14, vermoegen: 4150000, gapBeiPension: 410000, naechsterTermin: null, planVollstaendig: 100, provision: 4800, prio: "normal", herkunft: "Affiliate · Müller Treuhand", quelleId: "MT-088" },
  { id: "m5", vorname: "Sandra",   nachname: "Iten",        typ: "single", ort: "Zug",        kanton: "ZG", geb: 1968, status: "erfasst",   letzteAktivitaet: 0, vermoegen: 985000, gapBeiPension: -45000, naechsterTermin: { datum: new Date(2026, 4, 13), art: "Erstgespräch" }, planVollstaendig: 32, provision: 0, prio: "hoch", herkunft: "Affiliate · Fischer Vorsorge", quelleId: "FF-203" },
  { id: "m6", vorname: "David",    nachname: "Schneider",   typ: "single", ort: "Basel",      kanton: "BS", geb: 1972, status: "entwurf",   letzteAktivitaet: 5, vermoegen: 645000, gapBeiPension: -210000, naechsterTermin: null, planVollstaendig: 18, provision: 0, prio: "normal", herkunft: "Direkt", quelleId: null },
  { id: "m7", vorname: "Markus & Linda", nachname: "Frei",  typ: "paar",   ort: "Luzern",     kanton: "LU", geb: 1965, status: "plan",     letzteAktivitaet: 3, vermoegen: 2240000, gapBeiPension: 60000,   naechsterTermin: { datum: new Date(2026, 4, 22), art: "Plan-Übergabe" }, planVollstaendig: 88, provision: 0, prio: "normal", herkunft: "Affiliate · Vontobel Partner", quelleId: "VP-014" },
  { id: "m8", vorname: "Esther",   nachname: "Weber",       typ: "single", ort: "St. Gallen", kanton: "SG", geb: 1960, status: "abgeschlossen", letzteAktivitaet: 28, vermoegen: 1850000, gapBeiPension: 320000, naechsterTermin: null, planVollstaendig: 100, provision: 3200, prio: "normal", herkunft: "Empfehlung", quelleId: null },
  { id: "m9", vorname: "Daniela",  nachname: "Roth",        typ: "single", ort: "Aarau",      kanton: "AG", geb: 1970, status: "termin",    letzteAktivitaet: 1, vermoegen: 1120000, gapBeiPension: -80000, naechsterTermin: { datum: new Date(2026, 4, 12), art: "Erstgespräch" }, planVollstaendig: 50, provision: 0, prio: "hoch", herkunft: "Direkt", quelleId: null },
  { id: "m10", vorname: "Thomas & Petra", nachname: "Huber", typ: "paar", ort: "Chur",        kanton: "GR", geb: 1962, status: "plan",     letzteAktivitaet: 6, vermoegen: 3680000, gapBeiPension: 180000, naechsterTermin: { datum: new Date(2026, 4, 26), art: "Plan-Review" }, planVollstaendig: 84, provision: 0, prio: "normal", herkunft: "Affiliate · Fischer Vorsorge", quelleId: "FF-198" },
  { id: "m11", vorname: "Sabine",  nachname: "Marti",       typ: "single", ort: "Thun",       kanton: "BE", geb: 1969, status: "erfasst",  letzteAktivitaet: 0, vermoegen: 720000,  gapBeiPension: -120000, naechsterTermin: { datum: new Date(2026, 4, 18), art: "Erstgespräch" }, planVollstaendig: 38, provision: 0, prio: "normal", herkunft: "Affiliate · Müller Treuhand", quelleId: "MT-091" },
  { id: "m12", vorname: "Jean",    nachname: "Dupont",      typ: "single", ort: "Genf",       kanton: "GE", geb: 1964, status: "abgeschlossen", letzteAktivitaet: 45, vermoegen: 2540000, gapBeiPension: 150000, naechsterTermin: null, planVollstaendig: 100, provision: 3800, prio: "normal", herkunft: "Direkt", quelleId: null },
];

// === Helpers ===
const fmtCHF = (n) => {
  if (n === undefined || n === null) return "—";
  const abs = Math.abs(n);
  if (abs >= 1e6) return (n / 1e6).toFixed(2).replace(".", "'") + " Mio";
  if (abs >= 1e3) return Math.round(n / 1e3) + "k";
  return String(Math.round(n));
};
const fmtCHFFull = (n) => "CHF " + Math.round(n).toLocaleString("de-CH").replace(/,/g, "'");

const STATUS_META = {
  entwurf:       { label: "Entwurf",       order: 0, cls: "s-entwurf" },
  erfasst:       { label: "Erfasst",       order: 1, cls: "s-erfasst" },
  termin:        { label: "Termin",        order: 2, cls: "s-termin" },
  plan:          { label: "Plan",          order: 3, cls: "s-plan" },
  abgeschlossen: { label: "Abgeschlossen", order: 4, cls: "s-abgeschlossen" },
};

const initialsOf = (m) => {
  if (m.typ === "paar") {
    const [a, b] = m.vorname.split(" & ");
    return (a[0] + (b ? b[0] : "")).toUpperCase();
  }
  return (m.vorname[0] + m.nachname[0]).toUpperCase();
};

const avatarColor = (id) => {
  const palette = ["#0a2540", "oklch(0.55 0.16 252)", "oklch(0.5 0.12 280)", "oklch(0.55 0.12 158)", "oklch(0.55 0.14 80)", "oklch(0.55 0.18 25)"];
  let h = 0; for (const c of id) h = (h + c.charCodeAt(0)) % palette.length;
  return palette[h];
};

const dayDiff = (d) => Math.round((d - HEUTE) / 86400000);

const relWhen = (d) => {
  if (!d) return "—";
  const diff = dayDiff(d);
  if (diff === 0) return "heute";
  if (diff === 1) return "morgen";
  if (diff > 0 && diff < 7) return `in ${diff} T.`;
  if (diff < 0) return `${-diff} T. zurück`;
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  return `${dd}.${mm}.`;
};

const relAct = (days) => {
  if (days === 0) return "heute";
  if (days === 1) return "gestern";
  if (days < 7) return `vor ${days} T.`;
  if (days < 14) return `vor ${Math.floor(days / 7)} W.`;
  return `vor ${Math.floor(days / 7)} W.`;
};

const gapClass = (gap) => gap < -50000 ? "gap-warn" : gap < 50000 ? "gap-mid" : "gap-ok";

// === Sidebar ===
function Sidebar() {
  const [active, setActive] = useState("mandanten");
  const items = [
    { id: "dashboard",   label: "Dashboard",   icon: "M3 13h7V3H3v10zm0 8h7v-6H3v6zm11 0h7V11h-7v10zm0-18v6h7V3h-7z", count: null },
    { id: "mandanten",   label: "Mandanten",   icon: "M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5s-3 1.34-3 3 1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z", count: 12 },
    { id: "termine",     label: "Termine",     icon: "M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z", count: 4 },
    { id: "provisionen", label: "Provisionen", icon: "M12 6V3a1 1 0 0 0-2 0v3H7a1 1 0 0 0 0 2h3v3a1 1 0 0 0 2 0V8h3a1 1 0 0 0 0-2h-3z M6 14a4 4 0 1 0 0 8 4 4 0 0 0 0-8zm12 0a4 4 0 1 0 0 8 4 4 0 0 0 0-8z", count: null },
    { id: "berichte",    label: "Berichte",    icon: "M9 17v-6h-2v6h2zm4 0V7h-2v10h2zm4 0v-4h-2v4h2zM5 5h14v14H5V5zm0-2c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2H5z", count: null },
  ];

  return (
    <aside className="b-side">
      <div className="b-brand">
        <div className="b-brand-mark">C</div>
        <div>
          <div className="b-brand-name">Cuira</div>
          <div className="b-brand-sub">Berater-Cockpit</div>
        </div>
      </div>

      <div className="b-nav">
        <div className="b-nav-group">Arbeitsbereich</div>
        {items.map(it => (
          <button key={it.id} className={`b-nav-item ${active === it.id ? "is-on" : ""}`} onClick={() => setActive(it.id)}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d={it.icon} /></svg>
            <span>{it.label}</span>
            {it.count != null && <span className="nav-count">{it.count}</span>}
          </button>
        ))}
        <div className="b-nav-group">Kanäle</div>
        <a className="b-nav-item" href="Cuira Erfassung.html">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></svg>
          <span>Affiliate-Erfassung</span>
        </a>
        <a className="b-nav-item" href="Cuira Kunde.html">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
          <span>Endkunden-Funnel</span>
        </a>
        <a className="b-nav-item" href="Cuira Pensionsplanung.html">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 3v18h18"/><path d="M7 14l4-4 4 4 6-6"/></svg>
          <span>Pro-Modus</span>
        </a>
      </div>

      <div className="b-side-foot">
        <div className="b-user">
          <div className="b-avatar">LF</div>
          <div>
            <div className="b-user-name">Lukas Fischer</div>
            <div className="b-user-role">Senior Berater</div>
          </div>
        </div>
      </div>
    </aside>
  );
}

// === KPI Cards ===
function KpiCard({ label, value, delta, dir, foot }) {
  return (
    <div className="kpi-card">
      <div className="kpi-label">{label}</div>
      <div className="kpi-value num">{value}</div>
      <div className="kpi-meta">
        {delta && <span className={`kpi-delta ${dir}`}>{dir === "up" ? "↑" : "↓"} {delta}</span>}
        <span>{foot}</span>
      </div>
    </div>
  );
}

// === Filter Bar ===
function FilterBar({ q, setQ, status, setStatus, sort, setSort, counts, onNew }) {
  const statusOptions = [
    { id: "all", label: "Alle", count: counts.all },
    { id: "entwurf", label: "Entwurf", count: counts.entwurf },
    { id: "erfasst", label: "Erfasst", count: counts.erfasst },
    { id: "termin", label: "Termin", count: counts.termin },
    { id: "plan", label: "Plan", count: counts.plan },
    { id: "abgeschlossen", label: "Abgeschlossen", count: counts.abgeschlossen },
  ];
  return (
    <div className="filter-bar">
      <div className="filter-search">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: "var(--ink-3)" }}>
          <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
        </svg>
        <input placeholder="Mandant suchen … (Name, Ort, ID)" value={q} onChange={e => setQ(e.target.value)} />
      </div>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
        {statusOptions.map(s => (
          <button key={s.id} className={`pill ${status === s.id ? "is-on" : ""}`} onClick={() => setStatus(s.id)}>
            {s.id !== "all" && <span className="dot" style={{ background: s.id === "termin" ? "oklch(0.55 0.14 80)" : s.id === "plan" ? "oklch(0.5 0.12 280)" : s.id === "abgeschlossen" ? "oklch(0.5 0.12 158)" : s.id === "erfasst" ? "oklch(0.55 0.12 252)" : "var(--ink-4)" }}></span>}
            {s.label}
            <span className="num" style={{ opacity: .6, fontSize: 11 }}>{s.count}</span>
          </button>
        ))}
      </div>
      <div style={{ marginLeft: "auto", display: "flex", gap: 8, alignItems: "center" }}>
        <span style={{ fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--ink-3)", letterSpacing: ".06em", textTransform: "uppercase" }}>Sortieren</span>
        <div className="seg-sort">
          <button className={sort === "termin" ? "is-on" : ""} onClick={() => setSort("termin")}>Termin</button>
          <button className={sort === "name" ? "is-on" : ""} onClick={() => setSort("name")}>Name</button>
          <button className={sort === "vermoegen" ? "is-on" : ""} onClick={() => setSort("vermoegen")}>Vermögen</button>
          <button className={sort === "aktivitaet" ? "is-on" : ""} onClick={() => setSort("aktivitaet")}>Aktivität</button>
        </div>
        <button className="btn-primary" onClick={onNew}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 5v14M5 12h14"/></svg>
          Neuer Mandant <span className="kbd">N</span>
        </button>
      </div>
    </div>
  );
}

// === Table ===
function MandantenTabelle({ rows, onOpen, onPro }) {
  if (rows.length === 0) {
    return (
      <div className="table-card">
        <div className="empty">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" style={{ color: "var(--ink-4)", marginBottom: 10 }}>
            <circle cx="12" cy="12" r="9"/><path d="M9 12h6M12 9v6"/>
          </svg>
          <h3>Keine Mandanten gefunden</h3>
          <p>Filter zurücksetzen oder einen neuen Mandanten anlegen.</p>
        </div>
      </div>
    );
  }
  return (
    <div className="table-card">
      <table className="table">
        <thead>
          <tr>
            <th>Mandant</th>
            <th>Status</th>
            <th>Plan</th>
            <th style={{ textAlign: "right" }}>Vermögen</th>
            <th style={{ textAlign: "right" }}>Δ Pension</th>
            <th>Nächster Termin</th>
            <th>Letzte Aktivität</th>
            <th style={{ width: 100 }}></th>
          </tr>
        </thead>
        <tbody>
          {rows.map(m => {
            const sm = STATUS_META[m.status];
            const termin = m.naechsterTermin;
            const isSoon = termin && dayDiff(termin.datum) <= 3 && dayDiff(termin.datum) >= 0;
            const fillCls = m.planVollstaendig >= 90 ? "pos" : m.planVollstaendig >= 60 ? "" : "warn";
            return (
              <tr key={m.id} onClick={() => onOpen(m)}>
                <td>
                  <div className="mand-cell">
                    <div className="mand-avatar" style={{ background: avatarColor(m.id) }}>{initialsOf(m)}</div>
                    <div>
                      <div className="mand-name">{m.vorname} {m.nachname}</div>
                      <div className="mand-sub">{m.ort} · {m.kanton} · {m.typ === "paar" ? "Ehepaar" : "Einzelperson"} · *{m.geb}</div>
                    </div>
                  </div>
                </td>
                <td>
                  <span className={`status-pill ${sm.cls}`}>
                    <span className="dot"></span>{sm.label}
                  </span>
                  {m.prio === "hoch" && <span className="status-pill" style={{ marginLeft: 6, color: "var(--neg)", background: "var(--neg-soft)" }}>Hoch</span>}
                </td>
                <td>
                  <div className="num" style={{ fontSize: 12.5 }}>{m.planVollstaendig}%</div>
                  <div className="mini-bar-track" style={{ width: 80 }}><div className={`mini-bar-fill ${fillCls}`} style={{ width: `${m.planVollstaendig}%` }} /></div>
                </td>
                <td className="num" style={{ textAlign: "right" }}>{fmtCHF(m.vermoegen)}</td>
                <td className="num" style={{ textAlign: "right" }}>
                  <span className={gapClass(m.gapBeiPension)}>
                    {m.gapBeiPension >= 0 ? "+" : ""}{fmtCHF(m.gapBeiPension)}
                  </span>
                </td>
                <td>
                  {termin ? (
                    <div className={`next-termin ${isSoon ? "is-soon" : ""}`}>
                      <div className="when">{termin.art}</div>
                      <div className="relwhen">{relWhen(termin.datum)}</div>
                    </div>
                  ) : <span style={{ color: "var(--ink-4)" }}>—</span>}
                </td>
                <td className="num" style={{ color: "var(--ink-2)", fontSize: 12.5 }}>{relAct(m.letzteAktivitaet)}</td>
                <td>
                  <div className="row-actions" onClick={e => e.stopPropagation()}>
                    <button className="row-action" title="Im Pro-Modus öffnen" onClick={() => onPro(m)}>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
                    </button>
                    <button className="row-action" title="Mehr">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="6" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="18" r="1.5"/></svg>
                    </button>
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// === Drawer (Mandant detail) ===
function Drawer({ m, onClose, onPro }) {
  if (!m) return null;
  const sm = STATUS_META[m.status];
  return (
    <>
      <div className={`drawer-back ${m ? "is-open" : ""}`} onClick={onClose} />
      <div className={`drawer ${m ? "is-open" : ""}`}>
        <div className="drawer-head">
          <div className="mand-avatar" style={{ background: avatarColor(m.id), width: 44, height: 44, fontSize: 14 }}>{initialsOf(m)}</div>
          <div>
            <div style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-0.01em" }}>{m.vorname} {m.nachname}</div>
            <div style={{ fontSize: 12.5, color: "var(--ink-3)", marginTop: 2 }}>
              {m.ort} · {m.kanton} · *{m.geb} · ID {m.id.toUpperCase()}
            </div>
          </div>
          <button className="x-btn" onClick={onClose} aria-label="Schliessen">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6 6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div className="drawer-body">
          <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 12 }}>
            <span className={`status-pill ${sm.cls}`}><span className="dot"></span>{sm.label}</span>
            {m.prio === "hoch" && <span className="status-pill" style={{ color: "var(--neg)", background: "var(--neg-soft)" }}>Hohe Prio</span>}
            <span className="status-pill" style={{ marginLeft: "auto" }}>{m.herkunft}</span>
          </div>

          <div className="h-section">Eckwerte</div>
          <div className="kv-grid">
            <div className="kv">
              <div className="kv-label">Vermögen heute</div>
              <div className="kv-value num">{fmtCHFFull(m.vermoegen)}</div>
            </div>
            <div className="kv">
              <div className="kv-label">Δ bei Pensionierung</div>
              <div className={`kv-value num ${gapClass(m.gapBeiPension)}`}>{m.gapBeiPension >= 0 ? "+" : ""}{fmtCHFFull(m.gapBeiPension)}</div>
            </div>
            <div className="kv">
              <div className="kv-label">Plan vollständig</div>
              <div className="kv-value num">{m.planVollstaendig}%</div>
            </div>
            <div className="kv">
              <div className="kv-label">Provision</div>
              <div className="kv-value num">{m.provision ? fmtCHFFull(m.provision) : "—"}</div>
            </div>
          </div>

          <div className="h-section">Verlauf</div>
          <div className="timeline">
            {m.naechsterTermin && (
              <div className="timeline-item">
                <div className="timeline-dot"></div>
                <div>
                  <div className="timeline-when">{relWhen(m.naechsterTermin.datum).toUpperCase()} · GEPLANT</div>
                  <div className="timeline-what">{m.naechsterTermin.art}</div>
                </div>
              </div>
            )}
            <div className="timeline-item muted">
              <div className="timeline-dot"></div>
              <div>
                <div className="timeline-when">{relAct(m.letzteAktivitaet).toUpperCase()}</div>
                <div className="timeline-what">{m.status === "plan" ? "Plan-Entwurf erstellt · Variante A" : m.status === "termin" ? "Termin bestätigt" : m.status === "erfasst" ? "Daten via Affiliate erfasst" : "Mandant angelegt"}</div>
              </div>
            </div>
            <div className="timeline-item muted">
              <div className="timeline-dot"></div>
              <div>
                <div className="timeline-when">VOR {Math.max(m.letzteAktivitaet + 7, 8)} T.</div>
                <div className="timeline-what">{m.herkunft.startsWith("Affiliate") ? `Übergabe von ${m.herkunft.replace("Affiliate · ", "")}` : "Anfrage über Endkunden-Funnel"}</div>
              </div>
            </div>
          </div>

          <div className="h-section">Quelle</div>
          <div className="kv">
            <div className="kv-label">Herkunft</div>
            <div className="kv-value" style={{ fontSize: 13, fontWeight: 400 }}>{m.herkunft}{m.quelleId && <> · <span className="num" style={{ color: "var(--ink-3)" }}>{m.quelleId}</span></>}</div>
          </div>
        </div>
        <div className="drawer-foot">
          <button className="btn-ghost" onClick={onClose}>Schliessen</button>
          <button className="btn-primary" style={{ marginLeft: "auto" }} onClick={() => onPro(m)}>
            Im Pro-Modus öffnen
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M13 5l7 7-7 7"/></svg>
          </button>
        </div>
      </div>
    </>
  );
}

// === App ===
function App() {
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [sort, setSort] = useState("termin");
  const [open, setOpen] = useState(null);
  const [view, setView] = useState("aktiv");

  // Keyboard shortcut: N for new
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "n" && !e.metaKey && !e.ctrlKey && !e.altKey && document.activeElement.tagName !== "INPUT") {
        window.location.href = "Cuira Erfassung.html";
      }
      if (e.key === "Escape") setOpen(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const counts = useMemo(() => {
    const c = { all: MANDANTEN.length, entwurf: 0, erfasst: 0, termin: 0, plan: 0, abgeschlossen: 0 };
    MANDANTEN.forEach(m => c[m.status]++);
    return c;
  }, []);

  const filtered = useMemo(() => {
    let rows = MANDANTEN.slice();
    if (view === "aktiv") rows = rows.filter(m => m.status !== "abgeschlossen");
    else if (view === "abgeschlossen") rows = rows.filter(m => m.status === "abgeschlossen");
    if (status !== "all") rows = rows.filter(m => m.status === status);
    if (q.trim()) {
      const ql = q.toLowerCase();
      rows = rows.filter(m =>
        (m.vorname + " " + m.nachname).toLowerCase().includes(ql) ||
        m.ort.toLowerCase().includes(ql) ||
        m.id.toLowerCase().includes(ql) ||
        (m.quelleId && m.quelleId.toLowerCase().includes(ql))
      );
    }
    rows.sort((a, b) => {
      if (sort === "name") return (a.nachname).localeCompare(b.nachname);
      if (sort === "vermoegen") return b.vermoegen - a.vermoegen;
      if (sort === "aktivitaet") return a.letzteAktivitaet - b.letzteAktivitaet;
      // termin
      const ad = a.naechsterTermin ? a.naechsterTermin.datum.getTime() : Infinity;
      const bd = b.naechsterTermin ? b.naechsterTermin.datum.getTime() : Infinity;
      return ad - bd;
    });
    return rows;
  }, [q, status, sort, view]);

  const newMandant = () => { window.location.href = "Cuira Erfassung.html"; };
  const openPro    = (m) => { window.location.href = "Cuira Pensionsplanung.html"; };
  const openDetail = (m) => { window.location.href = "Cuira Mandant Detail.html"; };

  // KPIs
  const aktive = MANDANTEN.filter(m => m.status !== "abgeschlossen").length;
  const termineWoche = MANDANTEN.filter(m => m.naechsterTermin && dayDiff(m.naechsterTermin.datum) >= 0 && dayDiff(m.naechsterTermin.datum) <= 7).length;
  const provisionYTD = MANDANTEN.reduce((s, m) => s + (m.provision || 0), 0);
  const aumTotal = MANDANTEN.reduce((s, m) => s + m.vermoegen, 0);

  // Calendar strip — 7 days from today
  const calDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(HEUTE);
    d.setDate(d.getDate() + i);
    const hits = MANDANTEN.filter(m => m.naechsterTermin && m.naechsterTermin.datum.toDateString() === d.toDateString());
    return { d, hits };
  });

  return (
    <div className="berater-shell">
      <Sidebar />
      <main className="b-main" data-screen-label="Mandanten-Dashboard">
        <div className="b-head">
          <div>
            <div className="b-greet">Samstag · 09. Mai 2026</div>
            <h1 className="b-title">Guten Morgen, Lukas.</h1>
            <p className="b-subtitle">Du hast {termineWoche} Termine diese Woche und 2 Mandanten warten auf eine Plan-Übergabe.</p>
          </div>
          <div className="b-actions">
            <button className="btn-ghost">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ verticalAlign: "-2px", marginRight: 4 }}>
                <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
              </svg>
              Synchronisieren
            </button>
            <button className="btn-primary" onClick={newMandant}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 5v14M5 12h14"/></svg>
              Neuer Mandant
            </button>
          </div>
        </div>

        {/* Banner with calendar strip */}
        <div className="top-banner">
          <div>
            <h2>Kommende 7 Tage</h2>
            <p>Vier Termine geplant. Anna Brunner (Mi) ist Erstgespräch — Vorsorgeausweis liegt vor.</p>
          </div>
          <div className="cal-strip" style={{ flex: 1, maxWidth: 480, marginLeft: "auto" }}>
            {calDays.map((cd, i) => {
              const isToday = cd.d.toDateString() === HEUTE.toDateString();
              return (
                <div key={i} className={`cal-day ${isToday ? "today" : ""}`}>
                  <div className="dow">{["So","Mo","Di","Mi","Do","Fr","Sa"][cd.d.getDay()]}</div>
                  <div className="dom num">{cd.d.getDate()}</div>
                  <div className="hits">
                    {cd.hits.slice(0, 3).map((_, j) => <span key={j} className="hit"></span>)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* KPIs */}
        <div className="kpi-row">
          <KpiCard label="Aktive Mandanten" value={aktive} delta="+2" dir="up" foot="vs. Vormonat" />
          <KpiCard label="Termine 7 Tage"   value={termineWoche} foot="3 bestätigt · 1 ausstehend" />
          <KpiCard label="AUM begleitet"    value={fmtCHF(aumTotal)} delta="+4.2%" dir="up" foot="seit Jahresbeginn" />
          <KpiCard label="Provision YTD"    value={fmtCHFFull(provisionYTD).replace("CHF ", "CHF ")} foot="3 abgeschlossene Pläne" />
        </div>

        {/* View tabs */}
        <div className="view-tabs">
          <button className={`view-tab ${view === "aktiv" ? "is-on" : ""}`} onClick={() => setView("aktiv")}>Aktiv ({MANDANTEN.filter(m => m.status !== "abgeschlossen").length})</button>
          <button className={`view-tab ${view === "abgeschlossen" ? "is-on" : ""}`} onClick={() => setView("abgeschlossen")}>Abgeschlossen ({MANDANTEN.filter(m => m.status === "abgeschlossen").length})</button>
          <button className={`view-tab ${view === "alle" ? "is-on" : ""}`} onClick={() => setView("alle")}>Alle ({MANDANTEN.length})</button>
        </div>

        <FilterBar
          q={q} setQ={setQ}
          status={status} setStatus={setStatus}
          sort={sort} setSort={setSort}
          counts={counts}
          onNew={newMandant}
        />

        <MandantenTabelle rows={filtered} onOpen={openDetail} onPro={openPro} />

        <Drawer m={open} onClose={() => setOpen(null)} onPro={openPro} />
      </main>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
