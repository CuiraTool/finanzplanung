/* global React, ReactDOM, CUIRA_INITIAL_STATE, CuiraEngine */
const { useState, useEffect, useMemo, useRef, useCallback } = React;

window.fmtCHF = function (n, opts = {}) {
  if (n == null || isNaN(n)) return "—";
  const abs = Math.abs(n);
  const sign = n < 0 ? "−" : "";
  if (opts.compact && abs >= 1_000_000) {
    return `${sign}CHF ${(abs / 1_000_000).toFixed(2)} Mio.`;
  }
  return `${sign}CHF ${Math.round(abs).toLocaleString("de-CH").replace(/,/g, "'")}`;
};
window.fmtNum = function (n) {
  if (n == null || isNaN(n)) return "—";
  return Math.round(n).toLocaleString("de-CH").replace(/,/g, "'");
};

// === Hooks ===
window.useFlipNumber = function (value) {
  const [shown, setShown] = useState(value);
  const [flipping, setFlipping] = useState(false);
  const prev = useRef(value);
  useEffect(() => {
    if (prev.current === value) return;
    setFlipping(true);
    const t1 = setTimeout(() => { setShown(value); }, 160);
    const t2 = setTimeout(() => setFlipping(false), 320);
    prev.current = value;
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [value]);
  return [shown, flipping];
};

// Track last delta for KPI bumps
window.useDelta = function (value, threshold = 1) {
  const prev = useRef(value);
  const [delta, setDelta] = useState(null);
  useEffect(() => {
    if (prev.current !== value) {
      const d = value - prev.current;
      if (Math.abs(d) >= threshold) {
        setDelta(d);
        const t = setTimeout(() => setDelta(null), 1600);
        prev.current = value;
        return () => clearTimeout(t);
      }
      prev.current = value;
    }
  }, [value, threshold]);
  return delta;
};
