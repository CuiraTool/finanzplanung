// Cuira · Mandant-Detail · Familie Muster
const { useState, useMemo } = React;

const HEUTE = new Date(2026, 4, 9);

const MANDANT = {
  id: "M-0142",
  vorname: "Ralph & Stephanie",
  nachname: "Muster",
  ort: "Zürich · ZH",
  typ: "paar",
  status: "plan",
  prio: "hoch",
  herkunft: "Affiliate · Fischer Vorsorge AG",
  quelleId: "FF-201",
  email: "ralph.muster@example.ch",
  telefon: "+41 79 412 88 14",
  berater: { name: "Lukas Fischer", rolle: "Senior Berater" },
  personen: [
    { name: "Ralph Muster",     geb: "12.03.1967", alter: 59, beruf: "CFO Industriegruppe",   einkommen: 168000 },
    { name: "Stephanie Muster", geb: "04.09.1972", alter: 53, beruf: "Geschäftsleiterin NGO", einkommen:  92000 },
  ],
  kinder: [{ name: "Lara", geb: 2002 }, { name: "Niko", geb: 2005 }],
  vermoegenHeute: 3210000,
  vermoegenPension: 3490000,
  gapBeiPension: -180000,
  pensionAlterP1: 64,
  pensionAlterP2: 62,
  planVollstaendig: 78,
  saeulen: { ahv: 540000, pk: 1380000, s3: 252000, frei: 1038000 },
  warnungen: [
    { type: "warn", title: "PK-Sperrfrist 3 Jahre", text: "Geplanter Einkauf 2026 (CHF 25'000). Frühester Kapitalbezug daher 2029 — Pensionsalter 64 ist möglich, aber knapp." },
    { type: "info", title: "3a-Maximum nicht ausgeschöpft", text: "Stephanie zahlt aktuell CHF 5'400/J statt Maximum CHF 7'258 (Δ CHF 1'858/J)." },
  ],
};

const PLANS = [
  { id: "A", name: "Plan A · Standard",    aktiv: true,  erstellt: new Date(2026, 4, 2), gap: -180000, pensP1: 64, pensP2: 62, bezugsart: "Mischung 50/50" },
  { id: "B", name: "Plan B · Frühpension", aktiv: false, erstellt: new Date(2026, 4, 6), gap: -340000, pensP1: 62, pensP2: 60, bezugsart: "Mischung 60/40" },
  { id: "C", name: "Plan C · Spätbezug",   aktiv: false, erstellt: new Date(2026, 4, 7), gap:  +120000, pensP1: 67, pensP2: 65, bezugsart: "Rente" },
];

const TERMINE = [
  { id: "t1", datum: new Date(2026, 4, 14), zeit: "14:00", art: "Strategiegespräch", ort: "Cuira Office Zürich", status: "bestätigt", future: true },
  { id: "t2", datum: new Date(2026, 5,  4), zeit: "10:30", art: "Plan-Übergabe",     ort: "Video-Call",          status: "geplant",   future: true },
  { id: "t3", datum: new Date(2026, 3, 18), zeit: "16:00", art: "Erstgespräch",      ort: "Cuira Office Zürich", status: "erfolgt",   future: false },
];

const DOCS = [
  { id: "d1", name: "Vorsorgeausweis Ralph 2026.pdf",     kind: "PDF", grosse: "184 KB", uploaded: 5,  von: "Affiliate" },
  { id: "d2", name: "Vorsorgeausweis Stephanie 2026.pdf", kind: "PDF", grosse: "172 KB", uploaded: 5,  von: "Affiliate" },
  { id: "d3", name: "Steuererklärung 2024.pdf",           kind: "PDF", grosse: "2.1 MB", uploaded: 22, von: "Mandant" },
  { id: "d4", name: "Hypothek ZKB Vertrag.pdf",           kind: "PDF", grosse: "612 KB", uploaded: 22, von: "Mandant" },
  { id: "d5", name: "3a-Übersicht VIAC.pdf",              kind: "PDF", grosse:  "94 KB", uploaded: 14, von: "Mandant" },
];

const NOTIZEN = [
  { id: "n1", autor: "Lukas Fischer",   datum: 1, tag: "intern",  text: "Ralph präferiert Mischung mit Kapitalanteil 50%. Stephanie eher Rente. Im Termin Szenarien nebeneinander zeigen." },
  { id: "n2", autor: "Lukas Fischer",   datum: 5, tag: "kunde",   text: "Wunsch: Niko studiert ab 2025 in Lausanne — zusätzliche Belastung CHF 30'000/J für 4 Jahre. In Wunsch-Ausgaben einrechnen." },
  { id: "n3", autor: "Daniel Fischer (Affiliate)", datum: 12, tag: "übergabe", text: "Vorsorgeausweise sind aktuell. Steuererklärung 2024 nachträglich vom Treuhänder. Familie ist top-vorbereitet." },
];

const AKTIVITAET = [
  { id: "a1", datum: new Date(2026, 4, 14), kind: "termin",  what: "Strategiegespräch geplant",   detail: "14:00 Uhr · Cuira Office Zürich",       future: true },
  { id: "a2", datum: new Date(2026, 4,  7), kind: "plan",    what: "Plan C · Spätbezug erstellt", detail: "Bezugsalter 67/65 · Δ +120'000 CHF" },
  { id: "a3", datum: new Date(2026, 4,  6), kind: "plan",    what: "Plan B · Frühpension erstellt", detail: "Bezugsalter 62/60 · Δ −340'000 CHF" },
  { id: "a4", datum: new Date(2026, 4,  4), kind: "notiz",   what: "Notiz hinzugefügt",            detail: "Ralph präferiert Mischung mit Kapitalanteil 50%…" },
  { id: "a5", datum: new Date(2026, 4,  2), kind: "plan",    what: "Plan A · Standard erstellt",   detail: "Bezugsalter 64/62 · Δ −180'000 CHF" },
  { id: "a6", datum: new Date(2026, 3, 18), kind: "termin",  what: "Erstgespräch erfolgt",         detail: "16:00 · Übergabe-Notiz erfasst" },
  { id: "a7", datum: new Date(2026, 3,  4), kind: "doc",     what: "5 Dokumente hochgeladen",      detail: "Vorsorgeausweise, Steuererklärung, 3a-Übersicht" },
  { id: "a8", datum: new Date(2026, 3,  4), kind: "system",  what: "Mandant via Affiliate erstellt", detail: "Fischer Vorsorge AG · ID FF-201" },
];

// === Helpers ===
const fmtCHF = (n) => "CHF " + Math.round(n).toLocaleString("de-CH").replace(/,/g, "'");
const fmtCHFShort = (n) => {
  const abs = Math.abs(n);
  if (abs >= 1e6) return (n / 1e6).toFixed(2).replace(".", "'") + " Mio";
  if (abs >= 1e3) return Math.round(n / 1e3) + "k";
  return String(Math.round(n));
};
const dayDiff = (d) => Math.round((d - HEUTE) / 86400000);
const relWhen = (d, days) => {
  if (days !== undefined) {
    if (days === 0) return "heute";
    if (days === 1) return "gestern";
    if (days < 7) return `vor ${days} T.`;
    if (days < 30) return `vor ${Math.floor(days / 7)} W.`;
    if (days < 365) return `vor ${Math.floor(days / 30)} Mt.`;
    return `vor ${Math.floor(days / 365)} J.`;
  }
  if (!d) return "—";
  const diff = dayDiff(d);
  if (diff === 0) return "heute";
  if (diff === 1) return "morgen";
  if (diff > 0 && diff < 7) return `in ${diff} T.`;
  if (diff < 0) return `${-diff} T. zurück`;
  return d.toLocaleDateString("de-CH");
};

// === Header ===
function DetailHeader({ m }) {
  return (
    <>
      <div className="breadcrumb">
        <a href="Cuira Mandanten.html" className="crumb-back">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="m15 18-6-6 6-6"/></svg>
          Mandanten
        </a>
        <span className="sep">/</span>
        <span>{m.vorname} {m.nachname}</span>
      </div>
      <div className="detail-head">
        <div className="detail-avatar" style={{ background: "linear-gradient(135deg, #0a2540, oklch(0.55 0.16 252))" }}>RM</div>
        <div style={{ flex: 1 }}>
          <h1>{m.vorname} {m.nachname}</h1>
          <div className="detail-meta">
            <span className="status-pill s-plan"><span className="dot"></span>Plan in Arbeit</span>
            <span className="status-pill s-prio-hoch">Hohe Prio</span>
            <span className="status-pill s-affiliate">{m.herkunft}</span>
            <span className="dot"></span>
            <span>{m.ort}</span>
            <span className="dot"></span>
            <span className="num">ID {m.id}</span>
          </div>
        </div>
        <div className="detail-actions">
          <button className="btn-ghost">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
            Termin buchen
          </button>
          <button className="btn-ghost">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 5v14M5 12h14"/></svg>
            Neuer Plan
          </button>
          <a className="btn-primary" href="Cuira Pensionsplanung.html">
            Im Pro-Modus öffnen
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M7 17 17 7M7 7h10v10"/></svg>
          </a>
        </div>
      </div>
    </>
  );
}

// === Tabs ===
function TabBar({ tab, setTab }) {
  const tabs = [
    { id: "uebersicht", label: "Übersicht" },
    { id: "plaene",     label: "Pläne",      count: PLANS.length },
    { id: "termine",    label: "Termine",    count: TERMINE.length },
    { id: "dokumente",  label: "Dokumente",  count: DOCS.length },
    { id: "notizen",    label: "Notizen",    count: NOTIZEN.length },
    { id: "aktivitaet", label: "Aktivität" },
  ];
  return (
    <div className="tabbar">
      {tabs.map(t => (
        <button key={t.id} className={`tab ${tab === t.id ? "is-on" : ""}`} onClick={() => setTab(t.id)}>
          {t.label}
          {t.count != null && <span className="badge num">{t.count}</span>}
        </button>
      ))}
    </div>
  );
}

// === Vermögenschart ===
function VerlaufChart() {
  const W = 760, H = 200;
  const start = 2026, pension = 2031;
  const years = Array.from({ length: 14 }, (_, i) => start + i);
  const series = [3210000, 3320000, 3440000, 3560000, 3490000, 3380000, 3260000, 3140000, 3010000, 2870000, 2720000, 2560000, 2390000, 2210000];
  const max = 3700000, min = 2100000;
  const x = (i) => 40 + (i / (years.length - 1)) * (W - 60);
  const y = (v) => H - 20 - ((v - min) / (max - min)) * (H - 40);
  const path = series.map((v, i) => `${i === 0 ? "M" : "L"}${x(i)},${y(v)}`).join(" ");
  const fill = path + ` L${x(years.length - 1)},${H - 20} L${x(0)},${H - 20} Z`;
  const pensionX = x(years.indexOf(pension));
  return (
    <svg className="v-chart" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none">
      <defs>
        <linearGradient id="vfill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="oklch(0.55 0.16 252)" stopOpacity="0.25" />
          <stop offset="100%" stopColor="oklch(0.55 0.16 252)" stopOpacity="0" />
        </linearGradient>
      </defs>
      {/* Y-grid */}
      {[0.25, 0.5, 0.75].map((p, i) => (
        <line key={i} x1="40" x2={W - 20} y1={20 + p * (H - 40)} y2={20 + p * (H - 40)} stroke="var(--border)" strokeDasharray="2 4" />
      ))}
      {/* Pension marker */}
      <line x1={pensionX} x2={pensionX} y1="10" y2={H - 20} stroke="oklch(0.55 0.14 80)" strokeDasharray="3 3" />
      <text x={pensionX} y="14" fontSize="9" fill="oklch(0.5 0.14 80)" fontFamily="var(--font-mono)" textAnchor="middle">PENSION 2031</text>
      {/* Area */}
      <path d={fill} fill="url(#vfill)" />
      <path d={path} fill="none" stroke="oklch(0.55 0.16 252)" strokeWidth="2" />
      {/* Today dot */}
      <circle cx={x(0)} cy={y(series[0])} r="4" fill="oklch(0.55 0.16 252)" stroke="white" strokeWidth="2" />
      <circle cx={x(years.indexOf(pension))} cy={y(series[years.indexOf(pension)])} r="4" fill="oklch(0.55 0.14 80)" stroke="white" strokeWidth="2" />
      {/* Year labels */}
      {[0, 5, 10, 13].map(i => (
        <text key={i} x={x(i)} y={H - 4} fontSize="9.5" fill="var(--ink-3)" fontFamily="var(--font-mono)" textAnchor="middle">{years[i]}</text>
      ))}
      {/* Y labels */}
      {[max, (max + min) / 2, min].map((v, i) => (
        <text key={i} x="36" y={20 + i * ((H - 40) / 2) + 3} fontSize="9.5" fill="var(--ink-3)" fontFamily="var(--font-mono)" textAnchor="end">
          {fmtCHFShort(v)}
        </text>
      ))}
    </svg>
  );
}

// === Übersicht Tab ===
function TabUebersicht({ m }) {
  const total = m.saeulen.ahv + m.saeulen.pk + m.saeulen.s3 + m.saeulen.frei;
  const pct = (v) => ((v / total) * 100).toFixed(1);
  return (
    <div className="grid-2">
      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        <div className="card">
          <div className="hero-kpi">
            <div className="hero-kpi-cell">
              <div className="hero-kpi-label">Vermögen heute</div>
              <div className="hero-kpi-value num">{fmtCHF(m.vermoegenHeute)}</div>
              <div className="hero-kpi-meta">Konten · Depots · 3a · PK · Immobilien</div>
            </div>
            <div className="hero-kpi-cell">
              <div className="hero-kpi-label">Bei Pensionierung</div>
              <div className="hero-kpi-value num">{fmtCHF(m.vermoegenPension)}</div>
              <div className="hero-kpi-meta">Plan A · Bezugsalter 64/62</div>
            </div>
            <div className="hero-kpi-cell">
              <div className="hero-kpi-label">Δ vs. Wunsch</div>
              <div className={`hero-kpi-value num ${m.gapBeiPension < 0 ? "gap-warn" : "gap-ok"}`}>
                {m.gapBeiPension >= 0 ? "+" : ""}{fmtCHF(m.gapBeiPension)}
              </div>
              <div className="hero-kpi-meta">Lücke bei 120k CHF/J Wunschverbrauch</div>
            </div>
          </div>
          <div className="hero-chart">
            <VerlaufChart />
          </div>
          <div className="legend">
            <div className="legend-item"><span className="legend-swatch" style={{ background: "oklch(0.55 0.16 252)" }}></span>Vermögensverlauf · Plan A</div>
            <div className="legend-item"><span className="legend-swatch" style={{ background: "oklch(0.55 0.14 80)" }}></span>Pensionierung 2031</div>
          </div>
        </div>

        {/* Vorsorge-Snapshot */}
        <div className="card">
          <div className="card-head">
            <h3>Vorsorge-Snapshot</h3>
            <span className="card-meta">Stand 09.05.2026</span>
          </div>
          <div className="card-body">
            <div className="snap-grid" style={{ marginBottom: 14 }}>
              <div className="snap-cell"><div className="snap-label">1. Säule (AHV)</div><div className="snap-value num">{fmtCHFShort(m.saeulen.ahv)}</div><div className="snap-sub">Hochgerechnet · Faktor 1.00 / 1.00</div></div>
              <div className="snap-cell"><div className="snap-label">2. Säule (PK + FZ)</div><div className="snap-value num">{fmtCHFShort(m.saeulen.pk)}</div><div className="snap-sub">USW 5.4% · Mischung 50/50</div></div>
              <div className="snap-cell"><div className="snap-label">3. Säule</div><div className="snap-value num">{fmtCHFShort(m.saeulen.s3)}</div><div className="snap-sub">3a + 3b · 2 Konten · 1 Police</div></div>
              <div className="snap-cell"><div className="snap-label">Freies Vermögen</div><div className="snap-value num">{fmtCHFShort(m.saeulen.frei)}</div><div className="snap-sub">Konten · Depot · Immobilie netto</div></div>
            </div>
            <div className="stack-bar">
              <div style={{ width: pct(m.saeulen.ahv) + "%", background: "var(--cuira-deep)" }}>{pct(m.saeulen.ahv)}%</div>
              <div style={{ width: pct(m.saeulen.pk)  + "%", background: "oklch(0.45 0.14 252)" }}>{pct(m.saeulen.pk)}%</div>
              <div style={{ width: pct(m.saeulen.s3)  + "%", background: "oklch(0.55 0.16 252)" }}>{pct(m.saeulen.s3)}%</div>
              <div style={{ width: pct(m.saeulen.frei)+ "%", background: "oklch(0.7 0.1 252)"  }}>{pct(m.saeulen.frei)}%</div>
            </div>
            <div className="legend" style={{ padding: "12px 0 0" }}>
              <div className="legend-item"><span className="legend-swatch" style={{ background: "var(--cuira-deep)" }}></span>1. Säule</div>
              <div className="legend-item"><span className="legend-swatch" style={{ background: "oklch(0.45 0.14 252)" }}></span>2. Säule</div>
              <div className="legend-item"><span className="legend-swatch" style={{ background: "oklch(0.55 0.16 252)" }}></span>3. Säule</div>
              <div className="legend-item"><span className="legend-swatch" style={{ background: "oklch(0.7 0.1 252)" }}></span>Freies Vermögen</div>
            </div>
          </div>
        </div>

        {/* Warnungen */}
        <div className="card">
          <div className="card-head"><h3>Hinweise & Massnahmen</h3><span className="card-meta">{m.warnungen.length} aktiv</span></div>
          <div className="card-body" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {m.warnungen.map((w, i) => (
              <div key={i} className={`alert alert-${w.type}`}>
                <svg className="alert-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  {w.type === "warn" ? <><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4M12 17h.01"/></> : <><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></>}
                </svg>
                <div><strong>{w.title}</strong> — {w.text}</div>
              </div>
            ))}
            <div className="alert alert-pos">
              <svg className="alert-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/></svg>
              <div><strong>Vorsorgeausweise aktuell</strong> — Beide Vorsorgeausweise vom Februar 2026 vorhanden. Keine Aktualisierung nötig.</div>
            </div>
          </div>
        </div>
      </div>

      {/* Right rail */}
      <div className="rail">
        <div className="card">
          <div className="card-head"><h3>Plan-Vollständigkeit</h3></div>
          <div className="card-body">
            <div className="progress-ring-wrap">
              <svg className="ring" viewBox="0 0 64 64">
                <circle cx="32" cy="32" r="26" fill="none" stroke="var(--bg-soft)" strokeWidth="6" />
                <circle cx="32" cy="32" r="26" fill="none" stroke="oklch(0.55 0.16 252)" strokeWidth="6" strokeLinecap="round"
                  strokeDasharray={`${(m.planVollstaendig / 100) * 163.36} 163.36`} transform="rotate(-90 32 32)" />
              </svg>
              <div>
                <div className="ring-text num">{m.planVollstaendig}%</div>
                <div style={{ fontSize: 12, color: "var(--ink-2)" }}>9 von 10 Blöcken erfasst</div>
              </div>
            </div>
            <div style={{ marginTop: 12 }}>
              <div className="quick-row"><span>Personen, Ziele, Budget</span><span>✓</span></div>
              <div className="quick-row"><span>AHV, PK, 3. Säule</span><span>✓</span></div>
              <div className="quick-row"><span>Vermögen, Immobilien</span><span>✓</span></div>
              <div className="quick-row"><span>Nachlass</span><span style={{ color: "var(--warn)" }}>offen</span></div>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-head"><h3>Personen</h3></div>
          <div className="card-body">
            {m.personen.map((p, i) => (
              <div key={i} className="person-card">
                <div className="person-avatar">{p.name.split(" ")[0][0]}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13.5, fontWeight: 500 }}>{p.name}</div>
                  <div className="person-meta">{p.alter} J. · {p.beruf} · {fmtCHFShort(p.einkommen)}/J</div>
                </div>
              </div>
            ))}
            <div style={{ borderTop: "1px dashed var(--border)", marginTop: 8, paddingTop: 8 }}>
              <div style={{ fontSize: 11, fontFamily: "var(--font-mono)", color: "var(--ink-3)", letterSpacing: ".06em", textTransform: "uppercase", marginBottom: 6 }}>Kinder</div>
              {m.kinder.map((k, i) => (
                <div key={i} style={{ fontSize: 12.5, color: "var(--ink-2)" }}>{k.name} · *{k.geb}</div>
              ))}
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-head"><h3>Kontakt</h3><a href="#" className="card-link">Bearbeiten</a></div>
          <div className="card-body" style={{ fontSize: 13 }}>
            <div className="quick-row"><span>E-Mail</span><span className="num" style={{ fontSize: 12.5 }}>{m.email}</span></div>
            <div className="quick-row"><span>Telefon</span><span className="num">{m.telefon}</span></div>
            <div className="quick-row"><span>Berater</span><span>{m.berater.name}</span></div>
            <div className="quick-row"><span>Zugewiesen seit</span><span className="num">04.04.2026</span></div>
          </div>
        </div>

        <div className="card">
          <div className="card-head"><h3>Schnellaktionen</h3></div>
          <div className="card-body" style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <button className="btn-ghost" style={{ justifyContent: "flex-start", width: "100%" }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
              Plan per E-Mail senden
            </button>
            <button className="btn-ghost" style={{ justifyContent: "flex-start", width: "100%" }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/></svg>
              PDF generieren
            </button>
            <button className="btn-ghost" style={{ justifyContent: "flex-start", width: "100%" }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
              Mit-Berater einladen
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// === Pläne Tab ===
function TabPlaene() {
  return (
    <div className="card">
      <div className="card-head"><h3>Pläne · 3 Varianten</h3>
        <button className="btn-ghost" style={{ marginLeft: "auto" }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 5v14M5 12h14"/></svg>
          Neuer Plan
        </button>
      </div>
      <div className="card-body" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {PLANS.map(p => (
          <div key={p.id} className={`plan-card ${p.aktiv ? "is-current" : ""}`}>
            <div className="plan-letter">{p.id}</div>
            <div style={{ flex: 1 }}>
              <div className="plan-name">{p.name}</div>
              <div className="plan-meta">Pension {p.pensP1}/{p.pensP2} · {p.bezugsart} · erstellt {p.erstellt.toLocaleDateString("de-CH")}</div>
            </div>
            <div style={{ textAlign: "right", marginRight: 16 }}>
              <div style={{ fontSize: 11, fontFamily: "var(--font-mono)", letterSpacing: ".06em", textTransform: "uppercase", opacity: .7 }}>Δ Pension</div>
              <div className={`plan-num ${p.aktiv ? "" : (p.gap < 0 ? "gap-warn" : "gap-ok")}`} style={{ fontSize: 16 }}>
                {p.gap >= 0 ? "+" : ""}{fmtCHFShort(p.gap)}
              </div>
            </div>
            {p.aktiv && <span style={{ fontSize: 11, fontFamily: "var(--font-mono)", padding: "3px 8px", background: "rgba(255,255,255,.18)", borderRadius: 6, color: "white" }}>AKTIV</span>}
            <button className="btn-ghost" style={{ background: p.aktiv ? "rgba(255,255,255,.12)" : undefined, borderColor: p.aktiv ? "rgba(255,255,255,.3)" : undefined, color: p.aktiv ? "white" : undefined }}>
              Öffnen
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// === Termine Tab ===
function TabTermine() {
  const future = TERMINE.filter(t => t.future);
  const past = TERMINE.filter(t => !t.future);
  return (
    <div className="grid-2">
      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        <div className="card">
          <div className="card-head"><h3>Geplant</h3><span className="card-meta">{future.length} Termine</span></div>
          <div className="card-body">
            {future.map(t => {
              const m = ["Jan","Feb","Mär","Apr","Mai","Jun","Jul","Aug","Sep","Okt","Nov","Dez"];
              return (
                <div key={t.id} className="termin-row">
                  <div className="termin-date future">
                    <div className="dom num">{t.datum.getDate()}</div>
                    <div className="mon">{m[t.datum.getMonth()]}</div>
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 500 }}>{t.art}</div>
                    <div className="termin-meta">{t.zeit} · {t.ort} · {relWhen(t.datum)}</div>
                  </div>
                  <span className="status-pill" style={{ background: "var(--pos-soft)", color: "var(--pos)" }}>{t.status}</span>
                  <button className="btn-ghost">Verwalten</button>
                </div>
              );
            })}
          </div>
        </div>
        <div className="card">
          <div className="card-head"><h3>Vergangen</h3><span className="card-meta">{past.length} Termin{past.length !== 1 ? "e" : ""}</span></div>
          <div className="card-body">
            {past.map(t => {
              const m = ["Jan","Feb","Mär","Apr","Mai","Jun","Jul","Aug","Sep","Okt","Nov","Dez"];
              return (
                <div key={t.id} className="termin-row" style={{ opacity: .75 }}>
                  <div className="termin-date">
                    <div className="dom num">{t.datum.getDate()}</div>
                    <div className="mon">{m[t.datum.getMonth()]}</div>
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 500 }}>{t.art}</div>
                    <div className="termin-meta">{t.zeit} · {t.ort} · Notiz vorhanden</div>
                  </div>
                  <span className="status-pill">{t.status}</span>
                  <button className="btn-ghost">Notiz</button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      <div className="rail">
        <div className="card">
          <div className="card-head"><h3>Schnell buchen</h3></div>
          <div className="card-body">
            <button className="btn-primary" style={{ width: "100%", justifyContent: "center", marginBottom: 8 }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
              Termin im Kalender
            </button>
            <button className="btn-ghost" style={{ width: "100%", justifyContent: "center" }}>
              Buchungslink an Mandant senden
            </button>
            <div style={{ marginTop: 14, padding: "10px 12px", background: "var(--accent-soft)", borderRadius: 8, fontSize: 12, color: "var(--accent-ink)" }}>
              Mandant erhält per E-Mail einen Cuira-Buchungslink mit deinen freien Slots der nächsten 14 Tage.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// === Dokumente ===
function TabDokumente() {
  return (
    <div className="card">
      <div className="card-head"><h3>Dokumente · {DOCS.length}</h3>
        <button className="btn-ghost" style={{ marginLeft: "auto" }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
          Hochladen
        </button>
      </div>
      <div className="card-body">
        {DOCS.map(d => (
          <div key={d.id} className="doc-row">
            <div className="doc-icon"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg></div>
            <div style={{ flex: 1 }}>
              <div className="doc-name">{d.name}</div>
              <div className="doc-meta">{d.kind} · {d.grosse} · vor {d.uploaded} T. · von {d.von}</div>
            </div>
            <div className="doc-actions">
              <button className="btn-ghost" style={{ padding: "5px 10px" }}>Ansehen</button>
              <button className="btn-ghost" style={{ padding: "5px 10px" }}>Download</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// === Notizen ===
function TabNotizen() {
  const [tag, setTag] = useState("intern");
  return (
    <div className="grid-2">
      <div className="card">
        <div className="card-head"><h3>Notizen · {NOTIZEN.length}</h3></div>
        <div className="card-body">
          {NOTIZEN.map(n => (
            <div key={n.id} className="note">
              <div className="note-author">
                <strong style={{ color: "var(--ink-2)" }}>{n.autor}</strong>
                <span>· vor {n.datum} T.</span>
                <span className="tl-tag" style={{ marginLeft: "auto" }}>{n.tag}</span>
              </div>
              <div className="note-text">{n.text}</div>
            </div>
          ))}
          <div className="note-compose">
            <textarea placeholder="Neue Notiz hinzufügen…" />
            <div className="note-compose-foot">
              <div className="note-tag-pick">
                {["intern","kunde","übergabe"].map(t => (
                  <button key={t} className={`pill ${tag === t ? "is-on" : ""}`} onClick={() => setTag(t)}>{t}</button>
                ))}
              </div>
              <button className="btn-primary" style={{ padding: "5px 12px" }}>Speichern</button>
            </div>
          </div>
        </div>
      </div>
      <div className="rail">
        <div className="card">
          <div className="card-head"><h3>Notiz-Tags</h3></div>
          <div className="card-body" style={{ fontSize: 13 }}>
            <div className="quick-row"><span><span className="tl-tag">intern</span></span><span className="num">2</span></div>
            <div className="quick-row"><span><span className="tl-tag">kunde</span></span><span className="num">1</span></div>
            <div className="quick-row"><span><span className="tl-tag">übergabe</span></span><span className="num">1</span></div>
          </div>
        </div>
      </div>
    </div>
  );
}

// === Aktivität ===
function TabAktivitaet() {
  const kindIcon = {
    termin: "M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11z",
    plan:   "M3 3v18h18M7 14l4-4 4 4 6-6",
    notiz:  "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25z",
    doc:    "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z",
    system: "M12 2 2 22h20L12 2z",
  };
  return (
    <div className="card">
      <div className="card-head"><h3>Aktivität · {AKTIVITAET.length}</h3>
        <span className="card-meta">Vollständige Historie</span>
      </div>
      <div className="card-body">
        <div className="timeline">
          {AKTIVITAET.map(a => {
            const days = a.future ? null : Math.round((HEUTE - a.datum) / 86400000);
            return (
              <div key={a.id} className={`tl-item ${a.future ? "is-future" : days > 30 ? "is-muted" : ""}`}>
                <div className="tl-rail">
                  <div className="tl-dot"></div>
                  <div className="tl-line"></div>
                </div>
                <div style={{ flex: 1, paddingBottom: 14 }}>
                  <div className="tl-when">
                    {a.future ? `IN ${dayDiff(a.datum)} T. · ${a.datum.toLocaleDateString("de-CH")}` : `VOR ${days} T. · ${a.datum.toLocaleDateString("de-CH")}`}
                  </div>
                  <div className="tl-what">
                    <span className="tl-tag">{a.kind}</span>
                    {a.what}
                  </div>
                  <div className="tl-detail">{a.detail}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// === Sidebar (geteilt mit Mandanten-Dashboard) ===
function Sidebar() {
  return (
    <aside className="b-side">
      <div className="b-brand">
        <div className="b-brand-mark">C</div>
        <div>
          <div className="b-brand-name">Cuira</div>
          <div className="b-brand-sub">Berater-Cockpit</div>
        </div>
      </div>
      <div className="b-nav">
        <div className="b-nav-group">Arbeitsbereich</div>
        <a className="b-nav-item" href="Cuira Mandanten.html">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M3 13h7V3H3v10zm0 8h7v-6H3v6zm11 0h7V11h-7v10zm0-18v6h7V3h-7z"/></svg>
          <span>Dashboard</span>
        </a>
        <a className="b-nav-item is-on" href="Cuira Mandanten.html">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5s-3 1.34-3 3 1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5z"/></svg>
          <span>Mandanten</span>
        </a>
        <a className="b-nav-item" href="#">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11z"/></svg>
          <span>Termine</span>
        </a>
        <div className="b-nav-group">Kanäle</div>
        <a className="b-nav-item" href="Cuira Erfassung.html">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></svg>
          <span>Affiliate-Erfassung</span>
        </a>
        <a className="b-nav-item" href="Cuira Kunde.html">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
          <span>Endkunden-Funnel</span>
        </a>
        <a className="b-nav-item" href="Cuira Pensionsplanung.html">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 3v18h18"/><path d="M7 14l4-4 4 4 6-6"/></svg>
          <span>Pro-Modus</span>
        </a>
      </div>
      <div className="b-side-foot">
        <div className="b-user">
          <div className="b-avatar">LF</div>
          <div>
            <div className="b-user-name">Lukas Fischer</div>
            <div className="b-user-role">Senior Berater</div>
          </div>
        </div>
      </div>
    </aside>
  );
}

// === App ===
function App() {
  const [tab, setTab] = useState("uebersicht");
  return (
    <div className="berater-shell">
      <Sidebar />
      <main className="b-main" data-screen-label="Mandant Detail">
        <DetailHeader m={MANDANT} />
        <TabBar tab={tab} setTab={setTab} />
        <div className="tab-body">
          {tab === "uebersicht" && <TabUebersicht m={MANDANT} />}
          {tab === "plaene"     && <TabPlaene />}
          {tab === "termine"    && <TabTermine />}
          {tab === "dokumente"  && <TabDokumente />}
          {tab === "notizen"    && <TabNotizen />}
          {tab === "aktivitaet" && <TabAktivitaet />}
        </div>
      </main>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
