/* global React */
const { useState: useS, useMemo: useM } = React;

// === Field primitives ===
window.Field = function Field({ label, hint, children, suffix }) {
  return (
    <div className="field">
      <label className="field-label">{label}</label>
      {children}
      {hint && <div className="field-hint">{hint}</div>}
    </div>
  );
};

window.NumInput = function NumInput({ value, onChange, suffix = "CHF", placeholder, step = 1 }) {
  return (
    <div className="input-shell">
      <input
        type="number"
        className="input tabnum-input"
        value={value ?? ""}
        step={step}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value === "" ? null : Number(e.target.value))}
      />
      <span className="input-suffix">{suffix}</span>
    </div>
  );
};

window.TextInput = function TextInput({ value, onChange, placeholder }) {
  return (
    <input
      type="text"
      className="input"
      value={value ?? ""}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
    />
  );
};

window.YesNo = function YesNo({ value, onChange }) {
  return (
    <div className="yesno">
      <button className={value === true ? "is-active" : ""} onClick={() => onChange(true)}>Ja</button>
      <button className={value === false ? "is-active" : ""} onClick={() => onChange(false)}>Nein</button>
    </div>
  );
};

window.Segmented = function Segmented({ options, value, onChange }) {
  return (
    <div className="seg">
      {options.map((o) => (
        <button
          key={o.value}
          className={`seg-btn ${value === o.value ? "is-active" : ""}`}
          onClick={() => onChange(o.value)}
        >
          {o.label}
          {o.sub && <span className="seg-sub">{o.sub}</span>}
        </button>
      ))}
    </div>
  );
};

window.Slider = function Slider({ min, max, step = 1, value, onChange, format }) {
  return (
    <div className="slider-row">
      <div className="slider-track">
        <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} />
      </div>
      <div className="slider-value">{format ? format(value) : value}</div>
    </div>
  );
};

// === Block 1: Personen ===
window.Block1 = function Block1({ state, set }) {
  const Per = ({ idx, p, on }) => (
    <div className="card">
      <div className="card-head">
        <div>
          <div className="card-title">Person {idx} {state.fallart === "paar" ? `· ${p.vorname || ""}` : ""}</div>
          <div className="card-desc">Stammdaten — werden für AHV-Berechnung und Steuersatz verwendet.</div>
        </div>
      </div>
      <div className="card-grid cols-2">
        <Field label="Vorname"><TextInput value={p.vorname} onChange={(v) => on({ vorname: v })} /></Field>
        <Field label="Nachname"><TextInput value={p.nachname} onChange={(v) => on({ nachname: v })} /></Field>
        <Field label="Geburtsdatum">
          <input type="date" className="input tabnum-input" value={p.geburtsdatum} onChange={(e) => on({ geburtsdatum: e.target.value })} />
        </Field>
        <Field label="Zivilstand">
          <select className="input" value={p.zivilstand} onChange={(e) => on({ zivilstand: e.target.value })}>
            <option value="ledig">ledig</option>
            <option value="verheiratet">verheiratet</option>
            <option value="getrennt">getrennt</option>
            <option value="geschieden">geschieden</option>
            <option value="verwitwet">verwitwet</option>
          </select>
        </Field>
      </div>
    </div>
  );
  return (
    <>
      <div className="card">
        <div className="card-head">
          <div>
            <div className="card-title">Fallart</div>
            <div className="card-desc">Steuert Sektionen, Plafonds und die Paar-Logik im gesamten Wizard.</div>
          </div>
        </div>
        <Segmented
          options={[
            { value: "einzel", label: "Einzelperson" },
            { value: "paar", label: "Ehepaar" },
            { value: "konkubinat", label: "Konkubinat" },
          ]}
          value={state.fallart}
          onChange={(v) => set({ fallart: v })}
        />
      </div>
      <Per idx={1} p={state.person1} on={(patch) => set({ person1: { ...state.person1, ...patch } })} />
      {state.fallart !== "einzel" && (
        <Per idx={2} p={state.person2} on={(patch) => set({ person2: { ...state.person2, ...patch } })} />
      )}
      <div className="card">
        <div className="card-head">
          <div>
            <div className="card-title">Adresse</div>
            <div className="card-desc">Wohnsitz bestimmt Kantons- und Gemeindesteuer (aktuell ZH-Approximation).</div>
          </div>
        </div>
        <div className="card-grid cols-3" style={{ gridTemplateColumns: "2fr 1fr 1fr" }}>
          <Field label="Strasse"><TextInput value={state.adresse.strasse} onChange={(v) => set({ adresse: { ...state.adresse, strasse: v } })} /></Field>
          <Field label="PLZ"><TextInput value={state.adresse.plz} onChange={(v) => set({ adresse: { ...state.adresse, plz: v } })} /></Field>
          <Field label="Ort"><TextInput value={state.adresse.ort} onChange={(v) => set({ adresse: { ...state.adresse, ort: v } })} /></Field>
        </div>
      </div>
    </>
  );
};

// === Block 2: Ziele ===
window.Block2 = function Block2({ state, set }) {
  const z = state.ziele;
  const onZ = (patch) => set({ ziele: { ...z, ...patch } });
  return (
    <>
      <div className="card">
        <div className="card-head">
          <div>
            <div className="card-title">Wunsch-Pensionsalter</div>
            <div className="card-desc">Ordentliches AHV-Alter ist 65. Vorbezug bis 2 J. (−6.8 %/J.), Aufschub bis 5 J.</div>
          </div>
        </div>
        <Field label={`${state.person1.vorname || "Person 1"} — Bezugsalter`}>
          <Slider min={62} max={70} value={z.bezugsalterP1} onChange={(v) => onZ({ bezugsalterP1: v })} format={(v) => `${v} J.`} />
        </Field>
        {state.fallart === "paar" && (
          <Field label={`${state.person2.vorname || "Person 2"} — Bezugsalter`}>
            <Slider min={62} max={70} value={z.bezugsalterP2} onChange={(v) => onZ({ bezugsalterP2: v })} format={(v) => `${v} J.`} />
          </Field>
        )}
      </div>
      <div className="card">
        <div className="card-head">
          <div>
            <div className="card-title">Einmalige Ausgaben</div>
            <div className="card-desc">Renovationen, Auto, Hochzeit Kinder — werden im Cashflow im jeweiligen Jahr abgezogen.</div>
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {z.einmalAusgaben.map((e, idx) => (
            <div key={e.id} className="list-item">
              <div className="list-item-head">
                <span>Ausgabe {idx + 1}</span>
                <button className="x-btn" onClick={() => onZ({ einmalAusgaben: z.einmalAusgaben.filter((x) => x.id !== e.id) })}>Entfernen</button>
              </div>
              <div className="card-grid cols-3">
                <Field label="Beschreibung"><TextInput value={e.beschreibung} onChange={(v) => onZ({ einmalAusgaben: z.einmalAusgaben.map((x) => x.id === e.id ? { ...x, beschreibung: v } : x) })} /></Field>
                <Field label="Jahr">
                  <input type="number" className="input tabnum-input" value={e.jahr}
                    onChange={(ev) => onZ({ einmalAusgaben: z.einmalAusgaben.map((x) => x.id === e.id ? { ...x, jahr: Number(ev.target.value) } : x) })} />
                </Field>
                <Field label="Betrag">
                  <NumInput value={e.betrag} onChange={(v) => onZ({ einmalAusgaben: z.einmalAusgaben.map((x) => x.id === e.id ? { ...x, betrag: v } : x) })} />
                </Field>
              </div>
            </div>
          ))}
          <button className="add-row" onClick={() => onZ({ einmalAusgaben: [...z.einmalAusgaben, { id: "e" + Date.now(), jahr: 2030, betrag: null, beschreibung: "" }] })}>+ Einmalige Ausgabe hinzufügen</button>
        </div>
      </div>
    </>
  );
};

// === Block 3: Budget ===
window.Block3 = function Block3({ state, set }) {
  const b = state.budget;
  const onB = (patch) => set({ budget: { ...b, ...patch } });
  return (
    <>
      <div className="card">
        <div className="card-head"><div><div className="card-title">Einkommen</div><div className="card-desc">Brutto-Erwerbseinkommen heute, vor AHV/PK-Abzug.</div></div></div>
        <div className="card-grid cols-2">
          <Field label={`${state.person1.vorname || "Person 1"} — Einkommen p.a.`}><NumInput value={b.einkommenP1} onChange={(v) => onB({ einkommenP1: v })} /></Field>
          {state.fallart === "paar" && <Field label={`${state.person2.vorname || "Person 2"} — Einkommen p.a.`}><NumInput value={b.einkommenP2} onChange={(v) => onB({ einkommenP2: v })} /></Field>}
        </div>
      </div>
      <div className="card">
        <div className="card-head"><div><div className="card-title">Ausgaben</div><div className="card-desc">Heutiger Lebensstandard und Wunschverbrauch nach Pensionierung.</div></div></div>
        <div className="card-grid cols-2">
          <Field label="Ausgaben heute p.a." hint="alles inklusive Miete/Hypozinsen"><NumInput value={b.ausgabenTotal} onChange={(v) => onB({ ausgabenTotal: v })} /></Field>
          <Field label="Wunschverbrauch ab Pension p.a." hint="erfahrungsgemäss 75–85 % des heutigen Bedarfs"><NumInput value={b.wunschVerbrauch} onChange={(v) => onB({ wunschVerbrauch: v })} /></Field>
        </div>
      </div>
    </>
  );
};

// === Block 4: AHV ===
window.Block4 = function Block4({ state, set }) {
  return (
    <div className="card">
      <div className="card-head"><div><div className="card-title">AHV-Rentenfaktor</div><div className="card-desc">1.0 = volle Rente. Bei Beitragslücken (Auslandjahre, Studium) entsprechend tiefer. BSV-Maximum 2025: CHF 30 240 p.a. pro Person, Plafond Ehepaar CHF 45 360.</div></div></div>
      <div className="card-grid cols-2">
        <Field label={`${state.person1.vorname} — Faktor`}>
          <Slider min={0.5} max={1.0} step={0.01} value={state.ahv.rentenfaktorP1} onChange={(v) => set({ ahv: { ...state.ahv, rentenfaktorP1: v } })} format={(v) => v.toFixed(2)} />
        </Field>
        {state.fallart === "paar" && (
          <Field label={`${state.person2.vorname} — Faktor`}>
            <Slider min={0.5} max={1.0} step={0.01} value={state.ahv.rentenfaktorP2} onChange={(v) => set({ ahv: { ...state.ahv, rentenfaktorP2: v } })} format={(v) => v.toFixed(2)} />
          </Field>
        )}
      </div>
    </div>
  );
};

// === Block 5: BVG ===
window.Block5 = function Block5({ state, set }) {
  const Per = ({ idx, p, name, bezAlter, onP }) => {
    const bezJahr = parseInt(state[`person${idx}`].geburtsdatum.slice(0, 4), 10) + bezAlter;
    return (
      <div className="card">
        <div className="card-head">
          <div>
            <div className="card-title">Person {idx} {name ? `· ${name}` : ""} — Pensionskasse</div>
            <div className="card-desc">PK-Ausweis Stand letztes Jahr. Bezugsalter aus Block 2: {bezAlter} ({bezJahr}).</div>
          </div>
        </div>
        <Field label="Aktiver PK-Anschluss?"><YesNo value={p.aktiverAnschluss} onChange={(v) => onP({ aktiverAnschluss: v })} /></Field>
        {p.aktiverAnschluss && (
          <>
            <div className="card-grid cols-2">
              <Field label="Altersguthaben heute"><NumInput value={p.altersguthabenHeute} onChange={(v) => onP({ altersguthabenHeute: v })} /></Field>
              <Field label={`Altersguthaben mit ${bezAlter}`}><NumInput value={p.altersguthabenBeiBezug} onChange={(v) => onP({ altersguthabenBeiBezug: v })} /></Field>
            </div>
            <Field label="Umwandlungssatz" hint="laut PK-Reglement (gesetzlich min. 6.8 %, real meist tiefer)">
              <Slider min={4.5} max={7.0} step={0.1} value={p.umwandlungssatzProzent} onChange={(v) => onP({ umwandlungssatzProzent: v })} format={(v) => `${v.toFixed(1)} %`} />
            </Field>
            <Field label="Bezugspräferenz">
              <Segmented
                options={[
                  { value: "rente", label: "Rente", sub: "100 % verrentet" },
                  { value: "kapital", label: "Kapital", sub: "100 % einmalig" },
                  { value: "mischung", label: "Mischung" },
                ]}
                value={p.bezugspraeferenz}
                onChange={(v) => onP({ bezugspraeferenz: v })}
              />
            </Field>
            {p.bezugspraeferenz === "mischung" && (
              <Field label={`Kapitalanteil`} hint={`Rentenanteil ${100 - p.kapitalanteil}%`}>
                <Slider min={0} max={100} step={5} value={p.kapitalanteil} onChange={(v) => onP({ kapitalanteil: v })} format={(v) => `${v} %`} />
              </Field>
            )}
            {p.einkaeufe.length > 0 && (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <div className="card-eyebrow">Geplante Einkäufe</div>
                {p.einkaeufe.map((ek) => {
                  const sperr = ek.jahr >= bezJahr - 2 && (p.bezugspraeferenz === "kapital" || p.bezugspraeferenz === "mischung");
                  return (
                    <div key={ek.id} className="list-item">
                      <div className="list-item-head">
                        <span>Einkauf {ek.jahr}</span>
                        <button className="x-btn" onClick={() => onP({ einkaeufe: p.einkaeufe.filter(x => x.id !== ek.id) })}>Entfernen</button>
                      </div>
                      <div className="card-grid cols-2">
                        <Field label="Jahr">
                          <input type="number" className="input tabnum-input" value={ek.jahr} onChange={(e) => onP({ einkaeufe: p.einkaeufe.map(x => x.id === ek.id ? { ...x, jahr: Number(e.target.value) } : x) })} />
                        </Field>
                        <Field label="Betrag"><NumInput value={ek.betrag} onChange={(v) => onP({ einkaeufe: p.einkaeufe.map(x => x.id === ek.id ? { ...x, betrag: v } : x) })} /></Field>
                      </div>
                      {sperr && <div className="warn-callout">⚠ 3-Jahres-Sperrfrist: Einkauf liegt &lt; 3 J. vor Kapitalbezug. Art. 79b Abs. 3 BVG blockiert die Auszahlung.</div>}
                    </div>
                  );
                })}
              </div>
            )}
            <button className="add-row" onClick={() => onP({ einkaeufe: [...p.einkaeufe, { id: "ek" + Date.now(), jahr: bezJahr - 4, betrag: 20000 }] })}>+ Einkauf simulieren</button>
          </>
        )}
      </div>
    );
  };
  return (
    <>
      <Per idx={1} p={state.bvg.p1} name={state.person1.vorname} bezAlter={state.ziele.bezugsalterP1} onP={(patch) => set({ bvg: { ...state.bvg, p1: { ...state.bvg.p1, ...patch } } })} />
      {state.fallart === "paar" && <Per idx={2} p={state.bvg.p2} name={state.person2.vorname} bezAlter={state.ziele.bezugsalterP2} onP={(patch) => set({ bvg: { ...state.bvg, p2: { ...state.bvg.p2, ...patch } } })} />}
    </>
  );
};

// === Block 6: 3. Säule ===
window.Block6 = function Block6({ state, set }) {
  const renderArr = (arr, key, name) => (
    <div className="card">
      <div className="card-head"><div><div className="card-title">Person {key === "p1" ? 1 : 2} {name ? `· ${name}` : ""} — 3. Säule</div><div className="card-desc">3a-Konten und 3b-Versicherungen. Maximum 2026: CHF 7 258 Erwerbstätige.</div></div></div>
      {arr.map(s3 => (
        <div key={s3.id} className="list-item">
          <div className="list-item-head">
            <span>{s3.typ === "3a-konto" ? "3a-Konto" : "3b-Versicherung"}</span>
            <button className="x-btn" onClick={() => set({ saeule3: { ...state.saeule3, [key]: arr.filter(x => x.id !== s3.id) } })}>Entfernen</button>
          </div>
          {s3.typ === "3a-konto" ? (
            <div className="card-grid cols-3">
              <Field label="Saldo heute"><NumInput value={s3.saldoHeute} onChange={(v) => set({ saeule3: { ...state.saeule3, [key]: arr.map(x => x.id === s3.id ? { ...x, saldoHeute: v } : x) } })} /></Field>
              <Field label="Einzahlung p.a."><NumInput value={s3.einzahlungJaehrlich} onChange={(v) => set({ saeule3: { ...state.saeule3, [key]: arr.map(x => x.id === s3.id ? { ...x, einzahlungJaehrlich: v } : x) } })} /></Field>
              <Field label="Rendite p.a.">
                <Slider min={0} max={6} step={0.25} value={s3.renditeProzent} onChange={(v) => set({ saeule3: { ...state.saeule3, [key]: arr.map(x => x.id === s3.id ? { ...x, renditeProzent: v } : x) } })} format={(v) => `${v.toFixed(2)} %`} />
              </Field>
            </div>
          ) : (
            <div className="card-grid cols-3">
              <Field label="Rückkaufswert heute"><NumInput value={s3.rueckkaufHeute} onChange={(v) => set({ saeule3: { ...state.saeule3, [key]: arr.map(x => x.id === s3.id ? { ...x, rueckkaufHeute: v } : x) } })} /></Field>
              <Field label="Ablaufwert"><NumInput value={s3.ablaufwert} onChange={(v) => set({ saeule3: { ...state.saeule3, [key]: arr.map(x => x.id === s3.id ? { ...x, ablaufwert: v } : x) } })} /></Field>
              <Field label="Ablaufjahr">
                <input type="number" className="input tabnum-input" value={s3.ablaufjahr} onChange={(e) => set({ saeule3: { ...state.saeule3, [key]: arr.map(x => x.id === s3.id ? { ...x, ablaufjahr: Number(e.target.value) } : x) } })} />
              </Field>
            </div>
          )}
        </div>
      ))}
      <button className="add-row" onClick={() => set({ saeule3: { ...state.saeule3, [key]: [...arr, { id: "s" + Date.now(), typ: "3a-konto", saldoHeute: 0, einzahlungJaehrlich: 7258, renditeProzent: 1.5 }] } })}>+ 3a-Konto hinzufügen</button>
    </div>
  );
  return (
    <>
      {renderArr(state.saeule3.p1, "p1", state.person1.vorname)}
      {state.fallart === "paar" && renderArr(state.saeule3.p2, "p2", state.person2.vorname)}
    </>
  );
};

// === Block 7: Vermögen ===
window.Block7 = function Block7({ state, set }) {
  return (
    <div className="card">
      <div className="card-head"><div><div className="card-title">Konten & Depots</div><div className="card-desc">Liquide Mittel und Wertschriftendepots. Hauptkonto wird für Cashflow-Pufferung genutzt.</div></div></div>
      {state.vermoegen.map(v => (
        <div key={v.id} className="list-item">
          <div className="list-item-head">
            <span>{v.beschreibung || "Konto"}</span>
            <button className="x-btn" onClick={() => set({ vermoegen: state.vermoegen.filter(x => x.id !== v.id) })}>Entfernen</button>
          </div>
          <div className="card-grid cols-3" style={{ gridTemplateColumns: "2fr 1fr 1fr" }}>
            <Field label="Beschreibung"><TextInput value={v.beschreibung} onChange={(val) => set({ vermoegen: state.vermoegen.map(x => x.id === v.id ? { ...x, beschreibung: val } : x) })} /></Field>
            <Field label="Saldo"><NumInput value={v.saldo} onChange={(val) => set({ vermoegen: state.vermoegen.map(x => x.id === v.id ? { ...x, saldo: val } : x) })} /></Field>
            <Field label="Rendite p.a." hint="leer = 0 %">
              <Slider min={0} max={8} step={0.25} value={v.renditeProzent || 0} onChange={(val) => set({ vermoegen: state.vermoegen.map(x => x.id === v.id ? { ...x, renditeProzent: val } : x) })} format={(val) => `${val.toFixed(2)} %`} />
            </Field>
          </div>
        </div>
      ))}
      <button className="add-row" onClick={() => set({ vermoegen: [...state.vermoegen, { id: "v" + Date.now(), beschreibung: "", saldo: 0, renditeProzent: 0 }] })}>+ Konto / Depot hinzufügen</button>
    </div>
  );
};

// === Block 8: Immobilien ===
window.Block8 = function Block8({ state, set }) {
  return (
    <>
      {state.immobilien.map(im => (
        <div key={im.id} className="card">
          <div className="card-head"><div><div className="card-title">{im.art} · {im.adresse}</div><div className="card-desc">Belehnung {im.verkehrswert ? Math.round(im.hypotheken.reduce((a,b)=>a+(b.betrag||0),0) / im.verkehrswert * 100) : 0} % · Plan bei Pension: {im.planBeiPension}</div></div></div>
          <div className="card-grid cols-2">
            <Field label="Verkehrswert"><NumInput value={im.verkehrswert} onChange={(v) => set({ immobilien: state.immobilien.map(x => x.id === im.id ? { ...x, verkehrswert: v } : x) })} /></Field>
            <Field label="Plan bei Pension">
              <Segmented options={[{ value: "behalten", label: "Behalten" }, { value: "verkaufen", label: "Verkaufen" }]} value={im.planBeiPension} onChange={(v) => set({ immobilien: state.immobilien.map(x => x.id === im.id ? { ...x, planBeiPension: v } : x) })} />
            </Field>
          </div>
          <div className="card-eyebrow">Hypotheken-Tranchen</div>
          {im.hypotheken.map(h => (
            <div key={h.id} className="list-item">
              <div className="list-item-head">
                <span>Tranche · ablaufend {h.ablaufjahr}</span>
                <button className="x-btn" onClick={() => set({ immobilien: state.immobilien.map(x => x.id === im.id ? { ...x, hypotheken: x.hypotheken.filter(y => y.id !== h.id) } : x) })}>Entfernen</button>
              </div>
              <div className="card-grid cols-3">
                <Field label="Betrag"><NumInput value={h.betrag} onChange={(v) => set({ immobilien: state.immobilien.map(x => x.id === im.id ? { ...x, hypotheken: x.hypotheken.map(y => y.id === h.id ? { ...y, betrag: v } : y) } : x) })} /></Field>
                <Field label="Zinssatz">
                  <Slider min={0} max={5} step={0.05} value={h.zinsProzent} onChange={(v) => set({ immobilien: state.immobilien.map(x => x.id === im.id ? { ...x, hypotheken: x.hypotheken.map(y => y.id === h.id ? { ...y, zinsProzent: v } : y) } : x) })} format={(val) => `${val.toFixed(2)} %`} />
                </Field>
                <Field label="Ablaufjahr">
                  <input type="number" className="input tabnum-input" value={h.ablaufjahr} onChange={(e) => set({ immobilien: state.immobilien.map(x => x.id === im.id ? { ...x, hypotheken: x.hypotheken.map(y => y.id === h.id ? { ...y, ablaufjahr: Number(e.target.value) } : y) } : x) })} />
                </Field>
              </div>
            </div>
          ))}
          <button className="add-row" onClick={() => set({ immobilien: state.immobilien.map(x => x.id === im.id ? { ...x, hypotheken: [...x.hypotheken, { id: "h" + Date.now(), betrag: 100000, zinsProzent: 1.8, ablaufjahr: 2032 }] } : x) })}>+ Tranche hinzufügen</button>
        </div>
      ))}
    </>
  );
};

// === Block 9, 10 — minimal ===
window.Block9 = function Block9({ state, set }) {
  return (
    <div className="card">
      <div className="card-head"><div><div className="card-title">Firma / Selbständigkeit</div><div className="card-desc">Optional. Beteiligungen, Goodwill, Liquidationsplan.</div></div></div>
      <Field label="Firma vorhanden?"><YesNo value={state.firma.vorhanden} onChange={(v) => set({ firma: { ...state.firma, vorhanden: v } })} /></Field>
      {state.firma.vorhanden && <div className="field-hint">Sektion entfaltet weitere Felder — hier nicht abgebildet im Demo.</div>}
    </div>
  );
};

window.Block10 = function Block10({ state, set }) {
  const n = state.nachlass;
  return (
    <div className="card">
      <div className="card-head"><div><div className="card-title">Nachlass — Status-Erfassung</div><div className="card-desc">Reine Status-Abfrage. Wird im Massnahmen-Panel referenziert.</div></div></div>
      <Field label="Testament vorhanden?"><YesNo value={n.testamentVorhanden} onChange={(v) => set({ nachlass: { ...n, testamentVorhanden: v } })} /></Field>
      <Field label="Ehevertrag vorhanden?"><YesNo value={n.ehevertragVorhanden} onChange={(v) => set({ nachlass: { ...n, ehevertragVorhanden: v } })} /></Field>
      <Field label="Vorsorgeauftrag vorhanden?"><YesNo value={n.vorsorgeauftrag} onChange={(v) => set({ nachlass: { ...n, vorsorgeauftrag: v } })} /></Field>
    </div>
  );
};

window.BLOCKS = [
  { id: 1, title: "Personen", sub: "Stammdaten", desc: "Wer ist im Plan? Stammdaten beeinflussen Steuersatz, AHV-Skala und Paar-Logik.", glance: (s) => s.fallart === "paar" ? `${s.person1.vorname} & ${s.person2.vorname}` : s.person1.vorname, comp: "Block1" },
  { id: 2, title: "Ziele & Wünsche", sub: "Pensionsalter, Wunschausgaben", desc: "Wann wollen Sie aufhören? Welche grossen Ausgaben kommen?", glance: (s) => `${s.ziele.bezugsalterP1}${s.fallart === "paar" ? ` / ${s.ziele.bezugsalterP2}` : ""}`, comp: "Block2" },
  { id: 3, title: "Budget", sub: "Einnahmen & Ausgaben", desc: "Heutige Erwerbssituation und Wunschverbrauch nach Pensionierung.", glance: (s) => fmtCHF((s.budget.einkommenP1 || 0) + (s.budget.einkommenP2 || 0), { compact: true }), comp: "Block3" },
  { id: 4, title: "1. Säule (AHV)", sub: "Rentenfaktor", desc: "AHV-Beitragsjahre und Rentenfaktor pro Person.", glance: (s) => `${s.ahv.rentenfaktorP1.toFixed(2)}${s.fallart === "paar" ? ` / ${s.ahv.rentenfaktorP2.toFixed(2)}` : ""}`, comp: "Block4" },
  { id: 5, title: "Pensionskasse", sub: "2. Säule", desc: "Altersguthaben, Umwandlungssatz, Bezugsform und Einkäufe.", glance: (s) => fmtCHF((s.bvg.p1.altersguthabenBeiBezug || 0) + (s.fallart === "paar" ? (s.bvg.p2.altersguthabenBeiBezug || 0) : 0), { compact: true }), comp: "Block5" },
  { id: 6, title: "3. Säule", sub: "3a / 3b", desc: "Steueroptimierte Eigenvorsorge — Konten und Versicherungen.", glance: (s) => fmtCHF([...s.saeule3.p1, ...(s.fallart === "paar" ? s.saeule3.p2 : [])].reduce((a, b) => a + (b.saldoHeute || b.rueckkaufHeute || 0), 0), { compact: true }), comp: "Block6" },
  { id: 7, title: "Vermögen", sub: "Konten & Depots", desc: "Liquide Mittel und Wertschriften.", glance: (s) => fmtCHF(s.vermoegen.reduce((a, b) => a + (b.saldo || 0), 0), { compact: true }), comp: "Block7" },
  { id: 8, title: "Immobilien", sub: "Liegenschaften", desc: "Wohneigentum und Renditeobjekte mit Hypotheken-Tranchen.", glance: (s) => `${s.immobilien.length} Objekt${s.immobilien.length === 1 ? "" : "e"}`, comp: "Block8" },
  { id: 9, title: "Firma", sub: "Selbständigkeit", desc: "Optional — Beteiligungen, Goodwill, Liquidationsplan.", glance: (s) => s.firma.vorhanden ? "ja" : "—", comp: "Block9" },
  { id: 10, title: "Nachlass", sub: "Vorsorge & Erben", desc: "Testament, Ehevertrag, Vorsorgeauftrag.", glance: (s) => `${[s.nachlass.testamentVorhanden, s.nachlass.ehevertragVorhanden, s.nachlass.vorsorgeauftrag].filter(Boolean).length}/3`, comp: "Block10" },
];
