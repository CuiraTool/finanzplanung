// Mock data — Familie Muster reference (Ralph 1967, Stephanie 1972, Steuerkanton ZH)
// Numbers calibrated to Taxware Muster-PDF eckwerte where possible.
window.CUIRA_INITIAL_STATE = {
  fallart: "paar",
  person1: {
    vorname: "Ralph",
    nachname: "Muster",
    geburtsdatum: "1967-03-12",
    geschlecht: "m",
    zivilstand: "verheiratet",
    konfession: "reformiert",
  },
  person2: {
    vorname: "Stephanie",
    nachname: "Muster",
    geburtsdatum: "1972-09-04",
    geschlecht: "w",
    zivilstand: "verheiratet",
    konfession: "reformiert",
  },
  kinder: [
    { vorname: "Lara", geburtsdatum: "2002-06-01" },
    { vorname: "Niko", geburtsdatum: "2005-08-22" },
  ],
  adresse: { strasse: "Seestrasse 142", plz: "8002", ort: "Zürich", kanton: "ZH" },
  ziele: {
    bezugsalterP1: 64, // Wunsch
    bezugsalterP2: 62,
    ordentlichP1: 65,
    ordentlichP2: 65,
    einmalAusgaben: [
      { id: "e1", jahr: 2027, betrag: 60000, beschreibung: "Küchenrenovation" },
      { id: "e2", jahr: 2030, betrag: 35000, beschreibung: "Auto-Ersatz" },
    ],
  },
  budget: {
    einkommenP1: 168000,
    einkommenP2: 92000,
    ausgabenTotal: 142000,
    wunschVerbrauch: 120000,
  },
  ahv: { rentenfaktorP1: 1.0, rentenfaktorP2: 1.0 },
  bvg: {
    p1: {
      aktiverAnschluss: true,
      altersguthabenHeute: 612000,
      altersguthabenBeiBezug: 845000,
      umwandlungssatzProzent: 5.4,
      bezugspraeferenz: "mischung",
      kapitalanteil: 50,
      einkaeufe: [{ id: "ek1", jahr: 2026, betrag: 25000 }],
      freizuegigkeit: [],
    },
    p2: {
      aktiverAnschluss: true,
      altersguthabenHeute: 218000,
      altersguthabenBeiBezug: 360000,
      umwandlungssatzProzent: 5.4,
      bezugspraeferenz: "rente",
      kapitalanteil: 0,
      einkaeufe: [],
      freizuegigkeit: [{ id: "fz1", beschreibung: "FZ Migros Bank", saldoHeute: 48000, auszahlungsjahr: 2034, renditeProzent: 1.0 }],
    },
  },
  saeule3: {
    p1: [
      { id: "s1", typ: "3a-konto", saldoHeute: 86000, einzahlungJaehrlich: 7258, renditeProzent: 1.5 },
      { id: "s2", typ: "3b-versicherung", rueckkaufHeute: 24000, ablaufwert: 65000, ablaufjahr: 2032 },
    ],
    p2: [
      { id: "s3", typ: "3a-konto", saldoHeute: 42000, einzahlungJaehrlich: 7258, renditeProzent: 1.5 },
    ],
  },
  vermoegen: [
    { id: "v1", beschreibung: "Privatkonto ZKB", saldo: 38000, hauptkonto: true },
    { id: "v2", beschreibung: "Sparkonto", saldo: 95000, hauptkonto: false },
    { id: "v3", beschreibung: "Depot Swissquote", saldo: 280000, renditeProzent: 4.0 },
  ],
  immobilien: [
    {
      id: "i1",
      art: "Eigenheim",
      adresse: "Seestrasse 142, Zürich",
      verkehrswert: 1850000,
      hypotheken: [
        { id: "h1", betrag: 850000, zinsProzent: 1.6, ablaufjahr: 2030 },
        { id: "h2", betrag: 200000, zinsProzent: 2.1, ablaufjahr: 2032 },
      ],
      planBeiPension: "behalten",
    },
  ],
  firma: { vorhanden: false },
  nachlass: { testamentVorhanden: true, ehevertragVorhanden: true, vorsorgeauftrag: true },
};
